"""Independent saved-row/depth I84 audit; no mapper, synchronizer or physics calls."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import argparse
import hashlib
import json
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
FAMILIES = ['shell_A', 'shell_B', 'belt_A', 'belt_B']


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()


def write(p, value):
    with Path(p).open('x') as f: json.dump(value, f, indent=2, sort_keys=True, allow_nan=False); f.write('\n')


def blend(primary, preview):
    p = np.asarray(primary, float); w = np.asarray(preview['blend_weights'], float)
    return p+w*(np.asarray(preview['commands'], float)-p)


def hypothetical(original_requested, native_blend, map_blend, fade, bounds):
    delta = np.asarray(map_blend, float)-np.asarray(native_blend, float)
    scale = np.array([fade, fade, fade, 1., 1.])
    requested = np.asarray(original_requested, float)+delta*scale
    bounds = np.asarray(bounds, float)
    return requested, np.minimum(np.maximum(requested, -bounds), bounds)


def opportunity(targets, change, threshold=.001):
    accepted = any(t['selected_future_map_accepted'] and t['blend_weight'] > 0. for t in targets)
    return accepted, bool(accepted and change >= threshold)


def difference(a, b): return float(np.max(abs(np.asarray(a, float)-np.asarray(b, float))))


def guard(native, mapped):
    a, b = native['targets'], mapped['targets']
    assert len(a) == len(b) == 4
    values = [difference(native['outgoing_tangential_velocity_m_s'], mapped['outgoing_tangential_velocity_m_s'])]
    for x, y, expected in zip(a, b, FAMILIES):
        assert x['name'] == y['name'] == expected
        for key in ['normal_load_N', 'normal_load_fraction', 'current_patch_margin_m']:
            values.append(abs(x[key]-y[key]))
        values.append(difference(x['actual_tangential_velocity_m_s'], y['actual_tangential_velocity_m_s']))
        if x['normal_load_fraction'] >= .05: assert y['blend_weight'] == 0.
    return max(values)


def camera_calibration():
    focal = 64./(2*np.tan(np.deg2rad(100.)/2))
    intrinsic = np.array([[focal, 0., 31.5], [0., focal, 23.5], [0., 0., 1.]])
    result = []
    for angle, xyz in zip([0., 90., 180., 270.], [[.105, 0., .235], [0., .135, .235], [-.105, 0., .235], [0., -.135, .235]]):
        c, s = np.cos(np.deg2rad(angle)), np.sin(np.deg2rad(angle)); a = np.sqrt(.5)
        transform = np.eye(4)
        transform[:3, :3] = np.array([[s, -a*c, a*c], [-c, -a*s, a*s], [0., -a, -a]])
        transform[:3, 3] = xyz; result.append(transform)
    return np.broadcast_to(intrinsic, (4, 3, 3)).copy(), np.asarray(result)


def rotation(q):
    q = np.asarray(q, float); q = q/np.linalg.norm(q, axis=-1, keepdims=True)
    w, x, y, z = q.T
    return np.stack([1-2*(y*y+z*z), 2*(x*y-w*z), 2*(x*z+w*y), 2*(x*y+w*z),
        1-2*(x*x+z*z), 2*(y*z-w*x), 2*(x*z-w*y), 2*(y*z+w*x), 1-2*(x*x+y*y)], axis=-1).reshape(-1, 3, 3)


def inspect_query(query, now, maximum_capture, tolerance):
    assert abs(query['at_time_s']-now) <= tolerance
    for key in ['first_capture_s', 'last_capture_s', 'support_oldest_last_capture_s', 'support_newest_last_capture_s']:
        value = query.get(key)
        if value is not None:
            assert maximum_capture is not None and value <= maximum_capture+tolerance, (key, value, maximum_capture, now)
            assert value+.05 <= now+tolerance
    if query.get('last_capture_s') is not None:
        assert abs(query['age_s']-(now-query['last_capture_s'])) <= tolerance
    if query['supported']:
        assert query['reason'] == 'local_observed_plane'
        assert query['support_cells'] >= 6
        assert query['plane_rms_m'] <= .003+tolerance
        assert query['minor_xy_spread_m'] >= .003-tolerance
        assert query['slope_deg'] <= 60.+tolerance
        assert query['query_cell_height_spread_m'] <= .02+tolerance
        normal = np.asarray(query['normal']); assert abs(np.linalg.norm(normal)-1.) <= tolerance and normal[2] > 0.
        assert abs(query['point_m'][2]-query['height_m']) <= tolerance


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--registration', type=Path, required=True)
    ap.add_argument('--audit', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args(); out = args.output.resolve(); audit = args.audit.resolve()
    if out.exists(): raise FileExistsError(out)
    registration = json.loads(args.registration.read_text()); settings = registration['settings']
    assert registration['iteration'] == 'I-84'
    assert settings['gate_minimum_focus_opportunities'] == 10 and settings['gate_normalized_applied_change'] == .001
    paths = dict(source=Path(__file__).resolve(), tests=Path(__file__).resolve().with_name('test_verify_shadow.py'),
        registration=args.registration.resolve(), rows=audit/'rows.json', depth=audit/'depth_batches.npz', report=audit/'report.json', manifest=audit/'artifact_manifest.json',
        precision=ROOT/settings['inputs']['precision'], model=ROOT/settings['inputs']['model_xml'], config=ROOT/settings['inputs']['config'])
    bindings = {k: dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size, sha256=sha(p)) for k, p in paths.items()}
    for group in ['source_sha256', 'input_sha256']:
        assert all(sha(ROOT/p) == h for p, h in registration[group].items())
    manifest = json.loads(paths['manifest'].read_text())['files']
    assert all((audit/p).stat().st_size == item['bytes'] and sha(audit/p) == item['sha256'] for p, item in manifest.items())
    out.mkdir(parents=True); (out/'source').mkdir()
    for key in ['source', 'tests']: shutil.copyfile(paths[key], out/'source'/paths[key].name)
    write(out/'registered_before_rows_arrays.json', dict(iteration='I-84', utc=datetime.now(timezone.utc).isoformat(), files=bindings,
        scope='Independently recompute all saved shadow command/parity/current guards and fixed opportunity gate; audit causal depth clocks/calibration/poses and sample images. No mapper/synchronizer/raycast/simulator calls.'))
    rows = json.loads(paths['rows'].read_text())['rows']; report = json.loads(paths['report'].read_text())
    required = ['time_s', 'exact_qpos', 'exact_previous_applied', 'exact_input_bounds', 'exact_applied', 'exact_requested', 'exact_equilibrium_command',
        'exact_rolling_feedforward', 'exact_support_command', 'exact_lqr_command', 'exact_sync_weights', 'exact_transition_command_delta', 'exact_heading_command',
        'exact_fade_command_delta', 'exact_drive_fade', 'exact_estimated_support_loads_N']
    with np.load(paths['precision'], allow_pickle=False) as saved: raw = {key: saved[key] for key in required}
    times = raw['time_s']; tol = settings['gate_native_and_current_guard_tolerance']
    assert len(times) == 26601 and np.max(abs(times-np.arange(26601)*.005)) <= 1e-9
    uniform = np.arange(len(times)) % 100 == 0
    dense = (times >= 99.5-1e-9) & (times <= 104.+1e-9)
    expected_indices = np.flatnonzero(uniform | dense)
    assert [r['index'] for r in rows] == expected_indices.tolist()
    assert len(rows) == report['audit_anchors'] and int(uniform.sum()) == report['uniform_anchors'] and int(dense.sum()) == report['dense_anchors']
    max_parity = max_guard = max_delta_error = 0.; qualifying = focus_count = 0; rejects = Counter(); accepted_selected = 0; focus_records = []
    with np.load(paths['depth'], allow_pickle=False) as depth:
        capture = depth['capture_time_s']; delivery = depth['delivered_at_s']
        expected_capture = times[np.arange(len(times)) % 10 == 0]
        assert np.array_equal(capture, expected_capture) and np.array_equal(delivery, capture+.05)
        assert len(capture) == 2661 and len(capture) == report['camera_batches_captured']
        delivered = int(np.sum(delivery <= times[-1]+1e-10))
        assert delivered == report['camera_batches_delivered'] and len(capture)-delivered == report['pending_batches']
        K, transforms = camera_calibration()
        assert difference(K, depth['intrinsics']) <= 1e-12 and difference(transforms, depth['body_from_camera']) <= 1e-12
        assert list(depth['camera_names']) == ['camera_000', 'camera_090', 'camera_180', 'camera_270']
        assert depth['depth_m'].shape == depth['valid_mask'].shape == (2661, 4, 48, 64)
        assert depth['world_from_camera'].shape == (2661, 4, 4, 4)
        selected_q = raw['exact_qpos'][::10]
        body = np.broadcast_to(np.eye(4), (2661, 4, 4)).copy(); body[:, :3, :3] = rotation(selected_q[:, 3:7]); body[:, :3, 3] = selected_q[:, :3]
        expected_poses = body[:, None, :, :]@transforms[None, :, :, :]
        maximum_pose_error = difference(expected_poses, depth['world_from_camera'])
        assert maximum_pose_error <= 1e-9
        valid = depth['valid_mask']; axial = depth['depth_m']
        assert np.isnan(axial[~valid]).all() and np.isfinite(axial[valid]).all() and np.all(axial[valid] > 0.)
        yy, xx = np.meshgrid(np.arange(48), np.arange(64), indexing='ij')
        ray_norm = np.sqrt(((xx-31.5)/K[0, 0, 0])**2+((yy-23.5)/K[0, 1, 1])**2+1.)
        euclidean = axial*ray_norm
        assert np.all(euclidean[valid] >= .08-1e-12) and np.all(euclidean[valid] <= 2.+1e-12)
        sample_indices = [0, 20, 1990, 2010, 2036, 2080, 2660]
        fractions = []
        from PIL import Image, ImageDraw
        montage = Image.new('RGB', (4*256, len(sample_indices)*210), (16, 25, 34)); draw = ImageDraw.Draw(montage)
        for n, batch in enumerate(sample_indices):
            row = []
            for camera in range(4):
                image = axial[batch, camera]; mask = valid[batch, camera]; gray = np.zeros(image.shape, np.uint8)
                gray[mask] = np.clip(255*(1.-image[mask]/2.), 0., 255).astype(np.uint8)
                rgb = np.stack((gray, gray, gray), axis=-1); rgb[~mask] = [90, 35, 45]
                montage.paste(Image.fromarray(rgb).resize((256, 192)), (camera*256, n*210))
                draw.text((camera*256+3, n*210+194), f't={capture[batch]:.2f}s cam{camera*90:03d} valid={mask.mean():.3f}', fill=(235, 239, 242))
                row.append(float(mask.mean()))
            fractions.append(dict(batch=batch, capture_s=float(capture[batch]), delivered_s=float(delivery[batch]), valid_fractions=row))
        montage.save(out/'depth_sample_montage.png')
        for row in rows:
            i = row['index']; now = row['time_s']; assert abs(now-times[i]) <= 1e-12
            assert row['uniform'] == bool(uniform[i]) and row['dense'] == bool(dense[i])
            prefix = np.flatnonzero(delivery <= now+1e-10)
            maximum_capture = None if not len(prefix) else float(capture[prefix[-1]])
            assert row['maximum_delivered_capture_s'] == maximum_capture
            p = sum((raw[k][i] for k in ['exact_equilibrium_command', 'exact_rolling_feedforward', 'exact_support_command', 'exact_lqr_command']), start=np.zeros(5))
            assert difference(p, row['native_pre_sync']) <= tol
            native, mapped = row['native_preview'], row['map_preview']; bounds = raw['exact_input_bounds'][i]
            assert np.array_equal(bounds, settings['operating_bounds'])
            n = blend(p, native); m = blend(p, mapped)
            reconstructed = n+raw['exact_heading_command'][i]+raw['exact_fade_command_delta'][i]
            parity = dict(sync_weights=difference(native['blend_weights'], raw['exact_sync_weights'][i]),
                transition_delta=difference(n-p, raw['exact_transition_command_delta'][i]), requested=difference(reconstructed, raw['exact_requested'][i]),
                applied=difference(np.clip(reconstructed, -bounds, bounds), raw['exact_applied'][i]),
                estimated_loads=difference([t['normal_load_N'] for t in native['targets']], raw['exact_estimated_support_loads_N'][i]))
            assert all(abs(parity[k]-row['native_parity_errors'][k]) <= tol for k in parity)
            g = guard(native, mapped); assert abs(g-row['current_guard_error']) <= tol
            max_parity = max(max_parity, max(parity.values())); max_guard = max(max_guard, g)
            req, applied = hypothetical(raw['exact_requested'][i], n, m, raw['exact_drive_fade'][i], bounds)
            max_delta_error = max(max_delta_error, difference(req, row['map_shadow_requested']), difference(applied, row['map_shadow_applied']))
            assert difference(raw['exact_applied'][i], row['native_applied']) <= tol
            change = float(np.linalg.norm((applied-raw['exact_applied'][i])/bounds))
            assert abs(change-row['normalized_applied_change']) <= tol
            diag = row['map_diagnostics']; assert diag['current_support_uses_native_plane'] and diag['provider_query_time'] == 'anchor_only' and diag['parent_preview_calls'] == 1
            assert abs(diag['anchor_time_s']-now) <= tol
            for selected in diag['selected_targets']:
                query = selected.get('query')
                if query:
                    assert query['future_pose'] and abs(query['anchor_time_s']-now) <= tol
                    for k in ['centre_query', 'foot_query']:
                        if k in query: inspect_query(query[k], now, maximum_capture, tol)
                    if query['accepted']:
                        assert query['centre_query']['supported'] and query['foot_query']['supported']
                        assert query['foot_height_disagreement_m'] <= .003+1e-12
                assert selected['selected_future_map_accepted'] == bool(query and query['accepted'])
                if selected['selected_future_map_accepted'] and selected['blend_weight'] > 0.: accepted_selected += 1
            accepted, qualifies = opportunity(diag['selected_targets'], change)
            assert accepted == row['complete_future_map_nonzero_blend'] and qualifies == row['potential_gate_opportunity']
            focus = 100.5-1e-9 <= now <= 101.8+1e-9; assert focus == row['focus']
            focus_count += int(focus); qualifying += int(focus and qualifies)
            if focus: focus_records.append(dict(index=i,time_s=now,accepted_nonzero_target=accepted,normalized_applied_change=change,qualifies=qualifies))
            rejects.update(diag['rejection_reasons'])
    assert max_delta_error <= tol
    assert abs(max_parity-report['maximum_native_parity_error']) <= tol and abs(max_guard-report['maximum_current_guard_error']) <= tol
    assert dict(rejects) == report['rejection_reasons'] and focus_count == report['focus_anchors'] and qualifying == report['focus_qualifying_opportunities']
    integrity = max_parity <= tol and max_guard <= tol
    passed = bool(integrity and qualifying >= 10)
    assert integrity == report['integrity_passed'] and passed == report['potential_gate_passed']
    assert all(sha(paths[k]) == item['sha256'] for k, item in bindings.items())
    write(out/'report.json', dict(iteration='I-84', passed=True, audit_integrity_passed=integrity, potential_gate_passed=passed,
        opportunity_gate_minimum=10, focus_anchors=focus_count, qualifying_focus_anchors=qualifying, all_saved_anchors=len(rows),
        maximum_native_parity_error=max_parity, maximum_current_guard_error=max_guard, maximum_shadow_command_reconstruction_error=max_delta_error,
        all_unknown_and_fallback_rows_included=True, accepted_nonzero_selected_targets_all_anchors=accepted_selected,
        depth_batches=len(capture), delivered_batches=delivered, pending_batches=len(capture)-delivered,
        maximum_capture_pose_error=maximum_pose_error, exact_calibration_passed=True, depth_range_and_validity_passed=True,
        sample_frames=fractions, focus_rows=focus_records, inputs_unchanged=True,
        no_new_physics=True, no_mapper_synchronizer_or_raycast_calls=True,
        qualification='Independent saved-record audit; a failed potential gate stops this particular map-preparation candidate, not terrain sensing generally. Shadow command effects are not motion results.'))
    write(out/'artifact_manifest.json', dict(iteration='I-84', files={str(p.relative_to(out)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(out.rglob('*')) if p.is_file()}))
    print(json.dumps(dict(passed=True, integrity=integrity, focus_anchors=focus_count, qualifying_focus=qualifying, potential_gate=passed, depth_batches=len(capture))))


if __name__ == '__main__': main()
