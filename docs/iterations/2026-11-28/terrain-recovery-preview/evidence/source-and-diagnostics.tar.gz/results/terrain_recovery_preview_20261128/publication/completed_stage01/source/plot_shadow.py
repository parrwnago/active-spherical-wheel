"""Describe closed I84 shadow applicability and delivered-depth geometry only."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import argparse
import hashlib
import json
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[3]


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda: f.read(1024*1024), b''): h.update(x)
    return h.hexdigest()


def save(p, value):
    with Path(p).open('x') as f: json.dump(value, f, indent=2, sort_keys=True, allow_nan=False); f.write('\n')


def summarize_window(rows):
    accepted_nonzero = accepted_selected = native_nonzero = mapped_nonzero = delta_threshold = complete_cache = 0
    reasons = Counter(); zero_guards = Counter(); target_slots = 0
    for r in rows:
        diag = r['map_diagnostics']; targets = diag['selected_targets']; preview = r['map_preview']['targets']
        accepted_selected += any(t['selected_future_map_accepted'] for t in targets)
        accepted_nonzero += any(t['selected_future_map_accepted'] and t['blend_weight'] > 0. for t in targets)
        native_nonzero += any(t['blend_weight'] > 0. for t in r['native_preview']['targets'])
        mapped_nonzero += any(t['blend_weight'] > 0. for t in preview)
        delta_threshold += r['normalized_applied_change'] >= .001
        complete_cache += diag['future_support_queries'] == diag['accepted_future_supports']
        for t, p in zip(targets, preview):
            target_slots += 1; q = t.get('query'); reasons['no_saved_future_query' if q is None else q['reason']] += 1
            if p['blend_weight'] != 0.:continue
            guards = dict(not_approaching=not p['approaching'], current_load_at_least_5percent=p['normal_load_fraction'] >= .05,
                future_gap_above_20mm=p['predicted_support_gap_m'] > .02,
                zero_exposure_activation=p['predicted_patch_margin_m'] <= -.012,
                tiny_drive_lever_or_axis=(p.get('predicted_contact_lever_m',1.) < .0001 or p.get('predicted_control_axis_norm',1.) < .001))
            for k, value in guards.items():zero_guards[k] += int(value)
            zero_guards['zero_weight_slots'] += 1;zero_guards['no_identified_zero_guard'] += int(not any(guards.values()))
    return dict(anchors=len(rows),selected_target_slots=target_slots,anchors_all_cached_future_supports_accepted=complete_cache,
        cached_future_queries=sum(r['map_diagnostics']['future_support_queries'] for r in rows),
        accepted_cached_future_queries=sum(r['map_diagnostics']['accepted_future_supports'] for r in rows),
        anchors_any_accepted_selected_support=accepted_selected,anchors_accepted_selected_nonzero_blend=accepted_nonzero,
        anchors_nonzero_native_blend=native_nonzero,anchors_nonzero_mapped_blend=mapped_nonzero,
        anchors_normalized_applied_change_at_least_001=delta_threshold,
        maximum_normalized_applied_change=max((r['normalized_applied_change'] for r in rows),default=0.),
        selected_query_reasons=dict(reasons),zero_weight_guard_counts=dict(zero_guards),
        guard_count_qualification='Guards overlap. Zero activation follows selected negative best margin; exposed chosen targets cannot have zero activation.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--registration', type=Path, required=True)
    ap.add_argument('--audit', type=Path, required=True)
    ap.add_argument('--verification', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args(); out = args.output.resolve(); audit = args.audit.resolve()
    if out.exists(): raise FileExistsError(out)
    proto = json.loads(args.registration.read_text()); settings = proto['settings']
    paths = dict(source=Path(__file__).resolve(), registration=args.registration.resolve(),
        rows=audit/'rows.json', report=audit/'report.json', depth=audit/'depth_batches.npz',
        verification=args.verification.resolve()/'report.json', precision=ROOT/settings['inputs']['precision'])
    bindings = {k: dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size, sha256=sha(p)) for k,p in paths.items()}
    assert json.loads(paths['verification'].read_text())['passed']
    out.mkdir(parents=True); (out/'source').mkdir(); shutil.copyfile(paths['source'],out/'source'/paths['source'].name)
    save(out/'registered_before_rows_depth.json', dict(iteration='I-84',utc=datetime.now(timezone.utc).isoformat(),files=bindings,
        scope='Descriptive shadow gate/applicability plots and a fixed-stride sample of causally delivered depth at100.5s. No controller, mapper, raycasting or physics.',
        depth_view=dict(anchor_s=100.5,delivery_only=True,pixel_stride=8,world_xy_halfwidth_m=.35,
            interpretation='Sampled observed points, not a complete fitted terrain map or proof that empty plotted cells were unseen.')))
    rows=json.loads(paths['rows'].read_text())['rows']; report=json.loads(paths['report'].read_text())
    selected=[r for r in rows if r['dense']]
    reasons=Counter(); accepted=np.zeros(len(selected),int); active=np.zeros(len(selected),int); incomplete=np.zeros(len(selected),int); noquery=np.zeros(len(selected),int)
    nonzero_any=np.zeros(len(selected),bool); native_nonzero=np.zeros(len(selected),bool)
    for i,r in enumerate(selected):
        for target in r['map_diagnostics']['selected_targets']:
            query=target.get('query'); reason='no_saved_future_query' if query is None else query['reason']; reasons[reason]+=1
            if target['selected_future_map_accepted']:
                accepted[i]+=1
                if target['blend_weight']>0.:active[i]+=1
            elif query is None:noquery[i]+=1
            else:incomplete[i]+=1
            nonzero_any[i] |= target['blend_weight']>0.
        native_nonzero[i]=any(t['blend_weight']>0. for t in r['native_preview']['targets'])
    t=np.array([r['time_s']for r in selected]);change=np.array([r['normalized_applied_change']for r in selected]); qualifies=np.array([r['potential_gate_opportunity']for r in selected])
    assert np.all(accepted+incomplete+noquery==4)
    dense_summary=dict(dense_anchors=len(selected),selected_target_slots=4*len(selected),
        anchors_any_complete_selected_future_support=int(np.sum(accepted>0)),
        selected_complete_future_support_slots=int(accepted.sum()),
        anchors_any_nonzero_map_preparation_blend=int(nonzero_any.sum()),
        anchors_any_nonzero_native_preparation_blend=int(native_nonzero.sum()),
        anchors_complete_selected_future_support_with_nonzero_blend=int(np.sum(active>0)),
        complete_selected_nonzero_slots=int(active.sum()),
        anchors_normalized_applied_change_at_least_001=int(np.sum(change>=.001)),
        potential_opportunity_anchors=int(qualifies.sum()),
        maximum_normalized_applied_change=float(change.max()),selected_query_reasons=dict(reasons),
        incomplete_selected_support_slots=int(incomplete.sum()),unqueried_selected_support_slots=int(noquery.sum()),
        all_focus_anchors_retained=True,gate_passed=report['potential_gate_passed'],
        qualification='This is applicability of future-only preparation on fixed B060 history, not a live tracking comparison or a rejection of terrain sensing generally.')
    breakdown=dict(focus=summarize_window([r for r in rows if r['focus']]), dense=summarize_window(selected),
        before_focus=summarize_window([r for r in selected if r['time_s']<100.5-1e-9]),
        after_focus=summarize_window([r for r in selected if r['time_s']>101.8+1e-9]),
        uniform=summarize_window([r for r in rows if r['uniform']]), dense_selected_supports=dense_summary,
        registered_focus_qualifying_anchors=report['focus_qualifying_opportunities'],required_focus_qualifying_anchors=10,
        registered_gate_passed=report['potential_gate_passed'],all_unknowns_retained=True)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    fig,axes=plt.subplots(4,1,figsize=(11,10),sharex=True)
    axes[0].step(t,accepted,where='mid',label='Complete accepted selected future supports',color='#318c80')
    axes[0].step(t,active,where='mid',label='Accepted and nonzero preparation blend',color='#a65235')
    axes[0].step(t,incomplete+noquery,where='mid',label='Rejected/incomplete/unqueried selected supports',color='#657482',ls=':')
    axes[0].set_ylabel('Selected drives\nof four');axes[0].set_yticks(range(5));axes[0].legend(loc='upper right',fontsize=8)
    axes[1].plot(t,change,color='#235fa4',label='Norm of actual shadow-applied change / operating bounds')
    axes[1].axhline(.001,color='#ad4334',ls='--',label='Registered change threshold 0.001')
    axes[1].scatter(t[qualifies],change[qualifies],s=15,color='#318c80',label='Qualifying focus anchor')
    axes[1].set_ylabel('Normalized\napplied change');axes[1].legend(loc='upper right',fontsize=8)
    parity=np.array([max(r['native_parity_errors'].values())for r in selected]);guard=np.array([r['current_guard_error']for r in selected])
    axes[2].plot(t,parity,label='Native command/load reconstruction',color='#657482')
    axes[2].plot(t,guard,label='Current support/load/velocity guard',color='#835493',ls='--')
    axes[2].axhline(1e-9,color='#ad4334',ls=':',label='Integrity tolerance 1e-9')
    axes[2].set_ylabel('Max numerical\ndifference');axes[2].legend(loc='upper right',fontsize=8)
    for i,label in enumerate(['shaft torque','shell A torque','shell B torque','belt A speed','belt B speed']):
        delta=np.array([(np.array(r['map_shadow_applied'])-np.array(r['native_applied']))[i]/settings['operating_bounds'][i]for r in selected])
        axes[3].plot(t,delta,label=label)
    axes[3].set_ylabel('Per-channel\nnormalized delta');axes[3].set_xlabel('Recorded physical time (s)');axes[3].legend(loc='upper right',fontsize=8,ncol=2)
    for ax in axes:
        ax.grid(alpha=.2);ax.set_xlim(99.5,104.);ax.axvspan(100.5,101.8,color='#235fa4',alpha=.07)
    fig.suptitle(f"I-84 future-preparation SHADOW | focus {report['focus_qualifying_opportunities']}/{report['focus_anchors']} qualifying anchors (need 10)\nAll 901 dense anchors shown; blue shade is registered focus. No changed commands applied.",fontsize=13)
    fig.tight_layout(rect=(0,0,1,.94));fig.savefig(out/'focus_shadow_applicability.png',dpi=150)
    # Fixed subsampling of delivered frames; never ingest future capture batches.
    with np.load(paths['precision'],allow_pickle=False) as z:
        raw_t=z['time_s'];i=int(np.argmin(abs(raw_t-100.5))); centre=z['exact_qpos'][i,:3]; estimated=z['exact_estimated_contact_point_m'][i]
    with np.load(paths['depth'],allow_pickle=False) as z:
        delivered=z['delivered_at_s']<=100.5+1e-10; indices=np.flatnonzero(delivered)
        valid=z['valid_mask'];depth=z['depth_m'];intrinsics=z['intrinsics'];poses=z['world_from_camera'];capture=z['capture_time_s']
        y,x=np.meshgrid(np.arange(0,48,8),np.arange(0,64,8),indexing='ij');uv=np.column_stack((x.ravel(),y.ravel(),np.ones(x.size)))
        points=[]
        for k in indices:
            for camera in range(4):
                mask=valid[k,camera,y,x].ravel();d=depth[k,camera,y,x].ravel()
                rays=uv@np.linalg.inv(intrinsics[camera]).T;local=rays[mask]*d[mask,None]
                pose=poses[k,camera];world=local@pose[:3,:3].T+pose[:3,3]
                keep=np.all(abs(world[:,:2]-centre[:2])<=.35,axis=1)
                if keep.any():points.append(world[keep])
        points=np.concatenate(points)if points else np.empty((0,3));maximum_capture=float(capture[indices[-1]])
    anchor=next(r for r in rows if abs(r['time_s']-100.5)<1e-8)
    fig2,ax=plt.subplots(figsize=(8,7))
    if len(points):
        cloud=ax.scatter(points[:,0],points[:,1],c=points[:,2],s=2,cmap='viridis',alpha=.5,rasterized=True);fig2.colorbar(cloud,ax=ax,label='Observed world z (m)')
    ax.scatter(*centre[:2],marker='+',s=180,c='#161f28',label='Current wheel centre XY')
    if np.isfinite(estimated).all():ax.scatter(*estimated[:2],marker='*',s=130,c='#bb3d36',label='Current inferred contact point')
    for target in anchor['map_diagnostics']['selected_targets']:
        query=target.get('query')
        if not query:continue
        color='#267b62'if query['accepted']else'#ad4334'
        for key,marker in [('centre_query','x'),('foot_query','o')]:
            if key in query:
                p=query[key]['query_xy_m'];ax.scatter(*p,marker=marker,s=60,c=color,facecolors='none'if marker=='o'else color)
                ax.annotate(target['patch']+(' centre'if key=='centre_query'else' foot'),p,fontsize=7,xytext=(4,4),textcoords='offset points')
    ax.set_aspect('equal');ax.set_xlim(centre[0]-.35,centre[0]+.35);ax.set_ylim(centre[1]-.35,centre[1]+.35);ax.grid(alpha=.2)
    ax.set_xlabel('World x (m)');ax.set_ylabel('World y (m)');ax.legend(fontsize=8,loc='best')
    fig2.suptitle('I-84: observed depth available at 100.5 s | current and future queries\nFixed stride-8 pixel sample, delivered observations only; no simulator contact truth',fontsize=11)
    ax.set_title(f'{len(indices)} delivered batches; latest capture {maximum_capture:.3f} s\nSparse plotted gaps do not establish that the full terrain map is unknown.',fontsize=9)
    fig2.tight_layout(rect=(0,0,1,.91));fig2.savefig(out/'causal_depth_queries_100p5.png',dpi=150)
    with PdfPages(out/'terrain_preview_shadow_assessment.pdf')as pdf:pdf.savefig(fig);pdf.savefig(fig2)
    plt.close(fig);plt.close(fig2)
    breakdown['causal_point_view']=dict(anchor_s=100.5,delivered_batches=len(indices),latest_capture_s=maximum_capture,plotted_points=len(points),pixel_stride=8,world_xy_halfwidth_m=.35)
    assert all(sha(paths[k])==item['sha256']for k,item in bindings.items())
    save(out/'report.json',dict(iteration='I-84',breakdown=breakdown,inputs_unchanged=True,no_new_physics=True))
    save(out/'artifact_manifest.json',dict(iteration='I-84',files={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(out.rglob('*'))if p.is_file()}))
    print(json.dumps(breakdown),flush=True)


if __name__=='__main__':main()
