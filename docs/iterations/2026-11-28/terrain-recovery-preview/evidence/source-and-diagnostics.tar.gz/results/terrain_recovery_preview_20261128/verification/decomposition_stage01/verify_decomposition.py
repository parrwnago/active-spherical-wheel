"""Independent exact I84 posthoc decomposition from closed saved rows only."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import argparse
import hashlib
import json
import shutil
import numpy as np

ROOT=Path(__file__).resolve().parents[3]


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def summarize(rows):
    result=dict(anchors=len(rows))
    counts=Counter();rejects=Counter();family={n:Counter()for n in ['shell_A','shell_B','belt_A','belt_B']}
    maximum=0.
    for r in rows:
        diag=r['map_diagnostics'];targets=diag['selected_targets']
        native={t['name']:t for t in r['native_preview']['targets']};mapped={t['name']:t for t in r['map_preview']['targets']}
        accepted=any(t['selected_future_map_accepted']for t in targets)
        nonzero=any(t['selected_future_map_accepted']and t['blend_weight']>0.for t in targets)
        change=float(np.linalg.norm((np.asarray(r['map_shadow_applied'])-r['native_applied'])/np.array([1.5,.6,.6,.6,.6])))
        counts['anchors_any_accepted_future_support']+=diag['accepted_future_supports']>0
        counts['anchors_selected_future_map_accepted']+=accepted
        counts['anchors_selected_map_accepted_nonzero_blend']+=nonzero
        counts['anchors_selected_map_accepted_nonzero_blend_change_below_registered_threshold']+=nonzero and change<.001
        counts['anchors_map_nonzero_blend']+=any(t['blend_weight']>0.for t in mapped.values())
        counts['anchors_native_nonzero_blend']+=any(t['blend_weight']>0.for t in native.values())
        counts['anchors_applied_change_at_least_registered_threshold']+=change>=.001
        counts['anchors_registered_potential_opportunity']+=nonzero and change>=.001
        counts['anchors_any_exact_applied_change']+=not np.array_equal(r['map_shadow_applied'],r['native_applied'])
        counts['unique_future_patch_pose_queries']+=diag['future_support_queries']
        counts['accepted_complete_future_patch_pose_queries']+=diag['accepted_future_supports']
        counts['rejected_future_patch_pose_queries']+=diag['future_support_queries']-diag['accepted_future_supports']
        rejects.update(diag['rejection_reasons']);maximum=max(maximum,change)
        for t in targets:
            f=family[t['patch']]
            f['selected_map_accepted']+=t['selected_future_map_accepted']
            f['selected_map_accepted_nonzero_blend']+=t['selected_future_map_accepted']and t['blend_weight']>0.
            f['map_nonzero_blend']+=mapped[t['patch']]['blend_weight']>0.
            f['native_nonzero_blend']+=native[t['patch']]['blend_weight']>0.
    result.update({k:int(v)for k,v in counts.items()})
    result.update(maximum_normalized_applied_change=maximum,rejection_reasons=dict(rejects),per_family={k:dict(v)for k,v in family.items()})
    return result


def compare(a,b,path=''):
    if isinstance(b,dict):
        assert set(a)==set(b),(path,set(a)^set(b))
        return sum(compare(a[k],b[k],path+'/'+k)for k in b)
    if isinstance(b,(int,float)):
        assert abs(a-b)<=1e-12,(path,a,b)
        return 1
    assert a==b,(path,a,b)
    return 0


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--base',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();base=args.base.resolve();out=args.output.resolve()
    if out.exists():raise FileExistsError(out)
    paths=dict(source=Path(__file__).resolve(),rows=base/'audit/stage01/rows.json',canonical=base/'analysis/decomposition_stage01/report.json')
    bindings={k:dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p))for k,p in paths.items()}
    out.mkdir(parents=True);shutil.copyfile(paths['source'],out/'verify_decomposition.py')
    (out/'registered_before_rows.json').write_text(json.dumps(dict(iteration='I-84',utc=datetime.now(timezone.utc).isoformat(),files=bindings,
        scope='Exact independent saved-row decomposition; no sensor/model/controller or physics execution.'),indent=2,sort_keys=True)+'\n')
    rows=json.loads(paths['rows'].read_text())['rows'];canonical=json.loads(paths['canonical'].read_text())
    result=dict(strata={k:summarize([r for r in rows if r[k]])for k in ['dense','focus','uniform']},union=summarize(rows))
    leaves=compare(result,dict(strata=canonical['strata'],union=canonical['union']))
    assert all(sha(paths[k])==v['sha256']for k,v in bindings.items())
    report=dict(iteration='I-84',passed=True,numeric_leaves=leaves,all_decomposition_fields_match=True,results=result,
        inputs_unchanged=True,no_sensor_or_physics_execution=True,
        interpretation='Focus/dense map queries are accepted but every prep blend is zero. Uniform has94accepted-nonzero,63unconditionalchangesabove.001,and50jointopportunities;44accepted-nonzero are belowthreshold.')
    (out/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(passed=True,numeric_leaves=leaves,uniform_joint_opportunities=result['strata']['uniform']['anchors_registered_potential_opportunity'])))


if __name__=='__main__':main()
