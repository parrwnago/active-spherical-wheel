"""Preserve closed I83/I84 evidence and exact declared prerequisites, no physics."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[3]
B83 = ROOT / 'results/recovery_assessment_20261128'
B84 = ROOT / 'results/terrain_recovery_preview_20261128'
OUT = B84 / 'publication/evidence_archive_stage01'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for v in iter(lambda: f.read(1024 * 1024), b''):
            h.update(v)
    return h.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    required = [B83 / 'evaluation/completed_stage01/artifact_manifest.json',
                B83 / 'verification/completed_stage01/artifact_manifest.json',
                B83 / 'publication/video_stage01/artifact_manifest.json',
                B84 / 'audit/stage01/artifact_manifest.json']
    assert all(p.is_file() for p in required), 'Close scientific outputs before packaging'
    declared = {}
    p83 = json.loads((B83 / 'protocol/frozen_stage01/protocol.json').read_text())
    for group in ['sources', 'inputs']:
        for n, x in p83[group].items():
            assert sha(ROOT / n) == x['sha256'], n
            declared[n] = x['sha256']
    p84 = json.loads((B84 / 'protocol/frozen_stage01/registration.json').read_text())
    for group in ['source_sha256', 'input_sha256']:
        for n, h in p84[group].items():
            assert sha(ROOT / n) == h, n
            assert n not in declared or declared[n] == h, n
            declared[n] = h
    old_movie = ROOT / 'results/current_belt_capacity_20261128/publication/video_stage01/eight_m100_B030_B060.mp4'
    assert sha(old_movie) == 'a21e4c06ef335704d6ff2db697fe7dca891a33decf12f33abdfba2b3910777ac'
    declared[str(old_movie.relative_to(ROOT))] = sha(old_movie)
    paths = {ROOT / n for n in declared}
    omitted = []
    for base in [B83, B84]:
        for p in base.rglob('*'):
            if not p.is_file():
                continue
            rel = p.relative_to(base)
            if any(n in rel.parts for n in ['__pycache__', 'curation', 'evidence_archive_stage01']):
                if p not in paths and 'evidence_archive_stage01' not in rel.parts:
                    omitted.append({'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size,
                        'sha256': sha(p), 'reason': 'interpreter cache or evidence curation helper'})
                continue
            paths.add(p)
    records = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size,
                'sha256': sha(p)} for p in sorted(paths)]
    OUT.mkdir(parents=True)
    inventory = {'iterations': ['I-83', 'I-84'],
        'bound_before_archive_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Closed new evidence plus exact registered prerequisites at original project-relative paths; not the entire repository or simulator environment.', 'files': records}
    metadata = {'inventory.json': inventory, 'excluded_files.json': {'files': omitted},
        'external_prerequisites.json': {'files': declared}}
    instructions = (
        '# I83/I84 closed evidence\n\n'
        'Extract in an isolated directory. project/ restores original repository-relative paths. '
        'Use the repository plus the recorded Python/Gazebo environment when executing tools; '
        'this archive is not a full operating environment. Verify bytes against _archive/inventory.json. '
        'Living presentation notes and the iteration log are in the accompanying Git repository.\n\n'
        'I83 uses existing I82 recorded states; I84 stores causal four-camera measurements and '
        'shadow preparation proposals. Neither shadow changes nor completed capture establish '
        'an actual driving improvement. Read each report and any preserved failed stages. '
        'No earlier outcome, source or default is overwritten.\n'
    ).encode()
    for n, value in metadata.items():
        write(OUT / n, value)
    (OUT / 'REPRODUCE.md').write_bytes(instructions)
    archive = OUT / 'i83_i84_evidence.tar.gz'
    with tarfile.open(archive, 'w:gz') as tf:
        for p in sorted(paths):
            tf.add(p, arcname='project/' + str(p.relative_to(ROOT)), recursive=False)
        for n, value in metadata.items():
            data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
            entry = tarfile.TarInfo('_archive/' + n); entry.size = len(data)
            tf.addfile(entry, io.BytesIO(data))
        entry = tarfile.TarInfo('_archive/REPRODUCE.md'); entry.size = len(instructions)
        tf.addfile(entry, io.BytesIO(instructions))
    with tarfile.open(archive, 'r:gz') as tf:
        assert len(tf.getmembers()) == len(records) + 4
        for x in records:
            f = tf.extractfile('project/' + x['path']); h = hashlib.sha256(); size = 0
            for v in iter(lambda: f.read(1024 * 1024), b''):
                h.update(v); size += len(v)
            assert h.hexdigest() == x['sha256'] and size == x['bytes'], x['path']
        for n, value in metadata.items():
            expected = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
            assert tf.extractfile('_archive/' + n).read() == expected, n
        assert tf.extractfile('_archive/REPRODUCE.md').read() == instructions
    assert all(sha(ROOT / x['path']) == x['sha256'] for x in records)
    assert all((ROOT / x['path']).stat().st_size == x['bytes'] and
               sha(ROOT / x['path']) == x['sha256'] for x in omitted)
    receipt = {'iterations': ['I-83', 'I-84'], 'archive': str(archive.relative_to(ROOT)),
        'bytes': archive.stat().st_size, 'sha256': sha(archive),
        'project_files_verified': len(records), 'regular_members_verified': len(records) + 4,
        'original_path_prerequisites': len(declared), 'explicit_omissions': len(omitted),
        'every_project_member_stream_sha_size_verified': True,
        'all_four_metadata_members_byte_verified': True, 'new_physics': False}
    write(OUT / 'verification.json', receipt)
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
