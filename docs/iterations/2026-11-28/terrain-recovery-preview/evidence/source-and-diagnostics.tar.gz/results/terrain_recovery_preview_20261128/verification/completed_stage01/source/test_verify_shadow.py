"""Pure independent I84 contracts, without recorded rows/depth or a simulator."""
import unittest
import numpy as np
from verify_shadow import opportunity, hypothetical, blend, camera_calibration, guard


class ShadowContracts(unittest.TestCase):
    def test_unknown_or_zero_weight_cannot_count_even_with_large_change(self):
        self.assertEqual(opportunity([dict(selected_future_map_accepted=False,blend_weight=1.)], .5), (False, False))
        self.assertEqual(opportunity([dict(selected_future_map_accepted=True,blend_weight=0.)], .5), (False, False))

    def test_gate_requires_actual_applied_difference_threshold(self):
        t = [dict(selected_future_map_accepted=True,blend_weight=.1)]
        self.assertEqual(opportunity(t,.00099),(True,False))
        self.assertEqual(opportunity(t,.001),(True,True))

    def test_torque_fade_does_not_scale_belt_speed_delta(self):
        req, applied = hypothetical(np.zeros(5),np.zeros(5),np.ones(5),.25,[.3,.3,.3,.6,.6])
        np.testing.assert_array_equal(req,[.25,.25,.25,1.,1.])
        np.testing.assert_array_equal(applied,[.25,.25,.25,.6,.6])

    def test_actual_clipping_can_cancel_requested_change(self):
        req, applied = hypothetical(np.ones(5),np.zeros(5),np.ones(5),1.,np.ones(5))
        np.testing.assert_array_equal(applied,np.ones(5))
        self.assertGreater(np.linalg.norm(req-applied),0.)

    def test_blend_and_four_camera_geometry(self):
        np.testing.assert_allclose(blend([1.]*5,dict(blend_weights=[.25]*5,commands=[-1.]*5)),[.5]*5)
        K,T=camera_calibration()
        for r in T[:,:3,:3]:
            np.testing.assert_allclose(r.T@r,np.eye(3),atol=1e-15)
            self.assertAlmostEqual(np.linalg.det(r),1.,places=14)
        np.testing.assert_allclose(T[:,2,2],-np.sqrt(.5))
        self.assertEqual(K.shape,(4,3,3))

    def test_current_loaded_drive_override_is_rejected(self):
        names=['shell_A','shell_B','belt_A','belt_B']
        a=dict(outgoing_tangential_velocity_m_s=[0.]*3,targets=[dict(name=n,normal_load_N=1.,normal_load_fraction=.25,current_patch_margin_m=0.,actual_tangential_velocity_m_s=[0.]*3,blend_weight=0.)for n in names])
        import copy
        b=copy.deepcopy(a);self.assertEqual(guard(a,b),0.)
        b['targets'][0]['blend_weight']=.1
        with self.assertRaises(AssertionError):guard(a,b)


if __name__ == '__main__':unittest.main(verbosity=2)
