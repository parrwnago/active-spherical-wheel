"""Post-hoc descriptive decomposition of CLOSED I84 rows; no gate changes."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json


ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parents[1]
SOURCE=Path(__file__).resolve()
ROWS=BASE/'audit/stage01/rows.json'
OUTPUT=BASE/'analysis/decomposition_stage01'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def write(path,value):
    with Path(path).open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def summarize(rows):
    reasons=Counter();queries=accepted=0
    answer=dict(anchors=len(rows),anchors_any_accepted_future_support=0,
        anchors_selected_future_map_accepted=0,anchors_native_nonzero_blend=0,
        anchors_map_nonzero_blend=0,anchors_selected_map_accepted_nonzero_blend=0,
        anchors_selected_map_accepted_nonzero_blend_change_below_registered_threshold=0,
        anchors_applied_change_at_least_registered_threshold=0,
        anchors_registered_potential_opportunity=0,anchors_any_exact_applied_change=0,
        maximum_normalized_applied_change=0.)
    families={name:dict(selected_map_accepted=0,native_nonzero_blend=0,map_nonzero_blend=0,
                        selected_map_accepted_nonzero_blend=0) for name in ('shell_A','shell_B','belt_A','belt_B')}
    for row in rows:
        diag=row['map_diagnostics'];queries+=diag['future_support_queries'];accepted+=diag['accepted_future_supports']
        reasons.update(diag['rejection_reasons'])
        accepted_selected=any(item['selected_future_map_accepted'] for item in diag['selected_targets'])
        native_nonzero=any(weight>0 for weight in row['native_preview']['blend_weights'])
        map_nonzero=any(weight>0 for weight in row['map_preview']['blend_weights'])
        accepted_nonzero=row['complete_future_map_nonzero_blend']
        change=row['normalized_applied_change']
        answer['anchors_any_accepted_future_support']+=diag['accepted_future_supports']>0
        answer['anchors_selected_future_map_accepted']+=accepted_selected
        answer['anchors_native_nonzero_blend']+=native_nonzero
        answer['anchors_map_nonzero_blend']+=map_nonzero
        answer['anchors_selected_map_accepted_nonzero_blend']+=accepted_nonzero
        answer['anchors_selected_map_accepted_nonzero_blend_change_below_registered_threshold']+=accepted_nonzero and change<.001
        answer['anchors_applied_change_at_least_registered_threshold']+=change>=.001
        answer['anchors_registered_potential_opportunity']+=row['potential_gate_opportunity']
        answer['anchors_any_exact_applied_change']+=change>0
        answer['maximum_normalized_applied_change']=max(answer['maximum_normalized_applied_change'],change)
        for selected,native,mapped in zip(diag['selected_targets'],row['native_preview']['targets'],row['map_preview']['targets']):
            item=families[selected['patch']]
            item['selected_map_accepted']+=selected['selected_future_map_accepted']
            item['native_nonzero_blend']+=native['blend_weight']>0
            item['map_nonzero_blend']+=mapped['blend_weight']>0
            item['selected_map_accepted_nonzero_blend']+=selected['selected_future_map_accepted'] and mapped['blend_weight']>0
    answer.update(unique_future_patch_pose_queries=queries,accepted_complete_future_patch_pose_queries=accepted,
                  rejected_future_patch_pose_queries=queries-accepted,rejection_reasons=dict(reasons),per_family=families)
    return answer


def main():
    OUTPUT.mkdir(parents=True,exist_ok=False)
    # Separate registration BEFORE interpreting the closed row data. This is
    # descriptive bookkeeping, not an amended potential/acceptance criterion.
    write(OUTPUT/'registered_before_rows.json',dict(iteration='I-84',
        utc=datetime.now(timezone.utc).isoformat(),source=str(SOURCE.relative_to(ROOT)),source_sha256=sha(SOURCE),
        rows=str(ROWS.relative_to(ROOT)),rows_sha256=sha(ROWS),
        stratum_fields=['focus','dense','uniform'],registered_threshold=.001,
        interpretation='Post-hoc descriptive decomposition only; overlapping strata are separate, original gate and decision unchanged.',
        no_new_physics=True,no_sensor_rerun=True))
    (OUTPUT/'source.py').write_bytes(SOURCE.read_bytes())
    rows=json.loads(ROWS.read_text())['rows']
    result=dict(iteration='I-84',scope='Post-hoc descriptive audit decomposition; no new decision criterion',
        strata={name:summarize([row for row in rows if row[name]]) for name in ('focus','dense','uniform')},
        union=summarize(rows),original_gate_unchanged=True,no_new_physics=True,no_sensor_rerun=True,
        current_guard_qualification='Audited native and current-value errors are exactly zero. Exact-qpos zero-horizon quaternion-normalization classification remains a general source qualification, not a demonstrated error on this dataset.')
    write(OUTPUT/'report.json',result)
    if sha(ROWS)!=json.loads((OUTPUT/'registered_before_rows.json').read_text())['rows_sha256']:
        raise AssertionError('Closed audit rows changed during descriptive reduction')
    write(OUTPUT/'artifact_manifest.json',dict(files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p))
        for p in sorted(OUTPUT.iterdir()) if p.is_file()}))
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=='__main__':main()
