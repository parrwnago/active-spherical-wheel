"""Freeze I84 shadow sources, old sealed inputs and optical scene before arrays."""
from __future__ import annotations

from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
import argparse
import json
import xml.etree.ElementTree as ET

import numpy as np

from spherical_wheel.terrain_depth import TerrainRayScene
from shadow_audit import ROOT, HERE, SETTINGS, sha, save


I82 = ROOT / 'results/current_belt_capacity_20261128'
I82_PROTOCOL = I82 / 'protocol/frozen_stage01/protocol.json'
I82_PROTOCOL_SHA = 'ce39ad0f0cd6c3748e764b72d413b45ad20353c1deb641bdbd722c35402dc400'
I82_SEAL = I82 / 'campaign/outputs_sealed.json'
I82_SEAL_SHA = '957e356fc264ee4b38cee442acf3908d053809518223a3c776b269b7806335f8'


def relative(path):
    path=Path(path).resolve()
    if not path.is_file() or path.is_symlink():
        raise ValueError('Existing regular repository input required: '+str(path))
    return str(path.relative_to(ROOT))


def xml_closure(xml):
    """Exact explicit include/asset paths only; no unrelated directory walk."""
    result, pending = set(), [Path(xml).resolve()]
    while pending:
        path=pending.pop()
        if path in result:continue
        relative(path);result.add(path)
        tree=ET.parse(path).getroot();compiler=tree.find('compiler')
        directories={} if compiler is None else compiler.attrib
        for node in tree.iter():
            filename=node.get('file')
            if not filename:continue
            candidate=Path(filename)
            if not candidate.is_absolute():
                directory=directories.get('meshdir','') if node.tag=='mesh' else directories.get('texturedir','') if node.tag=='texture' else ''
                candidate=path.parent/directory/candidate
            candidate=candidate.resolve();relative(candidate)
            if node.tag=='include':pending.append(candidate)
            else:result.add(candidate)
    return result


def verify_i82():
    if sha(I82_PROTOCOL)!=I82_PROTOCOL_SHA or sha(I82_SEAL)!=I82_SEAL_SHA:
        raise AssertionError('Original frozen protocol/output seal changed')
    protocol=json.loads(I82_PROTOCOL.read_text());seal=json.loads(I82_SEAL.read_text())
    if (len(protocol['source_sha256']),len(protocol['input_sha256']),len(seal['files']))!=(93,59,456):
        raise AssertionError('Original physical registration/seal counts differ')
    for group in ('source_sha256','input_sha256'):
        for name,expected in protocol[group].items():
            if sha(ROOT/name)!=expected:raise AssertionError('Original source/input changed: '+name)
    for name,expected in seal['files'].items():
        path=I82/name
        if sha(path)!=expected['sha256'] or path.stat().st_size!=expected['bytes']:
            raise AssertionError('Original closed output changed: '+name)
    return protocol,seal


def crop_certificate():
    angle=np.deg2rad(113.);rotation=np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])
    origin=np.array([-2.4,10.])+rotation@np.array([.5,0.])
    half=abs(rotation)@np.array([.5,.25]);margin=2.30
    required=np.array([origin[0]-half[0]-margin,origin[0]+half[0]+margin,
                       origin[1]-half[1]-margin,origin[1]+half[1]+margin])
    bounds=np.asarray(SETTINGS['scene_crop_xy_m'])
    if not (bounds[0]<=required[0] and bounds[1]>=required[1] and bounds[2]<=required[2] and bounds[3]>=required[3]):
        raise AssertionError('Optical crop does not enclose analytic route plus optical margin')
    return dict(analytic_origin_xy_m=origin,analytic_bounding_halfwidth_xy_m=half,
                required_crop_xy_m=required,actual_crop_xy_m=bounds,optical_margin_m=margin,
                no_executed_trajectory_used=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--register',action='store_true')
    args=parser.parse_args()
    if not args.register:raise SystemExit('Explicit --register required; arrays are never loaded here')
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    old,seal=verify_i82()
    sources=dict(old['source_sha256'])
    for name in ('map_preparation.py','causal_depth_memory.py','shadow_audit.py','register_audit.py','test_runtime.py','settings.json','PROPOSAL_stage01.md'):
        path=HERE/name;sources[relative(path)]=sha(path)
    inputs=dict(old['input_sha256'])
    for path in (I82_PROTOCOL,I82_SEAL,*[ROOT/name for name in SETTINGS['inputs'].values()]):
        inputs[relative(path)]=sha(path)
    # Native CAD is an explicit optional generator input, never an implicit scan.
    cad_presence={}
    for name in ('shell_positive.obj','shell_negative.obj','carrier.obj'):
        path=ROOT/'assets/cad/visuals'/name;cad_presence[str(path.relative_to(ROOT))]=path.exists()
        if path.exists():inputs[relative(path)]=sha(path)
    for path in xml_closure(ROOT/SETTINGS['inputs']['model_xml']):
        inputs[relative(path)]=sha(path)
    config=json.loads((ROOT/SETTINGS['inputs']['config']).read_text())
    certificate=crop_certificate()
    save(output/'registered_before_scene.json',dict(iteration='I-84',utc=datetime.now(timezone.utc).isoformat(),
        sources=sources,inputs=inputs,settings=SETTINGS,known_optional_cad_presence=cad_presence,
        old_source_count=93,old_input_count=59,old_sealed_file_count=456,
        crop_certificate=certificate,no_arrays_loaded=True,no_new_physics=True))
    scene=TerrainRayScene.from_mars(config,output/'optical_scene',SETTINGS['scene_crop_xy_m'],
                                  dem_obj=ROOT/SETTINGS['inputs']['collision_dem'])
    scene_xml=Path(scene.metadata['scene_xml'])
    scene_files=xml_closure(scene_xml)
    for record in scene.metadata['source_assets']:
        path=Path(record['path'])
        if sha(path)!=record['sha256']:raise AssertionError('Sensor source asset changed')
        scene_files.add(path)
    for path in scene_files:inputs[relative(path)]=sha(path)
    metadata_path=output/'optical_scene_metadata.json';save(metadata_path,scene.metadata)
    inputs[relative(metadata_path)]=sha(metadata_path)
    verify_i82()
    registration=dict(iteration='I-84',utc=datetime.now(timezone.utc).isoformat(),settings=SETTINGS,
        source_sha256=sources,input_sha256=inputs,
        sensor_scene=dict(model_xml=relative(scene_xml),metadata=scene.metadata,
                          explicit_xml_asset_closure=[relative(p) for p in sorted(scene_files)]),
        crop_certificate=certificate,known_optional_cad_presence=cad_presence,
        physical_prerequisite_protocol_sha256=I82_PROTOCOL_SHA,physical_output_seal_sha256=I82_SEAL_SHA,
        imported_repository_sources_scope='All93 original frozen sources plus explicit I84 sources/contracts/settings; conservative superset of imported source files.',
        versions={name:version(name) for name in ('numpy','scipy','mujoco','Pillow','PyYAML')},
        no_arrays_loaded=True,no_new_physics=True)
    save(output/'registration.json',registration)
    print(json.dumps(dict(iteration='I-84',registration=relative(output/'registration.json'),
        sha256=sha(output/'registration.json'),source_count=len(sources),input_count=len(inputs),
        original_sources=93,original_inputs=59,sealed_outputs=456,
        arrays_loaded=False,physics_run=False)),flush=True)


if __name__=='__main__':main()
