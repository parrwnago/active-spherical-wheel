"""Run the frozen I82 pair serially, gating raised capacity on exact baseline."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    campaign = BASE / 'campaign'
    campaign.mkdir(exist_ok=False)
    (campaign / 'runs').mkdir()
    protocol = BASE / 'protocol/frozen_stage01/protocol.json'
    runner = BASE / 'runner/run_case.py'
    env = os.environ.copy()
    for name in ['PYTHONPATH', 'LD_LIBRARY_PATH', 'LD_PRELOAD']:
        env.pop(name, None)
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    save(campaign / 'registered_launch.json', dict(iteration='I-82',
        utc=datetime.now(timezone.utc).isoformat(), protocol_sha256=sha(protocol),
        launcher_sha256=sha(Path(__file__)), execution_order=['B030', 'B060'],
        scope='Two full133s current native cases, same original gains; raised arm starts only after full79field baseline parity.',
        environment=dict(unset=['PYTHONPATH','LD_LIBRARY_PATH','LD_PRELOAD'],
                         set={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})))
    observed = []
    for arm in ['B030', 'B060']:
        cmd = [str(ROOT / 'build/tools/bin/micromamba'), 'run', '-p',
               str(ROOT / 'build/gazebo-env'), 'python', str(runner),
               '--protocol', str(protocol), '--arm', arm,
               '--output', str(campaign / 'runs' / arm), '--run']
        if arm == 'B060':
            baseline = campaign / 'runs/B030'
            outcome = json.loads((baseline / 'outcome.json').read_text())
            assert outcome['baseline_parity_passed'] and outcome['runner_recording_completed']
            cmd += ['--native-baseline', str(baseline)]
        save(campaign / f'{arm}.launch.json', dict(iteration='I-82', arm=arm,
            utc=datetime.now(timezone.utc).isoformat(), command=cmd, cwd=str(ROOT)))
        print(f'Launching {arm}, full133s', flush=True)
        with (campaign / f'{arm}.stdout.log').open('xb') as log:
            result = subprocess.run(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        receipt = dict(iteration='I-82', arm=arm, utc=datetime.now(timezone.utc).isoformat(),
                       actual_observed_exit_code=result.returncode,
                       source='Actual subprocess.run returncode, not inferred from saved artifacts', command=cmd)
        save(campaign / f'{arm}.observed_exit.json', receipt)
        observed.append(receipt)
        print(json.dumps({'arm': arm, 'observed_exit_code': result.returncode}), flush=True)
        if result.returncode != 0:
            raise SystemExit(result.returncode)
    save(campaign / 'launch_completed.json', dict(iteration='I-82',
        utc=datetime.now(timezone.utc).isoformat(), observed=observed,
        all_processes_observed=True, all_returned_zero=True,
        physical_completion_is_separate_from_process_status=True))


if __name__ == '__main__':
    main()
