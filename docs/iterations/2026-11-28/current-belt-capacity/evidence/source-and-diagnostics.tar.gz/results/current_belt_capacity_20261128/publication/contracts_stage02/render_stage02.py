"""I82 exact recorded-pose movies: same LQR, different operating belt caps.

Gazebo/DART supplies all recorded dynamics. MuJoCo is a display-only model;
the renderer never executes a controller, observer or physics step.
"""
from pathlib import Path
from datetime import datetime, timezone
from unittest.mock import patch
import argparse
import hashlib
import importlib.util
import json
import math
import os
import shutil
import sys
os.environ.setdefault('MUJOCO_GL', 'egl')
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
OLD = ROOT / 'results/tangent_heading_routes_20261127'
TRUSTED = OLD / 'publication/video_tools/render.py'
GEOMETRY_HELPER = ROOT / 'results/path_progress_governor_20261128/publication/render.py'
FPS = 10
WIDTH, HEIGHT = 1600, 1010
PANEL_WIDTH, RENDER_HEIGHT = 800, 500
ARMS = ('B030', 'B060')
CAPS = dict(B030=.3, B060=.6)
LABELS = dict(B030='Original native N | belt cap 0.30 m/s', B060='Same native N | belt cap 0.60 m/s')
FAMILIES = ('shell A', 'shell B', 'belt A', 'belt B')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def safe(v):
    if isinstance(v, dict): return {str(k): safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [safe(x) for x in v]
    if isinstance(v, np.ndarray): return safe(v.tolist())
    if isinstance(v, np.generic): return safe(v.item())
    if isinstance(v, Path): return str(v)
    if isinstance(v, float) and not np.isfinite(v): return None
    return v


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(safe(value), f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def case_paths(case):
    inner = Path(case) / 'child/campaign/runs/eight_m100_N'
    return dict(case=Path(case), inner=inner, precision=inner/'precision.npz',
                rollout=inner/'rollout.npz', summary=inner/'summary.json',
                provenance=inner/'provenance.json', config=inner/'source_snapshot/config/model.yaml',
                outcome=Path(case)/'outcome.json', capacity=Path(case)/'capacity_receipt.json')


def display_moments(start=0., end=133.):
    if not np.isfinite([start, end]).all() or start < 0 or end < start:
        raise ValueError('Finite ordered physical time window required')
    first = int(round(start*FPS))
    last = int(round(end*FPS))
    if abs(first/FPS-start) > 1e-9 or abs(last/FPS-end) > 1e-9:
        raise ValueError('Presentation endpoints must lie on the fixed 10fps grid')
    return np.arange(first, last+1, dtype=float)/FPS


def dominant(load):
    a = np.asarray(load, float)
    return FAMILIES[int(np.argmax(a))] if np.sum(np.maximum(a, 0)) > 1e-9 else 'none'


def verify_seal(base, seal_path, protocol_path, cases):
    seal = json.loads(Path(seal_path).read_text())
    protocol = json.loads(Path(protocol_path).read_text())
    if protocol.get('iteration') != 'I-82' or seal.get('iteration') != 'I-82':
        raise ValueError('I82 frozen protocol and final output seal required')
    if seal.get('protocol_sha256') != sha(protocol_path):
        raise ValueError('Output seal does not bind this protocol')
    for rel, item in seal['files'].items():
        p = (base/rel).resolve()
        if not p.is_relative_to(base) or p.stat().st_size != item['bytes'] or sha(p) != item['sha256']:
            raise ValueError('Sealed output changed: ' + rel)
    for arm, case in cases.items():
        paths = case_paths(case)
        for key in ('precision', 'rollout', 'summary', 'provenance', 'outcome', 'capacity'):
            if str(paths[key].relative_to(base)) not in seal['files']:
                raise ValueError('Final seal lacks required input: ' + arm + '/' + key)
    # Root observes actual process statuses. Accept either standard spelling;
    # no summary-file inference of a successful process is permitted.
    success = seal.get('all_processes_successful', seal.get('all_returned_zero', seal.get('observed_return_codes_all_zero')))
    if success is not True and seal.get('all_processes_observed') is not True:
        raise ValueError('Both process exits must be observed before rendering')
    return protocol, dict(passed=True, protocol_sha256=sha(protocol_path),
                         output_seal_sha256=sha(seal_path), sealed_files=len(seal['files']))


def register(base, stage, seal_path, protocol_path, cases):
    protocol, verification = verify_seal(base, seal_path, protocol_path, cases)
    stage.mkdir(parents=True, exist_ok=False)
    dependencies = [Path(__file__).resolve(), TRUSTED, GEOMETRY_HELPER,
        protocol_path, seal_path, OLD/'runtime/route.py',
        ROOT/'src/spherical_wheel/offroad_view.py', ROOT/'src/spherical_wheel/gazebo/mars_compare.py',
        ROOT/'src/spherical_wheel/gazebo/mars.py', ROOT/'src/spherical_wheel/offroad.py',
        ROOT/'src/spherical_wheel/model.py', ROOT/'src/spherical_wheel/sim.py', ROOT/'src/spherical_wheel/terrain.py']
    yard = ROOT/'assets/gazebo/third_party/leo_simulator-ros2/leo_gz_worlds/models/marsyard2021_terrain'
    dependencies += [yard/'dem/marsyard_terrain_hm.tif',
                     *[yard/'meshes'/f'{name}.obj' for name in ('lava', 'rocks_big', 'rocks_medium')]]
    models = {}
    for arm, case in cases.items():
        paths = case_paths(case)
        dependencies += [paths[key] for key in ('precision', 'rollout', 'summary', 'provenance', 'config', 'outcome', 'capacity')]
        raw = json.loads(paths['provenance'].read_text())['models']
        models[arm] = {}
        for key in ('mirror_xml', 'physical_sdf'):
            p = Path(raw[key]).resolve()
            if not p.is_relative_to(case): raise ValueError('Recorded model path escapes case')
            models[arm][key] = str(p)
            dependencies.append(p)
    bindings = {str(p.relative_to(ROOT)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(set(dependencies))}
    for p in dependencies:
        if p.suffix == '.py':
            dest = stage/'source'/p.relative_to(ROOT)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, dest)
    save(stage/'registered_before_arrays_and_render.json', dict(iteration='I-82',
        utc=datetime.now(timezone.utc).isoformat(), files=bindings, raw_models=models,
        playback=dict(fps=FPS, speed=1., physical_time_shared=True, no_progress_alignment=True),
        camera='One static world-up camera covers both full recorded paths and planned geometry; event movie uses the same camera.',
        scope='Recorded Gazebo/DART poses, MuJoCo display only. No controller, observer or physics replay.',
        capacities_m_s=CAPS, method='Same native N LQR/observer/FF; only operating belt caps differ.'))
    save(stage/'output_seal_verification.json', verification)
    return protocol, bindings, models


def load_runs(cases, trusted):
    runs = {}
    for arm, case in cases.items():
        paths = case_paths(case)
        with np.load(paths['precision'], allow_pickle=False) as z:
            names = dict(time_s='time_s', qpos='exact_qpos', qvel='exact_qvel',
                reference_xy='exact_reference_xy', reference_quat='exact_reference_quat',
                requested='exact_requested', applied='exact_applied', bounds='exact_input_bounds',
                truth_load='truth_patch_loads_N', inferred_load='exact_estimated_support_loads_N',
                held='command_held_after_row')
            log = {name: z[key].copy() for name, key in names.items()}
        with np.load(paths['rollout'], allow_pickle=False) as z:
            for key in ('time_s', 'qpos', 'qvel', 'reference_xy'):
                if not np.array_equal(z[key], log[key].astype(z[key].dtype)):
                    raise ValueError('Recorded display encoding differs: ' + arm + '/' + key)
            log['ground_height_m'] = z['ground_height_m'].astype(float)
        if not np.isfinite(np.r_[log['time_s'], log['qpos'].ravel(), log['qvel'].ravel()]).all():
            raise ValueError('Cannot render nonfinite recorded states')
        expected = np.array([1.5, .6, .6, CAPS[arm], CAPS[arm]])
        np.testing.assert_array_equal(log['bounds'], np.tile(expected, (len(log['time_s']), 1)))
        signals = trusted.orientation_signals(log['qpos'], log['qvel'], log['reference_quat'])
        runs[arm] = dict(paths=paths, log=log, signals=signals,
                        summary=json.loads(paths['summary'].read_text()),
                        outcome=json.loads(paths['outcome'].read_text()))
    return runs


def composite(runs, moment, plant, renderer, camera, option, viewer, path, trusted):
    from PIL import Image, ImageDraw
    frame = Image.new('RGB', (WIDTH, HEIGHT), (13,21,31))
    draw = ImageDraw.Draw(frame)
    draw.text((22,12), f'I-82 | same figure-eight | shaft start -1.0 rad | shared t = {moment:06.2f} s | 1x', font=trusted.font(25), fill='white')
    draw.text((22,47), 'Recorded Gazebo / DART. Same LQR + observer + feedforward; only both belt operating speed caps differ.', font=trusted.font(19), fill=(186,199,211))
    panels = []
    goal = path(path.start_s+path.duration_s)[0]
    for column, arm in enumerate(ARMS):
        run = runs[arm]; log = run['log']; signals = run['signals']
        sample = trusted.display_sample(log['time_s'], moment)
        index = sample['pose_index']; left = column*PANEL_WIDTH
        pixels = viewer._draw(plant, renderer, log, index, camera, option, True)
        frame.paste(Image.fromarray(pixels), (left,80)); draw = ImageDraw.Draw(frame)
        draw.rectangle((left,80,left+PANEL_WIDTH-1,115), fill=(15,24,34))
        draw.text((left+14,84), LABELS[arm], font=trusted.font(23), fill='white')
        if sample['run_ended_pose_frozen']:
            draw.rectangle((left+8,180,left+PANEL_WIDTH-8,230), fill=(114,24,28))
            draw.text((left+18,190), f'RUN ENDED at {log["time_s"][-1]:.3f} s; pose frozen', font=trusted.font(20), fill='white')
        error = 1000*np.linalg.norm(log['qpos'][index,:2]-log['reference_xy'][index])
        goal_error = 1000*np.linalg.norm(log['qpos'][index,:2]-goal)
        ratio = float(np.max(np.abs(log['requested'][index])/log['bounds'][index]))
        lines = [f'Recorded pose time: {log["time_s"][index]:7.3f} s',
            f'Timed position / goal error: {error:6.1f} / {goal_error:6.1f} mm',
            f'Body tilt / ref lean / up error: {signals["tilt_deg"][index]:5.1f} / {signals["reference_lean_deg"][index]:5.1f} / {signals["reference_up_error_deg"][index]:5.1f} deg',
            f'XY speed: {np.linalg.norm(log["qvel"][index,:2]):.3f} m/s | spin: {signals["omega_world_z_deg_s"][index]:+.1f} deg/s',
            f'Belt A request / applied: {log["requested"][index,3]:+.3f} / {log["applied"][index,3]:+.3f} m/s',
            f'Belt B request / applied: {log["requested"][index,4]:+.3f} / {log["applied"][index,4]:+.3f} m/s',
            f'Last-solve / inferred support: {dominant(log["truth_load"][index])} / {dominant(log["inferred_load"][index])}',
            f'Largest request / its own cap: {ratio:.2f}']
        for number, line in enumerate(lines):
            draw.text((left+14,591+number*29), line, font=trusted.font(19), fill=(230,235,241))
        terminal = index == len(log['time_s'])-1
        draw.text((left+14,830), 'Last emitted command UNHELD.' if terminal else 'Current emitted command acts after the recorded state.', font=trusted.font(17), fill=(224,183,110))
        if column: draw.line((left,80,left,865), fill=(81,94,105), width=2)
        panels.append(dict(arm=arm, **sample, terminal_command_unheld=terminal,
                           recorded_reference_xy_m=log['reference_xy'][index]))
    draw.text((22,881), 'Orange: shared reference and current target | Cyan: actual recorded wheel-centre trail.', font=trusted.font(20), fill=(236,190,114))
    draw.text((22,916), 'Support labels compare instantaneous last-solve pressure with filtered inference; they are not an error count.', font=trusted.font(18), fill=(186,199,211))
    draw.text((22,949), 'Same physical elapsed time at 1x. Rough-stress terrain. Ended runs freeze visibly; full goal hold is retained.', font=trusted.font(18), fill=(186,199,211))
    draw.text((22,981), 'MuJoCo visuals only: no controller, observer or physics integration. Completion does not mean acceptance.', font=trusted.font(17), fill=(166,180,193))
    return np.asarray(frame), panels


def decode_sequential(video, stage, expected_frames):
    """Decode every saved frame using this renderer's declared dimensions."""
    import imageio_ffmpeg
    from PIL import Image
    original = sha(video)
    frames = imageio_ffmpeg.read_frames(str(video), input_params=['-threads','1'], output_params=['-threads','1'])
    info = next(frames); count = 0
    if info['size'] != (WIDTH, HEIGHT) or info['fps'] != FPS:
        frames.close()
        raise ValueError('Encoded dimensions/fps differ from I82 renderer')
    try:
        for index, pixels in enumerate(frames):
            count = index + 1
            if index in (0, expected_frames//2, expected_frames-1):
                Image.frombytes('RGB', info['size'], pixels).save(stage/f'decoded_{index:04d}.jpg', quality=95)
    finally:
        frames.close()
    if count != expected_frames or sha(video) != original:
        raise ValueError('Encoded frame count or bytes changed')
    if abs(info['duration']-expected_frames/FPS) > .03:
        raise ValueError('Encoded duration differs')
    return dict(path=str(video.relative_to(ROOT)) if video.is_relative_to(ROOT) else str(video),
        sha256=original, bytes=video.stat().st_size, decoded_frames=count,
        duration_s=info['duration'], all_frames_decoded=True,
        decode_policy='Sequential full stream, one FFmpeg input/output thread; I82 declared1600x1010 dimensions.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base', type=Path, default=BASE)
    ap.add_argument('--protocol', type=Path, required=True)
    ap.add_argument('--input-seal', type=Path, required=True)
    ap.add_argument('--case030', type=Path, required=True)
    ap.add_argument('--case060', type=Path, required=True)
    ap.add_argument('--stage', type=Path, required=True)
    ap.add_argument('--preview', action='store_true')
    args = ap.parse_args(); base=args.base.resolve(); stage=args.stage.resolve()
    cases = dict(B030=args.case030.resolve(), B060=args.case060.resolve())
    protocol, bindings, models = register(base, stage, args.input_seal.resolve(), args.protocol.resolve(), cases)
    trusted = module(TRUSTED, '_i82_trusted_video')
    geometry_helper = module(GEOMETRY_HELPER, '_i82_trusted_geometry')
    runs = load_runs(cases, trusted)
    routes = module(OLD/'runtime/route.py', '_i82_frozen_routes')
    path = routes.make_route('eight'); planned = routes.samples('eight')['xy_m']
    for run in runs.values(): run['log']['planned_xy'] = planned[::4]
    points = np.concatenate([planned, *[x['log']['qpos'][:,:2] for x in runs.values()],
                             *[x['log']['reference_xy'] for x in runs.values()]])
    low, high = points.min(axis=0), points.max(axis=0); middle=.5*(low+high)
    bounds = (float(low[0]-.6), float(high[0]+.6), float(low[1]-.6), float(high[1]+.6))
    from spherical_wheel.gazebo.mars import MarsYard
    from spherical_wheel.gazebo.mars_compare import replay_plant
    from spherical_wheel import offroad_view as viewer
    import mujoco, yaml, imageio.v2 as imageio
    if len({sha(x['paths']['config']) for x in runs.values()}) != 1:
        raise ValueError('Captured robot configurations differ')
    yard = MarsYard(); span=float(np.max(high-low)+.4)
    camera_info = dict(lookat=[float(middle[0]),float(middle[1]),float(yard.height(*middle)+.08)],
        azimuth_deg=23., elevation_deg=-32., distance_m=max(2.,1.6*span),
        full_actual_reference_bounds_xy_m=[low[0],high[0],low[1],high[1]])
    camera = viewer._camera(camera_info['lookat'],23.,-32.,camera_info['distance_m'])
    config = yaml.safe_load(next(iter(runs.values()))['paths']['config'].read_text())
    def no_step(*args, **kwargs): raise AssertionError('Display attempted physics integration')
    moments = display_moments()
    if args.preview: moments=np.array([0.,3.,98.,100.9,101.5,104.,123.,133.])
    video=stage/'eight_m100_B030_B060.mp4'; event=stage/'event_98_104_B030_B060.mp4'
    schedule=[]; writer=event_writer=None
    with patch.object(mujoco,'mj_step',no_step), patch.object(mujoco,'mj_step1',no_step), patch.object(mujoco,'mj_step2',no_step):
        plant=replay_plant(config,yard,bounds,stage/'scene')
        geometry=geometry_helper.robot_geometry_checks(models,plant.model,mujoco)
        option=mujoco.MjvOption(); option.geomgroup[3:]=0
        try:
            with mujoco.Renderer(plant.model,height=RENDER_HEIGHT,width=PANEL_WIDTH) as renderer:
                if not args.preview:
                    options=dict(fps=FPS,codec='libx264',macro_block_size=2,quality=None,
                        ffmpeg_log_level='error',ffmpeg_params=['-crf','21','-preset','fast','-threads','2'])
                    writer=imageio.get_writer(video,**options); event_writer=imageio.get_writer(event,**options)
                for number, moment in enumerate(moments):
                    frame, panels=composite(runs,float(moment),plant,renderer,camera,option,viewer,path,trusted)
                    if writer is not None:
                        writer.append_data(frame)
                        if 98.-1e-9 <= moment <= 104.+1e-9: event_writer.append_data(frame)
                    if args.preview or number in (0,30,980,1009,1015,1040,1230,1330):
                        imageio.imwrite(stage/f'pose_{moment:06.2f}s.jpg',frame,quality=95)
                    schedule.append(dict(frame=number,elapsed_time_s=float(moment),panels=panels))
                    if not args.preview and number % 100 == 0:
                        print(json.dumps(dict(frame=number,elapsed_s=float(moment))),flush=True)
        finally:
            if writer is not None: writer.close()
            if event_writer is not None: event_writer.close()
    metadata=dict(iteration='I-82',preview=args.preview,frames=len(moments),fps=FPS,dimensions=[WIDTH,HEIGHT],
        playback_speed=1.,shared_physical_elapsed_time=True,no_progress_rescaling=True,
        no_physics_or_controller_execution=True,raw_model_geometry_checks=geometry,shared_camera=camera_info,
        capacities_m_s=CAPS,actual_end_s={a:float(runs[a]['log']['time_s'][-1]) for a in ARMS},
        nominal_window_s=[0.,133.],event_window_s=[98.,104.],event_uses_identical_full_movie_frames=True,
        source='Exact recorded Gazebo/DART state; MuJoCo visuals only; configuration and robot geometry checked.',
        controller_acceptance_claim=False)
    if not args.preview:
        metadata['video']=decode_sequential(video,stage,len(moments))
        event_check=stage/'event_decode'; event_check.mkdir()
        metadata['event_video']=decode_sequential(event,event_check,61)
    for rel, item in bindings.items():
        if sha(ROOT/rel) != item['sha256']: raise AssertionError('Input changed while rendering: '+rel)
    save(stage/'display_schedule.json',schedule); save(stage/'metadata.json',metadata)
    save(stage/'artifact_manifest.json',dict(files={str(p.relative_to(stage)):dict(bytes=p.stat().st_size,sha256=sha(p))
        for p in sorted(stage.rglob('*')) if p.is_file() and 'scene' not in p.relative_to(stage).parts},no_physics=True))
    print(json.dumps(dict(preview=args.preview,frames=len(moments),video=str(video) if not args.preview else None,
                         event_video=str(event) if not args.preview else None)),flush=True)


if __name__ == '__main__': main()
