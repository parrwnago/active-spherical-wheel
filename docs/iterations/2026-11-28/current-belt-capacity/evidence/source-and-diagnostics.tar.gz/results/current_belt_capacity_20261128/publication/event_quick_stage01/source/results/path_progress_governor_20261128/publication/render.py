"""I78 saved-state comparison videos on one shared physical elapsed clock.

Recorded Gazebo/DART poses are rendered with the trusted MuJoCo Mars viewer.
No controller, observer, replay integration, time warping or progress alignment.
Inputs must be closed and covered by the final six-case output seal.
"""
from datetime import datetime,timezone
from pathlib import Path
from unittest.mock import patch
import argparse
import hashlib
import importlib.util
import json
import math
import os
import shutil
import sys
os.environ.setdefault('MUJOCO_GL','egl')
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parents[1]
OLD=ROOT/'results/tangent_heading_routes_20261127'
TRUSTED=OLD/'publication/video_tools/render.py'
FPS=10
WIDTH,HEIGHT=1600,960
PANEL_WIDTH,RENDER_HEIGHT=800,500
METHODS=('N','G')
PHASES=dict(m100=-1.,p030=.3,p090=.9)
LABELS=dict(N='Original native baseline (N)',G='Managed path progress (G)')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def safe(value):
    if isinstance(value,dict):return{str(k):safe(v)for k,v in value.items()}
    if isinstance(value,(tuple,list)):return[safe(v)for v in value]
    if isinstance(value,np.ndarray):return safe(value.tolist())
    if isinstance(value,np.generic):return safe(value.item())
    if isinstance(value,Path):return str(value)
    if isinstance(value,float)and not np.isfinite(value):return None
    return value
def save(path,value):
    with Path(path).open('x')as f:json.dump(safe(value),f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m
def case_paths(base,case_id):
    parent=case_id[:-1]+'N';case=base/'campaign/runs'/case_id
    folder=case/'child/campaign/runs'/parent
    return dict(case=case,folder=folder,precision=folder/'precision.npz',rollout=folder/'rollout.npz',
        summary=folder/'summary.json',provenance=folder/'provenance.json',
        config=folder/'source_snapshot/config/model.yaml',sidecar=case/'governor_diagnostics.npz',
        outcome=case/'i78_outcome.json',prefix=case/'precision_prefix_receipt.json')

def verify_output_seal(base,seal_path):
    protocol_path=base/'protocol/protocol.json';protocol=json.loads(protocol_path.read_text())
    seal=json.loads(seal_path.read_text())
    if protocol['iteration']!='I-78' or seal['protocol_sha256']!=sha(protocol_path):
        raise ValueError('Final I78 protocol/output seal required')
    jobs=protocol['cases'];expected={f'straight_{phase}_{method}'for phase in PHASES for method in METHODS}
    if {j['case_id']for j in jobs}!=expected or len(jobs)!=6:raise ValueError('All six registered cases required')
    files=seal['files']
    for relative,bound in files.items():
        path=(base/relative).resolve()
        if not path.is_relative_to(base):raise ValueError('Sealed path escapes experiment')
        if sha(path)!=bound['sha256']or path.stat().st_size!=bound['bytes']:
            raise ValueError('Sealed output changed: '+relative)
    if 'campaign/launch_completed.json'not in files:raise ValueError('Sealed observed process receipt required')
    processes=json.loads((base/'campaign/launch_completed.json').read_text())
    rows=processes['observed_processes']
    if (seal['observed_return_codes_all_zero']is not True or processes['all_returned_zero']is not True
        or processes['protocol_sha256']!=sha(protocol_path)
        or {p['case_id']for p in rows}!=expected or len(rows)!=6 or any(p['returncode']!=0 for p in rows)
        or {p['case_id']for p in seal['cases']}!=expected):
        raise ValueError('All six processes must have observed successful exits before rendering')
    for case_id in expected:
        paths=case_paths(base,case_id)
        for key in ('precision','rollout','summary','provenance','sidecar','outcome','prefix'):
            if str(paths[key].relative_to(base))not in files:
                raise ValueError('Final seal lacks required render input: '+case_id+'/'+key)
    return protocol,dict(passed=True,protocol_sha256=sha(protocol_path),
        output_seal_sha256=sha(seal_path),verified_sealed_files=len(files),
        observed_processes=len(rows),scope='Closed output integrity, not controller acceptance.')

def register_before_arrays(base,stage,seal_path):
    protocol,verification=verify_output_seal(base,seal_path)
    stage.mkdir(parents=True,exist_ok=False)
    dependencies=[Path(__file__).resolve(),TRUSTED,OLD/'runtime/route.py',base/'protocol/protocol.json',seal_path,
        base/'campaign/launch_completed.json',
        ROOT/'src/spherical_wheel/offroad_view.py',ROOT/'src/spherical_wheel/gazebo/mars_compare.py',
        ROOT/'src/spherical_wheel/gazebo/mars.py',ROOT/'src/spherical_wheel/offroad.py',
        ROOT/'src/spherical_wheel/model.py',ROOT/'src/spherical_wheel/sim.py',ROOT/'src/spherical_wheel/terrain.py']
    yard=ROOT/'assets/gazebo/third_party/leo_simulator-ros2/leo_gz_worlds/models/marsyard2021_terrain'
    dependencies += [yard/'dem/marsyard_terrain_hm.tif',*[yard/'meshes'/f'{n}.obj'for n in ('lava','rocks_big','rocks_medium')]]
    raw_models={}
    for job in protocol['cases']:
        paths=case_paths(base,job['case_id'])
        dependencies += [paths[key]for key in ('precision','rollout','summary','provenance','config','sidecar','outcome','prefix')]
        provenance=json.loads(paths['provenance'].read_text())
        raw_models[job['case_id']]={}
        for name in ('mirror_xml','physical_sdf'):
            path=Path(provenance['models'][name]).resolve()
            if not path.is_relative_to(paths['case']):raise ValueError('Raw model path escapes case')
            dependencies.append(path);raw_models[job['case_id']][name]=str(path)
    bindings={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(set(dependencies))}
    for p in dependencies:
        if p.suffix=='.py':
            target=stage/'source'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    save(stage/'registered_before_arrays_and_render.json',dict(iteration='I-78',
        utc=datetime.now(timezone.utc).isoformat(),files=bindings,raw_model_paths=raw_models,
        planned_camera=dict(azimuth_deg=23.,elevation_deg=-32.,
            extent_policy='One fixed camera covers all six sealed actual paths and the shared complete geometry; no favorable crop or body stabilization.'),
        playback=dict(fps=FPS,speed=1.,clock='Same physical elapsed seconds in both panels; never align or normalize progress.',
            endpoints='After each actual endpoint, freeze only the last recorded pose/reference/telemetry and display RUN ENDED. No later simulation is claimed.'),
        no_physics_or_control_execution=True,source='Recorded Gazebo/DART state; MuJoCo visuals only.',
        registration_scope='Source/metadata read and file hashing only before this receipt; no case arrays loaded.'))
    save(stage/'output_seal_verification.json',verification)
    return protocol,bindings,raw_models

def load_runs(base,protocol,trusted):
    runs={}
    for job in protocol['cases']:
        case_id=job['case_id'];paths=case_paths(base,case_id)
        with np.load(paths['precision'],allow_pickle=False)as z:
            log={k:z[v].copy()for k,v in dict(time_s='time_s',qpos='exact_qpos',qvel='exact_qvel',
                reference_xy='exact_reference_xy',reference_quat='exact_reference_quat',
                requested='exact_requested',bounds='exact_input_bounds',held='command_held_after_row').items()}
        with np.load(paths['rollout'],allow_pickle=False)as z:
            for key in ('time_s','qpos','qvel','reference_xy'):
                if not np.array_equal(z[key],log[key].astype(z[key].dtype)):
                    raise ValueError('Float32 rollout differs from corresponding exact record: '+case_id+'/'+key)
            log['ground_height_m']=z['ground_height_m'].astype(float)
        with np.load(paths['sidecar'],allow_pickle=False)as z:
            np.testing.assert_array_equal(z['time_s'],log['time_s'])
            for key in ('gov__progress_u','gov__virtual_time_s','gov__clock_rate','gov__reference_complete'):
                log[key]=z[key].copy()
        if not np.isfinite(np.r_[log['time_s'],log['qpos'].ravel(),log['qvel'].ravel()]).all():
            raise ValueError('Cannot render nonfinite recorded state')
        signals=trusted.orientation_signals(log['qpos'],log['qvel'],log['reference_quat'])
        signals['tilt_peak_so_far_deg']=np.maximum.accumulate(signals['tilt_deg'])
        runs[case_id]=dict(case_id=case_id,job=job,paths=paths,log=log,signals=signals,
            outcome=json.loads(paths['outcome'].read_text()))
    return runs

def display_moments(runs,phase):
    end=max(float(runs[f'straight_{phase}_{method}']['log']['time_s'][-1])for method in METHODS)
    # A uniform elapsed-time grid; a final fractional gap is visibly unavailable,
    # never compressed into a faster progress-matched final segment.
    steps=int(math.ceil(end*FPS-1e-7))
    return np.arange(steps+1,dtype=float)/FPS

def robot_geometry_checks(raw_models,display_model,mujoco):
    checks={}
    for case_id,paths in raw_models.items():
        raw=mujoco.MjModel.from_xml_path(paths['mirror_xml'])
        if (raw.nq,raw.nv)!=(display_model.nq,display_model.nv):raise ValueError('Recorded/display state dimensions differ')
        fork=mujoco.mj_name2id(raw,mujoco.mjtObj.mjOBJ_BODY,'fork');bodies=[]
        for i in range(raw.nbody):
            parent=i
            while parent>0 and parent!=fork:parent=int(raw.body_parentid[parent])
            if parent==fork:bodies.append(i)
        if not bodies:raise ValueError('Recorded robot subtree not found')
        geometry_count=0
        for i in bodies:
            name=mujoco.mj_id2name(raw,mujoco.mjtObj.mjOBJ_BODY,i)
            j=mujoco.mj_name2id(display_model,mujoco.mjtObj.mjOBJ_BODY,name)
            if j<0:raise ValueError('Display lacks recorded robot body: '+name)
            for field in ('body_pos','body_quat','body_ipos','body_iquat','body_mass','body_inertia'):
                np.testing.assert_array_equal(getattr(raw,field)[i],getattr(display_model,field)[j])
            for geom in np.flatnonzero(raw.geom_bodyid==i):
                name=mujoco.mj_id2name(raw,mujoco.mjtObj.mjOBJ_GEOM,int(geom))
                other=mujoco.mj_name2id(display_model,mujoco.mjtObj.mjOBJ_GEOM,name)
                if other<0:raise ValueError('Display lacks recorded robot geom: '+name)
                for field in ('geom_type','geom_size','geom_pos','geom_quat'):
                    np.testing.assert_array_equal(getattr(raw,field)[geom],getattr(display_model,field)[other])
                geometry_count+=1
        checks[case_id]=dict(passed=True,robot_bodies=len(bodies),robot_geoms=geometry_count,
            raw_model_sha256=sha(paths['mirror_xml']),state_dimensions=[raw.nq,raw.nv],
            scope='Named robot body/geom geometry and inertial parameters, excluding terrain/display feature bodies.')
    return checks

def composite(runs,phase,moment,plant,renderer,camera,option,viewer,path,trusted):
    from PIL import Image,ImageDraw
    image=Image.new('RGB',(WIDTH,HEIGHT),(13,21,31));draw=ImageDraw.Draw(image)
    draw.text((22,12),f'I-78 | straight | phase {PHASES[phase]:+.1f} rad | shared elapsed t = {moment:06.2f} s | 1x',font=trusted.font(25),fill='white')
    draw.text((22,47),'Recorded Gazebo / DART dynamics. Original LQR + momentum observer; only path timing differs.',font=trusted.font(19),fill=(186,199,211))
    schedule=[];goal=path(path.start_s+path.duration_s)[0]
    for col,method in enumerate(METHODS):
        run=runs[f'straight_{phase}_{method}'];log=run['log'];signals=run['signals']
        sample=trusted.display_sample(log['time_s'],moment);index=sample['pose_index'];ended=sample['run_ended_pose_frozen']
        pixels=viewer._draw(plant,renderer,log,index,camera,option,True)
        left=col*PANEL_WIDTH;image.paste(Image.fromarray(pixels),(left,80));draw=ImageDraw.Draw(image)
        draw.rectangle((left,80,left+PANEL_WIDTH-1,115),fill=(15,24,34))
        draw.text((left+14,84),LABELS[method],font=trusted.font(24),fill='white')
        if ended:
            draw.rectangle((left+8,180,left+PANEL_WIDTH-8,249),fill=(114,24,28))
            draw.text((left+18,189),f'RUN ENDED at {log["time_s"][-1]:.3f} s; pose frozen',font=trusted.font(20),fill='white')
            reason=run['outcome'].get('native_failure')or('reference / hold recorded'if run['outcome']['diagnostic_completed']else'budget or reference hold incomplete')
            draw.text((left+18,220),reason[:65],font=trusted.font(17),fill='white')
        position=log['qpos'][index,:2];error=1000*np.linalg.norm(position-log['reference_xy'][index])
        goal_error=1000*np.linalg.norm(position-goal);relative=position-path.origin
        cross=1000*abs(float(relative@np.array([-path.direction[1],path.direction[0]])))
        physical_progress=100*float(relative@path.direction)/1.2
        virtual=float(log['gov__virtual_time_s'][index]);rate=float(log['gov__clock_rate'][index])
        requested=float(np.max(abs(log['requested'][index])/log['bounds'][index]))
        lines=[f'Recorded pose time: {log["time_s"][index]:6.3f} s',
            f'Reference / physical along-path: {100*log["gov__progress_u"][index]:6.2f}% / {physical_progress:6.2f}%',
            f'Virtual clock: {virtual:6.2f} s | clock rate: {rate:5.2f}',
            f'Goal / cross-track / ref error: {goal_error:6.1f} / {cross:5.1f} / {error:5.1f} mm',
            f'Body tilt now / peak so far: {signals["tilt_deg"][index]:5.2f} / {signals["tilt_peak_so_far_deg"][index]:5.2f} deg',
            f'Ref lean / up-vector error: {signals["reference_lean_deg"][index]:5.2f} / {signals["reference_up_error_deg"][index]:5.2f} deg',
            f'XY speed: {np.linalg.norm(log["qvel"][index,:2]):.3f} m/s | request / cap max: {requested:.2f}']
        for number,line in enumerate(lines):draw.text((left+14,593+number*29),line,font=trusted.font(20),fill=(230,235,241))
        terminal=index==len(log['time_s'])-1
        status=('Last emitted command UNHELD; no later physics.'if terminal else'Current emitted command acts after the recorded state.')
        draw.text((left+14,805),status,font=trusted.font(17),fill=(224,183,110))
        if col:draw.line((left,80,left,840),fill=(81,94,105),width=2)
        schedule.append(dict(case_id=run['case_id'],**sample,reference_progress=float(log['gov__progress_u'][index]),
            physical_progress_percent=physical_progress,reference_marker_xy_m=log['reference_xy'][index],
            terminal_command_unheld=terminal))
    draw.text((22,857),'Orange: each method\'s actual reference + shared geometric path | Cyan: recorded wheel-centre trail.',font=trusted.font(20),fill=(236,190,114))
    draw.text((22,892),'Both panels use the same physical elapsed time. An ended panel stays visibly frozen; delay is not rescaled.',font=trusted.font(20),fill=(186,199,211))
    draw.text((22,929),'MuJoCo visuals only: no controller, observer or physics replay. I-78 completion and controller acceptance are separate.',font=trusted.font(17),fill=(166,180,193))
    return np.asarray(image),schedule

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--base',type=Path,default=BASE)
    parser.add_argument('--phase',choices=PHASES,required=True);parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--input-seal',type=Path,required=True);parser.add_argument('--preview',action='store_true')
    args=parser.parse_args();base=args.base.resolve();stage=args.stage.resolve()
    protocol,bindings,raw_models=register_before_arrays(base,stage,args.input_seal.resolve())
    trusted=module(TRUSTED,'_i78_trusted_video_helpers');runs=load_runs(base,protocol,trusted)
    routes=module(OLD/'runtime/route.py','_i78_recorded_route');path=routes.make_route('straight')
    planned=routes.samples('straight')['xy_m']
    for run in runs.values():run['log']['planned_xy']=planned[::4]
    points=np.concatenate([planned,*[r['log']['qpos'][:,:2]for r in runs.values()],
                           *[r['log']['reference_xy']for r in runs.values()]])
    low,high=points.min(axis=0),points.max(axis=0);middle=.5*(low+high)
    bounds=(float(low[0]-.6),float(high[0]+.6),float(low[1]-.6),float(high[1]+.6))
    from spherical_wheel.gazebo.mars import MarsYard
    from spherical_wheel.gazebo.mars_compare import replay_plant
    from spherical_wheel import offroad_view as viewer
    import mujoco,yaml,imageio.v2 as imageio
    config_hashes={sha(r['paths']['config'])for r in runs.values()}
    if len(config_hashes)!=1:raise ValueError('Recorded robot configurations differ; cannot share a render model')
    yard=MarsYard();span=float(np.max(high-low)+.4)
    camera_info=dict(lookat=[float(middle[0]),float(middle[1]),float(yard.height(*middle)+.08)],
        azimuth_deg=23.,elevation_deg=-32.,distance_m=max(2.,1.6*span),
        full_actual_and_reference_bounds_xy_m=[low[0],high[0],low[1],high[1]],
        render_terrain_bounds_xy_m=bounds,all_six_paths_included=True)
    camera=viewer._camera(camera_info['lookat'],23.,-32.,camera_info['distance_m'])
    camera_info['actual_lookat_m']=camera.lookat.copy()
    config=yaml.safe_load(next(iter(runs.values()))['paths']['config'].read_text())
    def no_step(*args,**kwargs):raise AssertionError('Rendering attempted dynamics integration')
    schedule=[];video=stage/f'straight_{args.phase}_N_G.mp4';writer=None
    moments=display_moments(runs,args.phase)
    if args.preview:
        sample_times=[0.,3.,20.5,35.,45.,min(45.1,float(moments[-1])),float(moments[-1])]
        moments=np.unique(np.clip(sample_times,0.,float(moments[-1])))
    with patch.object(mujoco,'mj_step',no_step),patch.object(mujoco,'mj_step1',no_step),patch.object(mujoco,'mj_step2',no_step):
        plant=replay_plant(config,yard,bounds,stage/'scene')
        geometry=robot_geometry_checks(raw_models,plant.model,mujoco)
        option=mujoco.MjvOption();option.geomgroup[3:]=0
        try:
            with mujoco.Renderer(plant.model,height=RENDER_HEIGHT,width=PANEL_WIDTH)as renderer:
                if not args.preview:
                    writer=imageio.get_writer(video,fps=FPS,codec='libx264',macro_block_size=2,quality=None,
                        ffmpeg_log_level='error',ffmpeg_params=['-crf','21','-preset','fast','-threads','2'])
                for number,moment in enumerate(moments):
                    frame,panels=composite(runs,args.phase,float(moment),plant,renderer,camera,option,viewer,path,trusted)
                    if writer is not None:writer.append_data(frame)
                    if args.preview or number in (0,30,450,451,len(moments)//2,len(moments)-1):
                        imageio.imwrite(stage/f'pose_{moment:06.2f}s.jpg',frame,quality=95)
                    schedule.append(dict(frame=number,elapsed_time_s=float(moment),panels=panels))
        finally:
            if writer is not None:writer.close()
    metadata=dict(iteration='I-78',phase=args.phase,phase_rad=PHASES[args.phase],methods=METHODS,
        preview=args.preview,fps=FPS,dimensions=[WIDTH,HEIGHT],frames=len(moments),playback_speed=1.,
        shared_physical_elapsed_clock=True,no_progress_rescaling=True,no_physics_or_controller_execution=True,
        raw_model_geometry_checks=geometry,shared_camera=camera_info,
        actual_end_s={method:float(runs[f'straight_{args.phase}_{method}']['log']['time_s'][-1])for method in METHODS},
        complete_reference_and_hold={method:runs[f'straight_{args.phase}_{method}']['outcome']['diagnostic_completed']for method in METHODS},
        renderer='Recorded exact Gazebo/DART qpos, MuJoCo visuals compiled from each byte-identical captured model configuration; every raw mirror robot subtree checked.',
        terrain='Original Mars DEM and feature meshes; display reconstruction is not a collision or contact prediction.',
        ended_panel_policy='Freeze actual last pose, reference and telemetry after its recorded endpoint, with red RUN ENDED banner and recorded pose timestamp. Global elapsed time continues.',
        reference_marker='Each pane uses its own recorded reference. Full geometric path/goal is shared; no future reference/physical motion is invented after termination.',
        command_timing='Emitted current command follows recorded state; final emitted command is unheld.',
        controller_acceptance_claim=False)
    if not args.preview:metadata['video']=trusted.decode_sequential(video,stage,len(moments))
    for rel,bound in bindings.items():
        if sha(ROOT/rel)!=bound['sha256']:raise AssertionError('Render input/source changed: '+rel)
    save(stage/'display_schedule.json',schedule);save(stage/'metadata.json',metadata)
    save(stage/'artifact_manifest.json',dict(files={str(p.relative_to(stage)):
        dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(stage.rglob('*'))
        if p.is_file()and'scene'not in p.relative_to(stage).parts},no_physics=True))
    print(json.dumps(dict(phase=args.phase,preview=args.preview,frames=len(moments),
        video=str(video)if not args.preview else None,stage=str(stage))),flush=True)

if __name__=='__main__':main()
