"""Package closed I82 movies/figures with an exact manifest; no numerical work."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[3]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--video-stage',type=Path,required=True)
    ap.add_argument('--evaluation-stage',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();video=args.video_stage.resolve();evaluation=args.evaluation_stage.resolve();out=args.output.resolve()
    if out.exists():raise FileExistsError(out)
    metadata=json.loads((video/'metadata.json').read_text())
    assert metadata['iteration']=='I-82' and metadata['preview'] is False
    assert metadata['video']['all_frames_decoded'] and metadata['event_video']['all_frames_decoded']
    selected={}
    for name in ['eight_m100_B030_B060.mp4','event_98_104_B030_B060.mp4','metadata.json',
                 'registered_before_arrays_and_render.json','output_seal_verification.json','display_schedule.json']:
        selected['video/'+name]=video/name
    for name in ['pose_000.00s.jpg','pose_100.90s.jpg','pose_101.50s.jpg','pose_123.00s.jpg','pose_133.00s.jpg']:
        if (video/name).exists():selected['video/'+name]=video/name
    for p in sorted(evaluation.iterdir()):
        if p.is_file() and p.suffix in {'.pdf','.png','.md'}:
            selected['evaluation/'+p.name]=p
    for name in ['report.json','registered_before_arrays.json','artifact_manifest.json']:
        if (evaluation/name).exists():selected['evaluation/'+name]=evaluation/name
    base = evaluation.parent.parent
    for name in ['report.json', 'summary.md', 'registered_before_arrays.json']:
        p = evaluation.parent/'force_stage01'/name
        if p.exists(): selected['evaluation/force_'+name] = p
    for audit in ['pair_stage01', 'trace_B030_stage01', 'trace_B060_stage01', 'headlines_stage01']:
        for name in ['report.json', 'artifact_manifest.json']:
            p = base/'verification'/audit/name
            if p.exists(): selected['verification/'+audit+'/'+name] = p
    selected['source/render_stage02.py']=Path(__file__).resolve().parent/'render_stage02.py'
    selected['source/assemble_visual_bundle.py']=Path(__file__).resolve()
    selected['README.md']=Path(__file__).resolve().parent/'README.md'
    bindings={name:dict(source=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for name,p in selected.items()}
    out.mkdir(parents=True)
    save(out/'registered_before_packaging.json',dict(iteration='I-82',utc=datetime.now(timezone.utc).isoformat(),
        scope='Closed visual evidence only; no simulations, array reduction or outcome selection.',files=bindings))
    for name,p in selected.items():
        q=out/'bundle'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
        assert sha(q)==bindings[name]['sha256']
    manifest=out/'bundle/manifest.json';save(manifest,dict(iteration='I-82',files=bindings,
        physics='Recorded Gazebo/DART, MuJoCo display only',playback='Shared physical elapsed time at 1x, 10 fps; event clip uses identical full-video frames over 98–104 s.'))
    archive=out/'I82-visual-comparison.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted((out/'bundle').rglob('*')):
            if p.is_file():z.write(p,p.relative_to(out/'bundle').as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(bindings)|{'manifest.json'}
        for name,item in bindings.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
    assert all(sha(selected[name])==item['sha256'] for name,item in bindings.items())
    save(out/'report.json',dict(iteration='I-82',archive=str(archive.relative_to(ROOT)),bytes=archive.stat().st_size,
        sha256=sha(archive),members=len(bindings)+1,all_members_crc_and_sha256_verified=True,
        inputs_unchanged=True,no_new_physics=True))
    print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),members=len(bindings)+1)))


if __name__=='__main__':main()
