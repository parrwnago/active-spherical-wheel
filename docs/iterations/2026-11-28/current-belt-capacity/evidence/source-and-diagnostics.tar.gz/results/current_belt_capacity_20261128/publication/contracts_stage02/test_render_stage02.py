"""Pure I82 presentation contracts; no case arrays, rendering or physics."""
from pathlib import Path
from unittest.mock import patch
import tempfile
import unittest
import json
import numpy as np
import render_stage02 as render


class PresentationContracts(unittest.TestCase):
    def test_full_and_event_use_identical_physical_grid(self):
        full=render.display_moments()
        event=render.display_moments(98.,104.)
        np.testing.assert_array_equal(full,np.arange(1331)/10)
        np.testing.assert_array_equal(event,full[980:1041])
        self.assertEqual(len(event),61)

    def test_fractional_or_invalid_window_is_not_silently_rescaled(self):
        for limits in [(-1.,1.),(2.,1.),(0.,float('nan')),(0.,133.015)]:
            with self.assertRaises(ValueError):render.display_moments(*limits)

    def test_ended_panel_freezes_at_recorded_endpoint(self):
        trusted=render.module(render.TRUSTED,'_i82_contract_time_helpers')
        ended=trusted.display_sample(np.array([0.,50.]),101.5)
        live=trusted.display_sample(np.array([0.,50.,101.5,133.]),101.5)
        self.assertTrue(ended['run_ended_pose_frozen'])
        self.assertEqual(ended['recorded_pose_time_s'],50.)
        self.assertFalse(ended['simulation_state_available'])
        self.assertEqual(live['recorded_pose_time_s'],101.5)
        self.assertEqual(ended['requested_time_s'],live['requested_time_s'])

    def test_decoder_uses_the_new_caption_canvas_dimensions(self):
        import imageio_ffmpeg
        with tempfile.TemporaryDirectory() as name:
            stage=Path(name); video=stage/'fixture.mp4'; video.write_bytes(b'fake-fixture-bytes')
            def fake_frames(*args,**kwargs):
                yield dict(size=(1600,1010),fps=10.,duration=.1)
                yield bytes(1600*1010*3)
            with patch.object(imageio_ffmpeg,'read_frames',fake_frames):
                result=render.decode_sequential(video,stage,1)
            self.assertEqual(result['decoded_frames'],1)
            self.assertTrue(result['all_frames_decoded'])

    def test_unobserved_process_set_rejected_before_arrays(self):
        with tempfile.TemporaryDirectory() as name:
            base=Path(name);protocol=base/'protocol.json';seal=base/'seal.json'
            protocol.write_text(json.dumps({'iteration':'I-82'}))
            seal.write_text(json.dumps({'iteration':'I-82','protocol_sha256':render.sha(protocol),'files':{}}))
            with patch.object(np,'load',side_effect=AssertionError('No arrays before observed exits')):
                with self.assertRaisesRegex(ValueError,'process exits'):
                    render.verify_seal(base,seal,protocol,{})


if __name__=='__main__':unittest.main()
