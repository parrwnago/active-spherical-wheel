"""Package CLOSED I82 evidence; never runs physics or changes trial artifacts."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import io
import json
import tarfile
import traceback

ROOT = Path(__file__).resolve().parents[4]
BASE = Path(__file__).resolve().parents[2]
ASSET_EXTENSIONS = {'.obj', '.stl', '.mtl', '.png', '.jpg', '.jpeg', '.tif', '.tiff', '.mjb'}
SUPPLEMENTAL_ALLOWED_SHA = {
    'results/tangent_heading_routes_20261127/evaluation/metrics.py':
        'ca4b71dc840c53f0bd59e38f60643500a3d1fb0bdab50d5ee062832cf130b4c1',
    'results/slope_response_trace_20261128/analysis/core.py':
        'd2f063d5edbabe40b50bac94b9407c080d08bd2e1e3e5fc6d9aa23763809387f',
    'results/tangent_heading_routes_20261127/publication/video_tools/render.py':
        '672a041f21cb70fa7f57d2d99b51e9ffd05d033fa8dff057397592c04c462ce1',
    'results/path_progress_governor_20261128/publication/render.py':
        '182e5efd52573437bdba36f3ec72d30617c18d6e9d5fdd706f2ab1f9840179e3',
}
SUPPLEMENTAL_REGISTRATIONS = (
    ('evaluation/dependency_closure_stage01/dependency_registration.json', 'files'),
    ('evaluation/force_stage01/registered_before_arrays.json', 'source_and_inputs'),
    ('publication/video_stage01/registered_before_arrays_and_render.json', 'files'),
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()


def write_new(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encode(value))


def relative_file(root, path):
    path = Path(path)
    if path.is_symlink():
        raise ValueError('Archive inputs must be regular captured files, not symlinks: '+str(path))
    relative = path.resolve().relative_to(Path(root).resolve())
    if not path.is_file():
        raise ValueError('Archive input missing: '+str(path))
    if any('credential' in part.lower() for part in relative.parts):
        raise ValueError('Credential paths are outside archive scope')
    return relative


def excluded_reason(path, base, output):
    path = Path(path)
    relative = path.relative_to(base)
    if path == output or output in path.parents:
        return 'Current archive construction/output; exclude recursion and mutable receipt files.'
    if 'curation' in relative.parts:
        return 'Repository compact-evidence packaging helper/output, separate from closed scientific trial.'
    if any(part in {'__pycache__', '.pytest_cache'} for part in relative.parts) or path.suffix == '.pyc':
        return 'Rebuildable interpreter/test cache.'
    if path.name.endswith(('.tar.gz', '.tgz', '.zip', '.tar')):
        return 'Existing generated archive; avoid archive recursion, captured contents are independently included.'
    if any(part.startswith('visual_bundle') for part in relative.parts):
        if path.suffix.lower() in {'.json', '.md'}:
            return None
        return 'Duplicate portable visual-bundle staging; original movies and their closed media/source metadata are included directly.'
    if any(part in {'_replay_scenes', 'render_cache', 'scene_cache', 'scene'} for part in relative.parts):
        return 'Rebuildable render scene/cache; recorded videos and their metadata are retained separately.'
    if '_workspaces' in relative.parts and path.suffix.lower() in ASSET_EXTENSIONS:
        return 'Repeated generated workspace terrain/mesh/visual/compiled-model asset; original registered assets and model/config sources are included.'
    return None


def select_files(root, base, output, prerequisites):
    """Walk only I82 and exact registered paths, never the rest of the workspace."""
    selected, excluded = {}, {}
    for path in sorted(Path(base).rglob('*')):
        if not path.is_file() and not path.is_symlink():
            continue
        relative = relative_file(root, path)
        reason = excluded_reason(path, Path(base), Path(output))
        if reason is None:
            selected[str(relative)] = path
        elif 'Current archive construction/output' not in reason:
            excluded[str(relative)] = (path, reason)
    # Exact registered sources/inputs always win over generated-asset filtering.
    for name in prerequisites:
        path = Path(root)/name
        relative = relative_file(root, path)
        selected[str(relative)] = path
        excluded.pop(str(relative), None)
    return selected, excluded


def bindings(protocol):
    result = {}
    for key in ('source_sha256', 'input_sha256'):
        for name, value in protocol[key].items():
            if name in result and result[name] != value:
                raise ValueError('Conflicting source/input hash: '+name)
            result[name] = value
    return result


def check_registered(root, protocol):
    expected = bindings(protocol)
    for name, value in expected.items():
        path = Path(root)/name
        relative_file(root, path)
        if sha(path) != value:
            raise AssertionError('Registered source/input changed: '+name)
    return expected


def check_supplemental(root, base, protocol):
    """Restore exact external analysis/media sources at original relative paths.

    Only three explicitly named CLOSED registrations are inspected. This is not
    a broad dependency scan. Physical protocol counts remain unchanged.
    """
    original = bindings(protocol)
    extra, registered_by = {}, {}
    base_relative = str(Path(base).resolve().relative_to(Path(root).resolve())) + '/'
    receipts = []
    for relative, key in SUPPLEMENTAL_REGISTRATIONS:
        receipt = Path(base) / relative
        relative_file(root, receipt)
        document = json.loads(receipt.read_text())
        if document.get('iteration') != 'I-82':
            raise ValueError('Supplemental I82 registration required')
        receipts.append(dict(source=str(receipt.relative_to(root)), sha256=sha(receipt)))
        for name, item in document[key].items():
            expected = item if isinstance(item, str) else item['sha256']
            if name in original or name.startswith(base_relative):
                continue
            if name not in SUPPLEMENTAL_ALLOWED_SHA:
                raise ValueError('Unknown external supplemental dependency requires explicit review: '+name)
            if expected != SUPPLEMENTAL_ALLOWED_SHA[name]:
                raise AssertionError('Supplemental registration differs from expected historical source: '+name)
            path = Path(root) / name
            relative_file(root, path)
            if sha(path) != expected:
                raise AssertionError('Supplemental registered source changed: '+name)
            extra[name] = expected
            registered_by.setdefault(name, []).append(str(receipt.relative_to(root)))
    if set(extra) != set(SUPPLEMENTAL_ALLOWED_SHA):
        raise AssertionError('Supplemental dependency set incomplete')
    inventory = dict(iteration='I-82', scope='Analysis/media-only external dependencies already registered by closed stages; physical93-source/59-input protocol is unchanged.',
        registration_receipts=receipts,
        files=[dict(source=name, sha256=value, archive_path='project/'+name,
                    registered_by=registered_by[name]) for name, value in sorted(extra.items())])
    return extra, inventory


def check_seal(seal_path, seal_base):
    seal = json.loads(Path(seal_path).read_text())
    if seal.get('iteration') != 'I-82' or not isinstance(seal.get('files'), dict):
        raise ValueError('I82 closed-output files mapping required')
    for name, expected in seal['files'].items():
        path = Path(seal_base)/name
        if sha(path) != expected['sha256'] or path.stat().st_size != expected['bytes']:
            raise AssertionError('Sealed output changed: '+name)
    return seal


def check_media_manifest(path):
    path = Path(path)
    manifest = json.loads(path.read_text())
    if not isinstance(manifest.get('files'), dict):
        raise ValueError('Closed media artifact files mapping required')
    required = {'eight_m100_B030_B060.mp4', 'event_98_104_B030_B060.mp4'}
    if not required.issubset(manifest['files']):
        raise AssertionError('Full-route and event movies missing from closed media manifest')
    for name, expected in manifest['files'].items():
        file = path.parent / name
        relative_file(ROOT, file)
        if sha(file) != expected['sha256'] or file.stat().st_size != expected['bytes']:
            raise AssertionError('Closed media changed: '+name)
    return manifest


def fixed_info(info):
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    info.mtime = 0
    return info


def stream_verify(archive, expected):
    """Read every regular member in one decompression pass and check exact set."""
    seen = set()
    with tarfile.open(archive, 'r|gz') as tf:
        for member in tf:
            if not member.isfile() or member.name in seen or member.name not in expected:
                raise AssertionError('Unexpected/duplicate/nonregular archive member: '+member.name)
            seen.add(member.name)
            h = hashlib.sha256()
            stream = tf.extractfile(member)
            for block in iter(lambda: stream.read(1024*1024), b''):
                h.update(block)
            record = expected[member.name]
            if member.size != record['bytes'] or h.hexdigest() != record['sha256']:
                raise AssertionError('Member digest mismatch: '+member.name)
    if seen != set(expected):
        raise AssertionError('Archive member set incomplete')
    return len(seen)


REPRODUCE = '''# I-82 full closed capacity-comparison evidence archive

This preserves two newly recorded Gazebo/DART executions of the same I76
figure-eight, shaft start -1 rad, yaw158 degrees, original133-second reference:
B030 uses0.30 m/s and B060 uses0.60 m/s operating limits on both belts. The
original0.30 design/configuration, gain bank, torque limits, observer and
controller algorithms remain fixed. Operating caps change after design
construction in both physical plant and measured-state mirror. Native incoming
preparation sees those caps too; this is not a final-clipping-only intervention.

Full-route completion, process completion and acceptance are distinct. B030
must reproduce all79 original precision fields through26,601 rows exactly.
B060 can legitimately stop early for a native physical failure; its arrays,
actual end and failure record remain included. A finished process does not
make an early physical stop successful. Higher-cap histories can diverge well
before the user's101.5-second event; this is a whole-run capacity comparison,
not a same-state local counterfactual. No cap/gain tuning follows outcomes.

`project/` holds original repository-relative paths. `_archive/` holds the
pre-archive registration, excluded-file inventory, prerequisite inventory,
this guide and member inventory. Historical absolute paths are preserved;
locate corresponding bytes at project/<repository-relative path>. Restore
captured source at its recorded path for read-only analysis into NEW stages.

All exact sources and inputs from the frozen I82 protocol are included,
including registered original I76 records, terrain/gain/plugin inputs and
runner sources. Original whole-campaign seals may reference unrelated runs;
only listed I82 prerequisites are claimed captured. No virtual environment,
credential helper, unrelated firmware or unrelated user file is included.

Four separately registered analysis/media source dependencies also appear at
their ORIGINAL repository-relative paths: original I76 evaluation/metrics.py,
I81 analysis/core.py, I76 publication/video_tools/render.py and I78 publication/
render.py. Their exact historical hashes and closed registration receipts are
listed in _archive/supplemental_dependencies.json; these are not retroactively
added to the physical experiment's93-source/59-input registration.

Repeated generated workspace mesh/terrain/visual assets, render scene caches,
interpreter caches and prior archives are omitted with path/size/SHA/reason
inventory. Direct physical/model XML/SDF/config files remain included. Exact
registered prerequisites override asset omission. New physics on a rebuilt
environment is not promised bit-identical to the captured recordings.

The completed portable visual ZIP and its closed metadata ARE included as an
explicit exception to prior-archive omission. Duplicate expanded movies/images
inside its staging folder are omitted because canonical media is included.

Start with:

- project/results/current_belt_capacity_20261128/protocol/frozen_stage01/protocol.json
- .../campaign/runs/B030/outcome.json and native_comparison.json
- .../campaign/runs/B060/outcome.json and native_comparison.json
- .../campaign/runs/ARM/child/campaign/runs/eight_m100_N/precision.npz and rollout.npz
- .../campaign/runs/ARM/substeps.npz and capture_receipt.json
- .../evaluation/ or .../analysis/ completed reports and .../verification/
- .../publication/ recorded full-route MP4, event clip and media metadata

Outer I82 arm/cap receipts are authoritative; inner child I76 job/cap labels
are inherited runner metadata. The full video and event clip use the same
physical elapsed time at1x. Recorded Gazebo/DART states use MuJoCo visuals
without replaying physics/controller/observer. A failed or ended panel freezes
visibly at its actual endpoint. Motion and acceptance are not rescaled.

The short100.5–101.8s contact capture splits each originalrun(5) into five
run(1) calls without extra control updates. B030 exact native parity checks
that instrumentation preserves original motion. B060 partial capture is
retained if physical termination precedes its end. Saved contacts are sampled
solver forces, not an exact impulse oracle. Each emitted command acts AFTER
its recorded state; prior held commands correspond to completed forces.

Verify all members against _archive/archive_inventory.json. The inventory
does not list its own digest; adjacent archive_verification.json binds it and
records one complete streaming member-hash verification, unchanged frozen
sources/inputs/output seal and unchanged evidence/omission selection.

Read-only captured-array analysis requires no new physics. Consult each
registered_before_*.json and README for exact commands and use empty output
stages. The runner's --run explicitly launches new physics and is unnecessary
for inspecting this evidence. Do not overwrite closed records.
'''


def check_cases(case030, case060):
    outcomes = []
    capacity_receipts = []
    for arm, path in [('B030', Path(case030)), ('B060', Path(case060))]:
        outcome = json.loads((path/'outcome.json').read_text())
        cap = .3 if arm == 'B030' else .6
        if (outcome.get('iteration') != 'I-82' or outcome.get('arm') != arm or
                outcome.get('cap_m_s') != cap or not outcome.get('runner_recording_completed')):
            raise AssertionError('Closed authoritative I82 arm outcome required: '+arm)
        if arm == 'B030' and (not outcome.get('baseline_parity_passed') or
                not outcome.get('physical_horizon_reached') or outcome.get('recorded_rows') != 26601):
            raise AssertionError('B030 full original79-field133s parity required')
        comparison = json.loads((path/'native_comparison.json').read_text())
        if arm == 'B030':
            if (not comparison.get('baseline_parity_passed') or len(comparison['fields']) != 79
                    or not all(x['bit_exact'] for x in comparison['fields'])):
                raise AssertionError('B030 comparison does not pass every native field')
        elif not all(comparison['physical_observer_prefix_checks'].values()):
            raise AssertionError('B060 state/observer prefix validation failed')
        receipt = json.loads((path/'capacity_receipt.json').read_text())
        if not receipt.get('config_and_design_unchanged'):
            raise AssertionError('Fixed design/configuration identity required')
        expected = [1.5, .6, .6, cap, cap]
        if receipt['physical_operating_bounds'] != expected or receipt['mirror_operating_bounds'] != expected:
            raise AssertionError('Physical/mirror operating caps differ from declared arm')
        if receipt['original_designer_bounds'] != [1.5, .6, .6, .3, .3]:
            raise AssertionError('Original .30 design bounds changed')
        capacity_receipts.append(receipt)
        outcomes.append(outcome)
    for key in ['config_sha256', 'bank_numeric_sha256', 'ordinary_design_sha256', 'bank_file_sha256']:
        if capacity_receipts[0][key] != capacity_receipts[1][key]:
            raise AssertionError('Capacity arms do not share original fixed design/config identity: '+key)
    return outcomes


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--protocol', type=Path, required=True)
    ap.add_argument('--seal', type=Path, required=True)
    ap.add_argument('--seal-base', type=Path, default=BASE)
    ap.add_argument('--observed-exit', type=Path, required=True, action='append')
    ap.add_argument('--case030', type=Path, required=True)
    ap.add_argument('--case060', type=Path, required=True)
    ap.add_argument('--media-manifest', type=Path, required=True)
    ap.add_argument('--visual-bundle', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--build', action='store_true')
    args = ap.parse_args()
    if not args.build:
        raise SystemExit('Explicit --build after root declares science AND media CLOSED')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    try:
        protocol = json.loads(args.protocol.read_text())
        if protocol.get('iteration') != 'I-82':
            raise ValueError('I82 frozen protocol required')
        physical_prerequisites = check_registered(ROOT, protocol)
        supplemental, supplemental_inventory = check_supplemental(ROOT, BASE, protocol)
        expected_prerequisites = dict(physical_prerequisites)
        expected_prerequisites.update(supplemental)
        seal = check_seal(args.seal, args.seal_base)
        if len(args.observed_exit) != 2 or len({p.resolve() for p in args.observed_exit}) != 2:
            raise ValueError('Exactly two actual observed process exits required')
        observed = [json.loads(path.read_text()) for path in args.observed_exit]
        if any(x.get('actual_observed_exit_code') != 0 for x in observed):
            raise AssertionError('Both process return codes must be actual observed zero exits')
        outcomes = check_cases(args.case030, args.case060)
        media = check_media_manifest(args.media_manifest)
        visual_relative = str(relative_file(ROOT, args.visual_bundle))
        if args.visual_bundle.suffix.lower() != '.zip':
            raise ValueError('Explicit closed portable visual ZIP required')
        visual_report_path = args.visual_bundle.parent / 'report.json'
        visual_report = json.loads(visual_report_path.read_text())
        if (visual_report.get('iteration') != 'I-82' or not visual_report.get('all_members_crc_and_sha256_verified')
                or visual_report.get('archive') != visual_relative
                or visual_report.get('sha256') != sha(args.visual_bundle)
                or visual_report.get('bytes') != args.visual_bundle.stat().st_size):
            raise AssertionError('Closed portable visual ZIP differs from verified media report')
        selection_prerequisites = dict(expected_prerequisites)
        selection_prerequisites[visual_relative] = sha(args.visual_bundle)
        selected, excluded = select_files(ROOT, BASE, output, selection_prerequisites)
        movies = [p for p in selected.values() if p.suffix.lower() == '.mp4']
        if len(movies) < 2:
            raise AssertionError('Closed full-route comparison and event-clip MP4s must be included')
        project = [{'source': name, 'archive_path': 'project/'+name,
                    'bytes': path.stat().st_size, 'sha256': sha(path)}
                   for name, path in sorted(selected.items())]
        omissions = [{'source': name, 'bytes': path.stat().st_size,
                      'sha256': sha(path), 'reason': reason}
                     for name, (path, reason) in sorted(excluded.items())]
        external = [{'source': name, 'sha256': value,
                     'archive_path': 'project/'+name, 'inside_I82': BASE in (ROOT/name).parents,
                     'binding_origin': 'physical_protocol' if name in physical_prerequisites else 'supplemental_closed_analysis_media_registration'}
                    for name, value in sorted(expected_prerequisites.items())]
        registration = dict(iteration='I-82', utc=datetime.now(timezone.utc).isoformat(),
            scope='Root declared scientific proof AND media stages closed; packaging only.',
            source=str(Path(__file__).relative_to(ROOT)), source_sha256=sha(Path(__file__)),
            protocol=str(args.protocol.resolve().relative_to(ROOT)), protocol_sha256=sha(args.protocol),
            seal=str(args.seal.resolve().relative_to(ROOT)), seal_sha256=sha(args.seal),
            actual_exits=[dict(path=str(p.resolve().relative_to(ROOT)),sha256=sha(p)) for p in args.observed_exit],
            outcomes=outcomes, media_manifest=str(args.media_manifest.resolve().relative_to(ROOT)),
            media_manifest_sha256=sha(args.media_manifest), included_mp4_count=len(movies),
            visual_bundle=visual_relative, visual_bundle_sha256=sha(args.visual_bundle),
            visual_bundle_report=str(visual_report_path.relative_to(ROOT)), visual_bundle_report_sha256=sha(visual_report_path),
            supplemental_dependency_count=len(supplemental),
            registered_sources=len(protocol['source_sha256']), registered_inputs=len(protocol['input_sha256']),
            sealed_outputs=len(seal['files']), files=project,
            no_new_physics=True, no_new_video=True, no_parameter_changes=True)
        metadata = {
            '_archive/registered_before_archive.json': encode(registration),
            '_archive/excluded_files.json': encode({'iteration': 'I-82', 'files': omissions}),
            '_archive/external_prerequisites.json': encode({'iteration': 'I-82', 'files': external}),
            '_archive/supplemental_dependencies.json': encode(supplemental_inventory),
            '_archive/REPRODUCE.md': REPRODUCE.encode(),
        }
        inventory = dict(iteration='I-82', project_files=project,
            metadata_files=[{'archive_path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                            for name, data in sorted(metadata.items())],
            inventory_self_digest='Excluded from this list; adjacent final verification binds inventory bytes.')
        metadata['_archive/archive_inventory.json'] = encode(inventory)
        for name, data in metadata.items():
            with (output/Path(name).name).open('xb') as stream:
                stream.write(data)
        expected_members = {x['archive_path']: {'bytes': x['bytes'], 'sha256': x['sha256']} for x in project}
        expected_members.update({name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                                 for name, data in metadata.items()})
        archive = output/'i82_full_evidence.tar.gz'
        with tarfile.open(archive, 'w:gz') as tf:
            for record in project:
                tf.add(ROOT/record['source'], arcname=record['archive_path'], recursive=False, filter=fixed_info)
            for name, data in sorted(metadata.items()):
                info = fixed_info(tarfile.TarInfo(name))
                info.size = len(data)
                tf.addfile(info, io.BytesIO(data))
        members = stream_verify(archive, expected_members)
        check_registered(ROOT, protocol)
        current_supplemental, current_supplemental_inventory = check_supplemental(ROOT, BASE, protocol)
        if current_supplemental != supplemental or current_supplemental_inventory != supplemental_inventory:
            raise AssertionError('Supplemental dependency source/registration changed during archive')
        check_seal(args.seal, args.seal_base)
        check_media_manifest(args.media_manifest)
        current, current_excluded = select_files(ROOT, BASE, output, selection_prerequisites)
        if set(current) != set(selected) or set(current_excluded) != set(excluded):
            raise AssertionError('Evidence inclusion/exclusion set changed during archive')
        for record in project:
            path = ROOT/record['source']
            if sha(path) != record['sha256'] or path.stat().st_size != record['bytes']:
                raise AssertionError('Included evidence changed during archive: '+record['source'])
        for record in omissions:
            path = ROOT/record['source']
            if sha(path) != record['sha256'] or path.stat().st_size != record['bytes']:
                raise AssertionError('Excluded-file inventory changed during archive: '+record['source'])
        receipt = dict(iteration='I-82', archive=str(archive.relative_to(ROOT)),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive),
            inventory_sha256=hashlib.sha256(metadata['_archive/archive_inventory.json']).hexdigest(),
            project_file_count=len(project), regular_file_members_verified=members,
            omitted_file_count=len(omissions), registered_source_count=len(protocol['source_sha256']),
            registered_input_count=len(protocol['input_sha256']), sealed_output_count=len(seal['files']),
            every_member_stream_decoded_and_sha256_verified=True,
            sources_inputs_outputs_and_evidence_unchanged=True,
            actual_process_exits_zero=True, native_baseline_parity_passed=True,
            candidate_full_horizon_reached=outcomes[1]['physical_horizon_reached'],
            candidate_physical_failure=outcomes[1]['physical_failure'],
            included_mp4_count=len(movies), no_new_physics=True, no_new_video=True)
        receipt.update(supplemental_dependency_count=len(supplemental),
                       supplemental_original_paths=sorted(supplemental),
                       visual_bundle_included=True, visual_bundle_sha256=sha(args.visual_bundle))
        write_new(output/'archive_verification.json', receipt)
        print(json.dumps(receipt), flush=True)
    except BaseException:
        write_new(output/'archive_failure.json', dict(iteration='I-82',
            traceback=traceback.format_exc(), failed_archive_preserved=True, no_new_physics=True))
        raise


if __name__ == '__main__':
    main()


