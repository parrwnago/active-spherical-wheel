"""I82 descriptive 1ms force comparison; no new physics or controller calls.

Physical histories may already differ before the fixed window. This is not a
same-state causal intervention, force-control test or motor work partition.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import math
import shutil
import xml.etree.ElementTree as ET
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
I81_CORE = ROOT/'results/slope_response_trace_20261128/analysis/core.py'
MODEL = ROOT/'results/tangent_heading_routes_20261127/campaign/_workspaces/eight_m100_N/mirror/model.xml'
ARMS = ['B030', 'B060']
SNAPSHOTS = [100.75, 100.835, 100.9, 101., 101.5, 101.505, 101.55, 101.65, 101.8]


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean(x):
    if isinstance(x, dict): return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [clean(v) for v in x]
    if isinstance(x, np.ndarray): return clean(x.tolist())
    if isinstance(x, np.generic): return clean(x.item())
    if isinstance(x, float) and not math.isfinite(x): return None
    return x


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(clean(value), f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def load(path):
    with np.load(path, allow_pickle=False) as z: return {k: z[k].copy() for k in z.files}


def model_properties():
    tree = ET.parse(MODEL); root = tree.getroot(); props = {}
    names = ['fork', 'carrier', 'shell_A', 'shell_B']
    for name in names:
        b = root.find('.//body[@name="'+name+'"]')
        if b is None: raise ValueError('Missing captured-model body '+name)
        if name != 'fork' and any(abs(float(v)) > 1e-14 for v in b.get('pos', '0 0 0').split()):
            raise ValueError('COM helper requires captured zero-offset topology')
        if b.get('quat', '1 0 0 0') != '1 0 0 0': raise ValueError('Unexpected fixed body rotation')
        inertial = b.find('inertial')
        props[name] = {'mass': float(inertial.get('mass')), 'inertial_pos': [float(v) for v in inertial.get('pos', '0 0 0').split()]}
    gravity = np.asarray([float(v) for v in root.find('option').get('gravity', '0 0 -9.81').split()])
    return props, gravity


def arm_analysis(core, p, s, props, gravity):
    mass = sum(v['mass'] for v in props.values()); weight = float(mass*np.linalg.norm(gravity))
    result = []; samples = []
    for j, t in enumerate(s['time_s']):
        c = s['contact_rows'][s['contact_offsets'][j]:s['contact_offsets'][j+1]]
        row = core.contact_reduction(c, s['bridge_state_before'][j, 2:5], s['bridge_state'][j, 2:5])
        row.update(time_s=float(t), hold_index=int(s['hold_index'][j]), substep_index=int(s['substep_index'][j]))
        samples.append(row)
    for hold in sorted(set(s['hold_index'].tolist())):
        ids = np.flatnonzero(s['hold_index'] == hold)
        if len(ids) != 5 or not s['hold_completed'][ids].all():
            continue
        rows = [samples[j] for j in ids]
        interval = core.interval_reduction(rows, max(.05, .05*weight))
        endpoint = hold+1
        if endpoint >= len(p['time_s']): raise ValueError('Trace interval has no next observer row')
        assert abs(p['time_s'][endpoint]-interval['time_s']) < 1e-8
        assert np.array_equal(s['held_input'][ids], np.broadcast_to(p['exact_applied'][hold], (5, 5)))
        q0, v0 = core.bridge_qv(s['bridge_state_before'][ids[0]])
        q1, v1 = core.bridge_qv(s['bridge_state'][ids[-1]])
        pos0, cv0 = core.com_state(q0, v0, props); pos1, cv1 = core.com_state(q1, v1, props)
        momentum_rate = mass*(cv1-cv0)/.005
        normal = core.unit(interval['positive_normal_sum'])
        projection = core.force_projection(interval['all_force'], normal, mass, gravity)
        row = dict(time_s=float(interval['time_s']), preceding_hold_start_s=float(p['time_s'][hold]),
            hold_index=hold, source_row=endpoint, position_xy_m=p['exact_qpos'][endpoint, :2],
            pressure_family_mean_N=interval['pressure_by_family_N'], pressure_last_family_N=interval['pressure_last_family_N'],
            inferred_family_at_held_command=int(core.dominant(p['exact_estimated_support_loads_N'][hold])),
            physical_interval_dominant_family=int(core.dominant(interval['pressure_by_family_N'])),
            physical_last_dominant_family=int(core.dominant(interval['pressure_last_family_N'])),
            pressure_normal=normal, contact_force_world_N=interval['all_force'],
            COM_momentum_rate_world_N=momentum_rate, COM_velocity_start_m_s=cv0, COM_velocity_end_m_s=cv1,
            whole_COM_position_end_m=pos1, gravity_world_N=mass*gravity,
            held_requested=p['exact_requested'][hold], held_applied=p['exact_applied'][hold],
            held_preparation_delta=p['exact_transition_command_delta'][hold],
            new_requested_after_endpoint=p['exact_requested'][endpoint], new_applied_after_endpoint=p['exact_applied'][endpoint],
            current_command_acts_next=True,
            wheel_centre_xy_speed_m_s=float(np.linalg.norm(p['exact_qvel'][endpoint, :2])),
            observer_interval_force_error_N=float(np.linalg.norm(interval['all_force']-p['exact_observer_interval_mean'][endpoint, :3])),
            force_projection=projection)
        for name in ['all', 'admitted', 'native']:
            row[name+'_COM_force_residual_N'] = interval[name+'_force']+mass*gravity-momentum_rate
        result.append(row)
    chosen = []
    for t in SNAPSHOTS:
        if not result or t < result[0]['time_s']-1e-8 or t > result[-1]['time_s']+1e-8:
            chosen.append({'requested_time_s': t, 'available': False}); continue
        a = min(result, key=lambda x: abs(x['time_s']-t))
        chosen.append({'requested_time_s': t, 'available': abs(a['time_s']-t) < 1e-8, **a})
    statistics = {}
    for key in ['contact_downhill_N', 'gravity_downhill_N', 'sampled_net_downhill_N']:
        statistics[key] = core.stats([r['force_projection'].get(key) for r in result])
    for name in ['all', 'admitted', 'native']:
        statistics[name+'_COM_force_residual_norm_N'] = core.stats([np.linalg.norm(r[name+'_COM_force_residual_N']) for r in result])
    return dict(intervals=len(result), raw_substeps=len(s['time_s']),
        captured_window_s=None if not len(s['time_s']) else [float(s['time_s'][0]), float(s['time_s'][-1])],
        complete_expected_capture=bool(len(s['time_s']) == 1300 and len(result) == 260),
        statistics=statistics, selected_rows=chosen, rows=result)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--runs', type=Path, required=True); ap.add_argument('--seal', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True); args = ap.parse_args()
    runs, seal_path, out = args.runs.resolve(), args.seal.resolve(), args.output.resolve()
    seal = json.loads(seal_path.read_text())
    for name, v in seal['files'].items():
        path = BASE/name
        assert path.stat().st_size == v['bytes'] and sha(path) == v['sha256']
    paths = [Path(__file__), I81_CORE, MODEL, seal_path]
    for arm in ARMS:
        paths += [runs/arm/'substeps.npz', runs/arm/'capture_receipt.json', runs/arm/'child/campaign/runs/eight_m100_N/precision.npz']
    bindings = {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths}
    out.mkdir(parents=True, exist_ok=False)
    for p in [Path(__file__), I81_CORE]: shutil.copyfile(p, out/p.name)
    save(out/'registered_before_arrays.json', dict(iteration='I-82', utc=datetime.now(timezone.utc).isoformat(),
        source_and_inputs=bindings, source_iteration='I-81 fixed pure reduction/COM helpers', selected_times_s=SNAPSHOTS,
        scope='Descriptive new1ms comparison of whole capacity histories, no new controller/gate/physics, no motor/passive-work partition.',
        interpretation='Same clock window can contain different positions, geometry and prior states between arms. Do not interpret pulse differences as a same-state isolated correction.'))
    spec = importlib.util.spec_from_file_location('_i82_force_i81_core', I81_CORE)
    core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    props, gravity = model_properties(); arms = {}
    for arm in ARMS:
        p = load(runs/arm/'child/campaign/runs/eight_m100_N/precision.npz')
        s = load(runs/arm/'substeps.npz')
        arms[arm] = arm_analysis(core, p, s, props, gravity)
    report = dict(iteration='I-82', arms=arms, model_properties=props, gravity_m_s2=gravity,
        no_new_physics=True, no_same_state_causal_claim=True, no_motor_work_partition=True,
        full_route_motion_comparison_primary=True,
        qualification='Exported force samples approximate completed-interval force, not exact solver impulse. Root acceleration is not whole-system COM acceleration. Pressure and filtered inference differ in timing.')
    save(out/'report.json', report)
    lines = ['# I-82 descriptive force-window comparison', '',
        'These are different capacity histories at the same recorded clock, not a same-state intervention.', '',
        '| Interval end | Arm | Contact downhill (N) | Gravity downhill (N) | Sampled sum (N) | Physical XY (m) |',
        '| --- | --- | ---: | ---: | ---: | --- |']
    for t in [100.9, 101., 101.5]:
        for arm in ARMS:
            row = next(x for x in arms[arm]['selected_rows'] if abs(x['requested_time_s']-t) < 1e-8)
            if not row['available']:
                lines.append(f'| {t:.3f} | {arm} | unavailable | unavailable | unavailable | unavailable |'); continue
            p = row['force_projection']; xy = row['position_xy_m']
            if not p.get('valid'):
                lines.append(f'| {t:.3f} | {arm} | undefined tangent | undefined tangent | undefined tangent | [{xy[0]:.5f}, {xy[1]:.5f}] |'); continue
            lines.append(f"| {t:.3f} | {arm} | {p['contact_downhill_N']:.6f} | {p['gravity_downhill_N']:.6f} | {p['sampled_net_downhill_N']:.6f} | [{xy[0]:.5f}, {xy[1]:.5f}] |")
    lines += ['', 'All/admitted/native force variants and COM momentum closure are reported. No force-based acceptance gate or controller change is introduced.']
    (out/'summary.md').write_text('\n'.join(lines)+'\n')
    assert all(sha(ROOT/name) == x['sha256'] for name, x in bindings.items())
    save(out/'artifact_manifest.json', {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(out.iterdir()) if p.is_file()}})
    print(json.dumps({'intervals': {arm: arms[arm]['intervals'] for arm in ARMS}, 'no_new_physics': True}))


if __name__ == '__main__': main()
