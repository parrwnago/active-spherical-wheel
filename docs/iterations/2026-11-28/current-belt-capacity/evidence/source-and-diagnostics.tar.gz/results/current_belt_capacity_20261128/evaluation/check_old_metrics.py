"""I82 pure-metric parity against already known original I76 baseline."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import numpy as np
import core

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OLD = ROOT/'results/tangent_heading_routes_20261127'


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    out = HERE/'old_metric_parity_stage01'; out.mkdir(exist_ok=False)
    case = OLD/'campaign/runs/eight_m100_N'
    inputs = [Path(__file__), HERE/'core.py', HERE/'definitions.json', core.OLD_PATH,
              case/'precision.npz', case/'summary.json', OLD/'evaluation/completed_stage01/science.json']
    binding = {str(p.relative_to(ROOT)): sha(p) for p in inputs}
    shutil.copyfile(Path(__file__), out/'check_old_metrics.py')
    (out/'registered_before_old_arrays.json').write_text(json.dumps({'iteration':'I-82','utc':datetime.now(timezone.utc).isoformat(),
        'source_inputs':binding,'scope':'One already-known original saved baseline; no new I82 arrays or physics. Frozen I82 numeric settings remain unchanged.'},indent=2)+'\n')
    with np.load(case/'precision.npz',allow_pickle=False) as z: raw = {k:z[k].copy() for k in z.files}
    summary = json.loads((case/'summary.json').read_text())
    row, signals = core.summarize(raw,summary)
    old = json.loads((OLD/'evaluation/completed_stage01/science.json').read_text())['cases']['eight_m100_N']
    pairs = [
        ('moving_timed_rms_m',row['tracking']['moving_timed_rms_m'],old['tracking']['moving_timed_rms_m']),
        ('full_timed_peak_m',row['tracking']['full_timed_peak_m'],old['tracking']['full_timed_peak_m']),
        ('final_goal_error_m',row['tracking']['final_goal_error_m'],old['tracking']['final_xy_m']),
        ('geometric_moving_rms_m',row['tracking']['moving_geometric_rms_m'],old['tracking']['geometric_moving_m']['rms']),
        ('geometric_moving_peak_m',row['tracking']['moving_geometric_peak_m'],old['tracking']['geometric_moving_m']['maximum']),
        ('own_reference_up_peak_deg',row['attitude']['own_reference_up_peak_deg'],old['attitude']['raw_reference_peak_deg']),
        ('own_reference_up_rms_deg',row['attitude']['own_reference_up_rms_deg'],old['attitude']['raw_reference_rms_deg']),
        ('absolute_tilt_peak_deg',row['attitude']['absolute_tilt_peak_deg'],old['attitude']['absolute_tilt_peak_deg']),
        ('xy_speed_peak_m_s',row['motion']['full_planar_speed_peak_m_s'],old['motion']['full_planar_speed_peak_m_s']),
        ('world_z_rate_peak_rad_s',row['motion']['full_world_z_rate_peak_rad_s'],old['motion']['full_world_z_peak_rad_s']),
        ('acceleration_peak_m_s2',row['motion']['full_50ms_acceleration_peak_m_s2'],old['motion']['full_50ms_acceleration_peak_m_s2']),
        ('normalized_own_step_peak',row['commands']['own']['normalized_applied_step']['maximum'],old['commands']['normalized_step']['maximum']),
        ('normalized_own_excess_rms',row['commands']['own']['normalized_requested_excess']['rms'],old['commands']['normalized_clipping_excess']['rms'])]
    checks = [{'name':name,'new':float(a),'original':float(b),'absolute_difference':abs(float(a)-float(b)),'passed':abs(float(a)-float(b))<1e-12} for name,a,b in pairs]
    checks.append({'name':'four_condition_settling','new':row['settling']['four_condition_passed'],'original':old['settling']['passed'],'passed':row['settling']['four_condition_passed']==old['settling']['passed']})
    assert all(x['passed'] for x in checks)
    assert all(sha(ROOT/name)==h for name,h in binding.items())
    report={'iteration':'I-82','passed':True,'checks':checks,'count':len(checks),'new_case_arrays_read':False,'no_new_physics':True}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'manifest.json').write_text(json.dumps({'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}},indent=2)+'\n')
    print(json.dumps({'passed':True,'scalar_and_settling_checks':len(checks),'maximum_scalar_difference':max(x.get('absolute_difference',0.) for x in checks),'no_new_I82_arrays':True}))


if __name__=='__main__':main()
