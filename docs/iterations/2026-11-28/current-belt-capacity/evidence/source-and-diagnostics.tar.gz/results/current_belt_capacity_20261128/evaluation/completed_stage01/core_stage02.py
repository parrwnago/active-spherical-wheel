"""I82 pure capacity metrics, fixed clocks/scales and unchanged I76 geometry.

No simulation, observer/controller calls or outcome-dependent settings.
"""
from pathlib import Path
import importlib.util
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
OLD_PATH = ROOT / 'results/tangent_heading_routes_20261127/evaluation/metrics.py'
spec = importlib.util.spec_from_file_location('_i82_original_i76_metrics', OLD_PATH)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
BASE_BOUNDS = np.array([1.5, .6, .6, .3, .3])
DT = .005


def exact(a, b):
    return old.exact_equal(a, b)


def window(t, lo, hi, terminal=True):
    return old.window(np.asarray(t), [lo, hi], terminal)


def stats(a):
    return old.stats(a)


def full_grid(t):
    t = np.asarray(t)
    return bool(len(t) == 26601 and abs(t[0]) <= 1e-9 and abs(t[-1]-133.) <= 1e-9
                and np.all(abs(np.diff(t)-DT) <= 1e-9))


def command_metrics(t, requested, applied, previous, bounds, held):
    t = np.asarray(t)
    requested, applied, previous, bounds = map(np.asarray, (requested, applied, previous, bounds))
    held = np.asarray(held, bool)
    duration = np.r_[np.diff(t), 0.]
    if np.any(duration < -1e-12):
        raise ValueError('Clock must increase')
    result = {'held_intervals': int(held.sum()), 'held_seconds': float(duration[held].sum()),
              'terminal_unheld_excluded': True,
              'final_unheld_request_finite': bool(np.isfinite(requested[-1]).all()),
              'applied_box_ok': bool(np.isfinite(applied[held]).all() and (bounds[held] > 0).all()
                  and np.all(abs(applied[held]) <= bounds[held]+1e-12)),
              'clip_identity': bool(np.array_equal(applied[held], np.clip(requested[held], -bounds[held], bounds[held]))),
              'prior_input_identity': bool(np.array_equal(previous[1:], applied[:-1])),
              'requested_peak_abs': np.max(abs(requested[held]), axis=0) if held.any() else np.full(5, np.nan),
              'applied_peak_abs': np.max(abs(applied[held]), axis=0) if held.any() else np.full(5, np.nan),
              'dimensional_applied_step_peak': np.max(abs(applied[held]-previous[held]), axis=0) if held.any() else np.full(5, np.nan)}
    for name, scale in [('own', bounds), ('base', np.broadcast_to(BASE_BOUNDS, bounds.shape))]:
        clipped = abs(requested) > scale+1e-12
        exceed = abs(applied) > scale+1e-12
        excess = np.linalg.norm((requested-np.clip(requested, -scale, scale))/scale, axis=1)
        step = np.linalg.norm((applied-previous)/scale, axis=1)
        result[name] = dict(
            requested_clipped_any_seconds=float(duration[held & clipped.any(axis=1)].sum()),
            requested_clipped_each_seconds=np.sum(duration[held, None]*clipped[held], axis=0),
            requested_clipped_any_fraction=float(np.mean(clipped[held].any(axis=1))) if held.any() else None,
            requested_clipped_each_fraction=np.mean(clipped[held], axis=0) if held.any() else np.full(5, np.nan),
            applied_exceeded_any_seconds=float(duration[held & exceed.any(axis=1)].sum()),
            applied_exceeded_each_seconds=np.sum(duration[held, None]*exceed[held], axis=0),
            normalized_requested_excess=stats(excess[held]),
            normalized_applied_step=stats(step[held]))
    return result


def settling(t, goal_distance, speed, world_z_rate, up_error_deg):
    t = np.asarray(t)
    mask = window(t, 131., 133.)
    good = ((np.asarray(goal_distance) <= .02+1e-12) & (np.asarray(speed) <= .02+1e-12)
            & (abs(np.asarray(world_z_rate)) <= .05+1e-12) & (np.asarray(up_error_deg) <= 2.+1e-12))
    complete = bool(full_grid(t) and mask.sum() == 401)
    position_good = ((np.asarray(goal_distance) <= .02+1e-12) & (np.asarray(speed) <= .02+1e-12))
    return dict(final_window_complete=complete, final_samples=int(mask.sum()),
                four_condition_passed=bool(complete and good[mask].all()),
                physical_position_speed_passed=bool(complete and position_good[mask].all()),
                goal_distance=stats(np.asarray(goal_distance)[mask]),
                xy_speed=stats(np.asarray(speed)[mask]),
                world_z_rate_abs=stats(abs(np.asarray(world_z_rate)[mask])),
                own_reference_up_error_deg=stats(np.asarray(up_error_deg)[mask]))


def signals(raw):
    t, q, v = raw['time_s'], raw['exact_qpos'], raw['exact_qvel']
    R = old.rotation(q[:, 3:7]); Rref = old.rotation(raw['exact_reference_quat'])
    up, upref = R[:, :, 2], Rref[:, :, 2]
    omega = np.einsum('nij,nj->ni', R, v[:, 3:6])
    xy = q[:, :2]
    path = old.geometric_polyline('eight', 4097)
    geometric = old.polyline_distance(xy, path)
    yaw = np.unwrap(np.arctan2(R[:, 1, 0], R[:, 0, 0]))
    return dict(time_s=t, xy=xy, timed_xy_error_m=np.linalg.norm(xy-raw['exact_reference_xy'], axis=1),
                geometric_error_m=geometric, goal_distance_m=np.linalg.norm(xy-path[-1], axis=1),
                xy_speed_m_s=np.linalg.norm(v[:, :2], axis=1),
                desired_xy_speed_m_s=np.linalg.norm(raw['exact_reference_velocity_m_s'], axis=1),
                tilt_deg=np.degrees(np.arccos(np.clip(up[:, 2], -1., 1.))),
                own_reference_up_error_deg=np.degrees(np.arccos(np.clip(np.sum(up*upref, axis=1), -1., 1.))),
                world_z_rate_rad_s=omega[:, 2], unwrapped_yaw_rad=yaw)


def summarize(raw, summary):
    s = signals(raw)
    t = s['time_s']; moving = window(t, 3., 123., False); full = window(t, 0., 133.)
    held = np.asarray(raw['command_held_after_row'], bool)
    command = command_metrics(t, raw['exact_requested'], raw['exact_applied'], raw['exact_previous_applied'], raw['exact_input_bounds'], held)
    acceleration = np.linalg.norm((raw['exact_qvel'][10:, :3]-raw['exact_qvel'][:-10, :3])/.05, axis=1)
    acc_valid = full[10:] & full[:-10] & (abs(t[10:]-t[:-10]-.05) <= 1e-9)
    stat = lambda key, mask: stats(s[key][mask])
    focus = window(t, 100.5, 103.)
    snapshots = []
    for target in [100.5, 100.835, 100.9, 101., 101.5, 101.505, 102.135, 103.]:
        i = int(np.argmin(abs(t-target)))
        snapshots.append(dict(requested_time_s=target, actual_time_s=float(t[i]), source_row=i,
            timed_xy_error_m=float(s['timed_xy_error_m'][i]), geometric_error_m=float(s['geometric_error_m'][i]),
            xy_speed_m_s=float(s['xy_speed_m_s'][i]), own_reference_up_error_deg=float(s['own_reference_up_error_deg'][i]),
            absolute_tilt_deg=float(s['tilt_deg'][i]), world_z_rate_rad_s=float(s['world_z_rate_rad_s'][i]),
            previous_applied=raw['exact_previous_applied'][i], new_requested=raw['exact_requested'][i], new_applied=raw['exact_applied'][i]))
    row = dict(frames=len(t), complete_grid=full_grid(t),
        completed=bool(summary.get('completed') and summary.get('failure') is None and full_grid(t)), failure=summary.get('failure'),
        finite_state=bool(np.isfinite(raw['exact_qpos']).all() and np.isfinite(raw['exact_qvel']).all()),
        finite_commands=bool(np.isfinite(raw['exact_requested']).all() and np.isfinite(raw['exact_applied']).all()),
        held_mask_ok=bool(np.array_equal(held, np.arange(len(t)) < len(t)-1)),
        tracking=dict(moving_timed_rms_m=stat('timed_xy_error_m', moving)['rms'],
            full_timed_peak_m=stat('timed_xy_error_m', full)['maximum'], final_goal_error_m=float(s['goal_distance_m'][-1]),
            moving_geometric_rms_m=stat('geometric_error_m', moving)['rms'], moving_geometric_peak_m=stat('geometric_error_m', moving)['maximum']),
        attitude=dict(own_reference_up_peak_deg=stat('own_reference_up_error_deg', full)['maximum'],
            own_reference_up_rms_deg=stat('own_reference_up_error_deg', full)['rms'], absolute_tilt_peak_deg=stat('tilt_deg', full)['maximum']),
        motion=dict(full_planar_speed_peak_m_s=stat('xy_speed_m_s', full)['maximum'],
            full_world_z_rate_peak_rad_s=stats(abs(s['world_z_rate_rad_s'][full]))['maximum'],
            full_50ms_acceleration_peak_m_s2=stats(acceleration[acc_valid])['maximum'],
            full_world_z_absolute_rotation_rad=float(np.trapz(abs(s['world_z_rate_rad_s'][full]), t[full]))),
        commands=command,
        settling=settling(t, s['goal_distance_m'], s['xy_speed_m_s'], s['world_z_rate_rad_s'], s['own_reference_up_error_deg']),
        focus=dict(window_s=[100.5, 103.], samples=int(focus.sum()),
            timed_error=stat('timed_xy_error_m', focus), geometric_error=stat('geometric_error_m', focus),
            speed=stat('xy_speed_m_s', focus), tilt=stat('tilt_deg', focus), up_error=stat('own_reference_up_error_deg', focus),
            world_z_rate_abs=stats(abs(s['world_z_rate_rad_s'][focus])), snapshots=snapshots,
            scope='Fixed descriptive episode; no1msforce attribution or replacement of whole-route scoring.'))
    return row, s


def compare(native, candidate, definitions):
    cfg = definitions['screen']; checks = []
    add = lambda name, actual, limit, passed: checks.append(dict(name=name, actual=actual, limit=limit, passed=bool(passed)))
    for arm, row in [('B030', native), ('B060', candidate)]:
        for key in ['completed', 'finite_state', 'finite_commands', 'held_mask_ok']:
            add(arm+'_'+key, row[key], True, row[key])
        for key in ['applied_box_ok', 'clip_identity', 'prior_input_identity']:
            add(arm+'_'+key, row['commands'][key], True, row['commands'][key])
    for key, ratio in [('moving_timed_rms_m', cfg['benefit']['moving_timed_rms_ratio']), ('full_timed_peak_m', cfg['benefit']['full_timed_peak_ratio'])]:
        n, c = native['tracking'][key], candidate['tracking'][key]
        limit = None if n is None else ratio*n
        add('benefit_'+key, c, limit, c is not None and limit is not None and np.isfinite(c) and c <= limit+1e-12)
    for key, (ratio, offset) in cfg['nonregression'].items():
        if key == 'base_normalized_applied_step_peak':
            n, c = native['commands']['base']['normalized_applied_step']['maximum'], candidate['commands']['base']['normalized_applied_step']['maximum']
        else:
            group = 'tracking' if key in native['tracking'] else 'attitude' if key in native['attitude'] else 'motion'
            n, c = native[group][key], candidate[group][key]
        limit = None if n is None else ratio*n+offset
        add('nonregression_'+key, c, limit, c is not None and limit is not None and np.isfinite(c) and c <= limit+1e-12)
    for k in range(3):
        n = native['commands']['own']['requested_clipped_each_seconds'][k]
        c = candidate['commands']['own']['requested_clipped_each_seconds'][k]
        limit = n+cfg['torque_channel_clipped_seconds_add_s']
        add('motor_channel'+str(k)+'_clipped_seconds', float(c), float(limit), c <= limit+1e-12)
    n, c = native['settling']['four_condition_passed'], candidate['settling']['four_condition_passed']
    add('preserve_native_four_condition_settling', c, 'required iff native passes', not n or c)
    return dict(status='PASS_CAPACITY_SCREEN' if all(x['passed'] for x in checks) else 'FAIL_CAPACITY_SCREEN',
                passed=all(x['passed'] for x in checks), checks=checks, automatic_adoption=False,
                full_general_improvement_claim=False, scope='One current matched route/phase, provisional screen. Completion and absolute settling remain separate.')
