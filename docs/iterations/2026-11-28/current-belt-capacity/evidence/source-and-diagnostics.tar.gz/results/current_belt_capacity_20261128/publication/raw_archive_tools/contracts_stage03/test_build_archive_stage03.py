"""Four synthetic packaging contracts; no campaign reads or physics."""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import tarfile
import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i82_archive_contract_source', HERE/'build_archive_stage03.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def put(path, text='bytes'):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


def test_selection_is_narrow_and_retains_movies_and_registered_prerequisites(tmp_path):
    root = tmp_path/'repo'; base = root/'results/i82'; out = base/'publication/full_evidence_stage01'
    keep = put(base/'campaign/case/precision.npz')
    model = put(base/'campaign/_workspaces/case/model.xml')
    movie = put(base/'publication/video_stage01/full.mp4')
    omit = put(base/'campaign/_workspaces/case/meshes/terrain.obj')
    scene = put(base/'publication/video_stage01/scene/model.xml')
    duplicate = put(base/'publication/visual_bundle_stage01/full.mp4')
    exact = put(root/'assets/registered.obj')
    put(root/'unrelated/user_secret.txt'); put(base/'curation/helper.py'); put(out/'recursive.tar.gz')
    selected, excluded = m.select_files(root, base, out, {'assets/registered.obj': m.sha(exact)})
    assert set(selected) == {str(x.relative_to(root)) for x in [keep, model, movie, exact]}
    assert all(str(x.relative_to(root)) in excluded for x in [omit, scene, duplicate])
    assert not any('unrelated' in x for x in selected)


def test_bound_input_changed_rejected(tmp_path):
    path = put(tmp_path/'src/control.py', 'before')
    protocol = {'source_sha256': {'src/control.py': m.sha(path)}, 'input_sha256': {}}
    assert m.check_registered(tmp_path, protocol)
    path.write_text('after')
    with pytest.raises(AssertionError, match='changed'):
        m.check_registered(tmp_path, protocol)


def test_stream_verification_detects_bad_digest_and_member_set(tmp_path):
    archive = tmp_path/'fixture.tar.gz'; payload = b'closed evidence'
    with tarfile.open(archive, 'w:gz') as tf:
        info = tarfile.TarInfo('project/evidence.json'); info.size = len(payload)
        tf.addfile(info, io.BytesIO(payload))
    expected = {'project/evidence.json': {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}}
    assert m.stream_verify(archive, expected) == 1
    with pytest.raises(AssertionError, match='digest'):
        m.stream_verify(archive, {'project/evidence.json': {'bytes': len(payload), 'sha256': '0'*64}})
    with pytest.raises(AssertionError, match='Unexpected'):
        m.stream_verify(archive, {})


def make_case(path, arm, early=False):
    path.mkdir()
    cap = .3 if arm == 'B030' else .6
    outcome = dict(iteration='I-82', arm=arm, cap_m_s=cap, runner_recording_completed=True,
                   baseline_parity_passed=arm == 'B030', physical_horizon_reached=not early,
                   recorded_rows=20000 if early else 26601, physical_failure='tilt' if early else None)
    comparison = (dict(baseline_parity_passed=True, fields=[{'bit_exact': True} for _ in range(79)])
                  if arm == 'B030' else dict(physical_observer_prefix_checks={'qpos': True, 'wrench': True}))
    receipt = dict(config_and_design_unchanged=True,
                   physical_operating_bounds=[1.5,.6,.6,cap,cap], mirror_operating_bounds=[1.5,.6,.6,cap,cap],
                   original_designer_bounds=[1.5,.6,.6,.3,.3], config_sha256='config',
                   bank_numeric_sha256='bank', ordinary_design_sha256='ordinary', bank_file_sha256='bytes')
    for name, value in [('outcome.json', outcome), ('native_comparison.json', comparison), ('capacity_receipt.json', receipt)]:
        (path/name).write_text(json.dumps(value))


def test_candidate_physical_failure_is_preserved_but_baseline_and_fixed_design_must_pass(tmp_path):
    a, b = tmp_path/'B030', tmp_path/'B060'
    make_case(a, 'B030'); make_case(b, 'B060', early=True)
    outcomes = m.check_cases(a, b)
    assert outcomes[1]['physical_failure'] == 'tilt' and not outcomes[1]['physical_horizon_reached']
    p = b/'capacity_receipt.json'; r = json.loads(p.read_text()); r['bank_numeric_sha256'] = 'changed'; p.write_text(json.dumps(r))
    with pytest.raises(AssertionError, match='fixed design'):
        m.check_cases(a, b)


def test_supplemental_external_sources_restore_original_paths_and_reject_changed_bytes(tmp_path, monkeypatch):
    root = tmp_path/'repo'; base = root/'results/current_belt_capacity_20261128'
    expected = {}
    for path in m.SUPPLEMENTAL_ALLOWED_SHA:
        file = put(root/path, 'synthetic historical source '+path)
        expected[path] = m.sha(file)
    monkeypatch.setattr(m, 'SUPPLEMENTAL_ALLOWED_SHA', expected)
    names = list(expected)
    groups = [[names[0]], [names[1]], names[2:]]
    for (relative, key), group in zip(m.SUPPLEMENTAL_REGISTRATIONS, groups):
        put(base/relative, json.dumps({'iteration': 'I-82', key: {name: {'sha256': expected[name]} for name in group}}))
    extra, inventory = m.check_supplemental(root, base, {'source_sha256': {}, 'input_sha256': {}})
    assert extra == expected and len(inventory['files']) == 4
    assert all(x['archive_path'] == 'project/'+x['source'] for x in inventory['files'])
    (root/names[0]).write_text('changed')
    with pytest.raises(AssertionError, match='changed'):
        m.check_supplemental(root, base, {'source_sha256': {}, 'input_sha256': {}})


def test_archive_metadata_handles_relative_and_absolute_visual_report_paths(tmp_path, monkeypatch):
    root = tmp_path/'repo'; report = put(root/'results/visual/report.json', '{}')
    monkeypatch.setattr(m, 'ROOT', root)
    monkeypatch.chdir(root)
    assert m.repository_relative(Path('results/visual/report.json')) == 'results/visual/report.json'
    assert m.repository_relative(report.resolve()) == 'results/visual/report.json'
