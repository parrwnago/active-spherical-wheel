"""I82 two-arm sealed capacity comparison; no simulation or controller calls."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import math
import shutil
import numpy as np
import core

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
OLD = ROOT / 'results/tangent_heading_routes_20261127'
HERE = Path(__file__).resolve().parent
ARMS = ('B030', 'B060')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def clean(value):
    if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [clean(v) for v in value]
    if isinstance(value, np.ndarray): return clean(value.tolist())
    if isinstance(value, np.generic): return clean(value.item())
    if isinstance(value, Path): return str(value)
    if isinstance(value, float) and not math.isfinite(value): return None
    return value


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(clean(value), f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def load(path):
    with np.load(path, allow_pickle=False) as z:
        return {key: z[key].copy() for key in z.files}


def expected_arm_cap(protocol, arm):
    cfg = protocol['runner_settings']['caps_m_s']
    return float(cfg[arm])


def seal_validation(protocol_path, seal_path, runs):
    protocol = json.loads(protocol_path.read_text())
    if protocol.get('iteration') != 'I-82': raise ValueError('I82 protocol required')
    definitions = json.loads((HERE/'definitions.json').read_text())
    if 'evaluation' in protocol and protocol['evaluation'] != definitions:
        raise ValueError('Evaluation definitions differ from frozen protocol')
    binding = {**protocol.get('source_sha256', {}), **protocol.get('input_sha256', {})}
    for path in [HERE/'core.py', HERE/'definitions.json', core.OLD_PATH]:
        name = str(path.relative_to(ROOT))
        if binding.get(name) != sha(path): raise ValueError('Required metric binding missing or changed: '+name)
    for name, expected in binding.items():
        if sha(ROOT/name) != expected: raise ValueError('Frozen input/source changed: '+name)
    seal = json.loads(seal_path.read_text())
    if seal.get('protocol_sha256') != sha(protocol_path): raise ValueError('Output seal protocol mismatch')
    files = seal['files']; resolved = set()
    for name, expected in files.items():
        path = BASE/name
        if path.stat().st_size != expected['bytes'] or sha(path) != expected['sha256']:
            raise ValueError('Sealed output changed: '+name)
        resolved.add(path.resolve())
    for arm in ARMS:
        inner = runs/arm/'child/campaign/runs/eight_m100_N'
        for path in [inner/'precision.npz', inner/'summary.json', inner/'provenance.json', runs/arm/'outcome.json', runs/arm/'capacity_receipt.json']:
            if path.resolve() not in resolved: raise ValueError('Required arm output unsealed: '+str(path))
    return protocol, definitions, binding


def pair_setup(raw, metadata, protocol):
    checks = []
    def add(name, passed, **extra): checks.append(dict(name=name, passed=bool(passed), **extra))
    for arm in ARMS:
        a = raw[arm]; n = len(a['time_s']); cap = expected_arm_cap(protocol, arm)
        bounds = np.broadcast_to([1.5, .6, .6, cap, cap], (n, 5))
        add(arm+'_actual_operating_caps', core.exact(a['exact_input_bounds'], bounds))
        add(arm+'_one_observer_per_command', np.all(a['native_observer_update_count'] == 1))
        for key in ['native_feedback_boundary_verified', 'mirror_previous_applied_matches_physical', 'no_truth_or_terrain_read_during_command']:
            add(arm+'_'+key, a[key].all())
        add(arm+'_native_heading_helper_off', not np.any(a['exact_heading_command']))
        add(arm+'_zero_native_body_angular_rate_reference', not np.any(a['exact_feedback_reference_qvel'][:, 3:6]))
        add(arm+'_unchanged_gain_bank_loaded', metadata[arm]['frozen_bank_loaded'])
        add(arm+'_expected_gain_bank_bytes', metadata[arm]['fixed_bank_bytes_sha256'] == protocol['gain_cache']['sha256'])
    a, b = raw['B030'], raw['B060']; n = min(len(a['time_s']), len(b['time_s']))
    for key in ['time_s', 'exact_reference_xy', 'exact_reference_velocity_m_s', 'exact_reference_acceleration_m_s2', 'heading__raw_heading_rad', 'heading__raw_heading_rate_rad_s', 'heading__raw_heading_acceleration_rad_s2']:
        add('same_reference_commonprefix_'+key, n > 0 and core.exact(a[key][:n], b[key][:n]))
    for key in ['exact_qpos', 'exact_qvel', 'exact_previous_applied']:
        add('same_initial_'+key, core.exact(a[key][0], b[key][0]))
    for key in ['ordinary_design_sha256', 'fixed_bank_numeric_sha256', 'fixed_bank_bytes_sha256']:
        add('same_'+key, metadata['B030'][key] == metadata['B060'][key])
    original = load(OLD/'campaign/runs/eight_m100_N/precision.npz')
    add('B030_original79field_set', set(a) == set(original) and len(a) == 79)
    for key in sorted(original):
        add('B030_original_exact_'+key, key in a and core.exact(a[key], original[key]))
    return checks


def plot(rows, signals, raw, out, decision):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    colors = {'B030': '#225fa4', 'B060': '#008b75'}
    labels = {'B030': 'Original cap 0.30 m/s', 'B060': 'Raised cap 0.60 m/s'}
    fig, ax = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    path = core.old.geometric_polyline('eight', 4097)
    ax[0, 0].plot(path[:, 0], path[:, 1], 'k:', label='Full fixed path')
    ax[0, 0].plot(path[-1, 0], path[-1, 1], 'kx', ms=7)
    for arm in ARMS:
        s = signals[arm]; c = colors[arm]; label = labels[arm]
        ax[0, 0].plot(s['xy'][:, 0], s['xy'][:, 1], color=c, label=label)
        ax[0, 0].plot(s['xy'][-1, 0], s['xy'][-1, 1], 's', color=c, ms=4)
        ax[0, 1].plot(s['time_s'], 1000*s['timed_xy_error_m'], color=c, label=label)
        ax[1, 0].plot(s['time_s'], s['xy_speed_m_s'], color=c, label=label)
        ax[1, 1].plot(s['time_s'], s['own_reference_up_error_deg'], color=c, label=label)
    s = signals['B030']; ax[1, 0].plot(s['time_s'], s['desired_xy_speed_m_s'], 'k--', lw=.8, label='Desired speed')
    ax[0, 0].set(xlabel='World X (m)', ylabel='World Y (m)', aspect='equal', title='Recorded wheel-centre path')
    ax[0, 1].set(ylabel='Timed XY error (mm)', xlabel='Physical time (s)', title='Same timed reference')
    ax[1, 0].set(ylabel='XY speed (m/s)', xlabel='Physical time (s)')
    ax[1, 1].set(ylabel='Own raw target up error (deg)', xlabel='Physical time (s)')
    for a in ax.flat:
        a.grid(alpha=.2); a.legend(fontsize=8)
    fig.suptitle('I-82: fixed LQR/observer, operating belt capacity only\n'+decision['status'])
    fig.savefig(out/'full_route_comparison.png', dpi=150)

    focus, f = plt.subplots(4, 1, figsize=(12, 10), sharex=True, constrained_layout=True)
    for arm in ARMS:
        s = signals[arm]; p = raw[arm]; m = core.window(s['time_s'], 100.5, 103.)
        c = colors[arm]; label = labels[arm]; t = s['time_s'][m]
        f[0].plot(t, 1000*s['timed_xy_error_m'][m], color=c, label=label)
        f[1].plot(t, s['xy_speed_m_s'][m], color=c, label=label)
        f[2].plot(t, np.degrees(s['world_z_rate_rad_s'][m]), color=c, label=label)
        f[3].plot(t, p['exact_requested'][m, 3], color=c, alpha=.5, label=label+' requested')
        f[3].plot(t, p['exact_applied'][m, 3], color=c, label=label+' applied')
    f[0].set_ylabel('Timed error (mm)'); f[1].set_ylabel('XY speed (m/s)')
    f[2].set_ylabel('World-z rate (deg/s)'); f[3].set(ylabel='Belt A speed (m/s)', xlabel='Physical state / next-command time (s)')
    for a in f:
        a.axvline(101.5, color='k', ls=':', lw=.8); a.grid(alpha=.2); a.legend(fontsize=8, ncol=2)
    focus.suptitle('I-82 fixed episode 100.5–103 s; original user frame at 101.5 s\nArms may arrive here with different physical histories; current commands act next.')
    focus.savefig(out/'downhill_episode_comparison.png', dpi=150)
    with PdfPages(out/'capacity_comparison.pdf') as pdf:
        pdf.savefig(fig); pdf.savefig(focus)
    plt.close(fig); plt.close(focus)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--protocol', type=Path, required=True)
    ap.add_argument('--seal', type=Path, required=True)
    ap.add_argument('--runs', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    protocol_path, seal_path, runs, out = args.protocol.resolve(), args.seal.resolve(), args.runs.resolve(), args.output.resolve()
    protocol, definitions, binding = seal_validation(protocol_path, seal_path, runs)
    paths = [Path(__file__), HERE/'core.py', HERE/'definitions.json', core.OLD_PATH, protocol_path, seal_path,
             OLD/'campaign/runs/eight_m100_N/precision.npz']
    for arm in ARMS:
        inner = runs/arm/'child/campaign/runs/eight_m100_N'
        paths += [inner/name for name in ['precision.npz', 'summary.json', 'provenance.json']]
        paths += [runs/arm/name for name in ['outcome.json', 'capacity_receipt.json']]
    bindings = {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths}
    out.mkdir(parents=True, exist_ok=False)
    for path in [Path(__file__), HERE/'core.py', HERE/'definitions.json']:
        shutil.copyfile(path, out/path.name)
    save(out/'registered_before_arrays.json', dict(iteration='I-82', utc=datetime.now(timezone.utc).isoformat(),
        source_and_inputs=bindings, scope='Two closed full-route arms; no new physics/controller calls, no post-outcome gate changes.',
        frozen_definitions_sha256=sha(HERE/'definitions.json')))
    raw, rows, signals, metadata, outcomes = {}, {}, {}, {}, {}
    for arm in ARMS:
        inner = runs/arm/'child/campaign/runs/eight_m100_N'
        raw[arm] = load(inner/'precision.npz')
        summary = json.loads((inner/'summary.json').read_text())
        metadata[arm] = json.loads((inner/'provenance.json').read_text())
        outcomes[arm] = json.loads((runs/arm/'outcome.json').read_text())
        rows[arm], signals[arm] = core.summarize(raw[arm], summary)
        for snap in rows[arm]['focus']['snapshots']:
            target = snap['requested_time_s']
            available = raw[arm]['time_s'][0]-1e-9 <= target <= raw[arm]['time_s'][-1]+1e-9
            snap['recorded_state_available'] = bool(available)
            if not available:
                snap['qualification'] = 'Requested focus time is beyond completed recording; nearest endpoint is not a state at the requested time.'
        with (out/(arm+'_signals.npz')).open('xb') as f:
            np.savez_compressed(f, **signals[arm])
    setup = pair_setup(raw, metadata, protocol)
    decision = core.compare(rows['B030'], rows['B060'], definitions)
    if not all(x['passed'] for x in setup):
        decision.update(status='INVALID_SETUP', passed=False)
    report = dict(iteration='I-82', cases=rows, setup_checks=setup, decision=decision,
        case_outcomes=outcomes, no_new_physics=True, no_automatic_adoption=True, full_repo_suite_claim=False,
        current_case_only=True, fixed_gains=True,
        interpretation='Capacity-interface comparison, including preparation use of operating bounds. Full-route metrics remain primary; fixed local episode descriptive.')
    save(out/'report.json', report)
    plot(rows, signals, raw, out, decision)
    lines = ['# I-82 matched current belt-capacity comparison', '', decision['status'], '',
        '| Metric | 0.30 m/s | 0.60 m/s |', '| --- | ---: | ---: |']
    for label, group, key, scale in [('Moving timed RMS (mm)', 'tracking', 'moving_timed_rms_m', 1000),
        ('Full timed peak (mm)', 'tracking', 'full_timed_peak_m', 1000),
        ('Moving geometric RMS (mm)', 'tracking', 'moving_geometric_rms_m', 1000),
        ('Final goal error (mm)', 'tracking', 'final_goal_error_m', 1000),
        ('Own-target up error peak (deg)', 'attitude', 'own_reference_up_peak_deg', 1),
        ('Absolute tilt peak (deg)', 'attitude', 'absolute_tilt_peak_deg', 1),
        ('XY speed peak (m/s)', 'motion', 'full_planar_speed_peak_m_s', 1)]:
        values = [rows[arm][group][key] for arm in ARMS]
        text = ['unavailable' if x is None else f'{scale*x:.6f}' for x in values]
        lines.append('| '+label+' | '+' | '.join(text)+' |')
    lines += ['', 'Four-condition final settling: '+', '.join(arm+'='+str(rows[arm]['settling']['four_condition_passed']) for arm in ARMS)+'.',
        '', 'Failed fixed checks:']
    lines += ['- '+x['name']+': actual '+str(x['actual'])+', limit '+str(x['limit']) for x in decision['checks'] if not x['passed']]
    lines += ['', 'Full-route completion, numerical consistency, screen acceptance and default adoption are separate. Ideal surface-speed capacity is not a motor torque/load validation. No1msforce conclusion follows from these motion metrics.']
    (out/'summary.md').write_text('\n'.join(lines)+'\n')
    assert all(sha(ROOT/name) == x['sha256'] for name, x in bindings.items())
    assert all(sha(ROOT/name) == value for name, value in binding.items())
    save(out/'artifact_manifest.json', {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(out.iterdir()) if p.is_file()}})
    print(json.dumps({'status': decision['status'], 'setup_passed': sum(x['passed'] for x in setup),
        'setup_checks': len(setup), 'performance_passed': sum(x['passed'] for x in decision['checks']),
        'performance_checks': len(decision['checks'])}))


if __name__ == '__main__':
    main()
