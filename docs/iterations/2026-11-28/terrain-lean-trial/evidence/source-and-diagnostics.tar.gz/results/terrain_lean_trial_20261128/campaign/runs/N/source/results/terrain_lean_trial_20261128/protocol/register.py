"""Freeze the single prospective I85 native/terrain-lean comparison."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for value in iter(lambda: f.read(1024 * 1024), b''):
            h.update(value)
    return h.hexdigest()


def main():
    out = BASE / 'protocol/frozen_stage01'
    if out.exists():
        raise FileExistsError(out)
    old84_path = ROOT / 'results/terrain_recovery_preview_20261128/protocol/frozen_stage01/registration.json'
    old84 = json.loads(old84_path.read_text())
    assert sha(old84_path) == 'bb8712febb1e5a57b0f274806c88482fa7a253d2d69b977d254ba7379f6d404b'
    sources, inputs = dict(old84['source_sha256']), dict(old84['input_sha256'])
    old83_path = ROOT / 'results/recovery_assessment_20261128/protocol/frozen_stage01/protocol.json'
    old83 = json.loads(old83_path.read_text())
    assert sha(old83_path) == '85f16fd35cbadd3ead3741b9d76f539df26cc7b58f8b3e882ff9de12a094e25c'
    for name, value in old83['sources'].items():
        sources[name] = value['sha256']
    for name, value in old83['inputs'].items():
        inputs[name] = value['sha256']
    old82_path = ROOT / 'results/current_belt_capacity_20261128/protocol/frozen_stage01/protocol.json'
    old82 = json.loads(old82_path.read_text())
    old82_seal_path = ROOT / 'results/current_belt_capacity_20261128/campaign/outputs_sealed.json'
    old82_seal = json.loads(old82_seal_path.read_text())
    for group in ['source_sha256', 'input_sha256']:
        for name, expected in old82[group].items():
            assert sha(ROOT / name) == expected, name
    for name, x in old82_seal['files'].items():
        assert sha(old82_seal_path.parent.parent / name) == x['sha256'], name
    for name, expected in {**sources, **inputs}.items():
        assert sha(ROOT / name) == expected, name
    for folder in ['runtime', 'runner', 'evaluation', 'publication']:
        assert (BASE / folder).is_dir(), folder
        for path in sorted((BASE / folder).glob('*.py')):
            sources[str(path.relative_to(ROOT))] = sha(path)
        for path in sorted((BASE / folder).glob('*.json')):
            inputs[str(path.relative_to(ROOT))] = sha(path)
        proofs = []
        for pattern in ['contracts*/receipt.json', 'contracts*/outcome.json']:
            proofs += sorted((BASE / folder).glob(pattern))
        assert proofs, 'Missing scoped prephysics contract receipt: ' + folder
        for path in proofs:
            inputs[str(path.relative_to(ROOT))] = sha(path)
    sources[str(Path(__file__).resolve().relative_to(ROOT))] = sha(Path(__file__).resolve())
    required = [old84_path, old83_path,
        ROOT / 'results/current_belt_capacity_20261128/campaign/runs/B030/outcome.json',
        ROOT / 'results/current_belt_capacity_20261128/campaign/runs/B060/outcome.json',
        ROOT / 'results/current_belt_capacity_20261128/campaign/runs/B060/native_comparison.json',
        ROOT / 'results/recovery_assessment_20261128/protocol/definitions.json',
        ROOT / 'results/recovery_assessment_20261128/evaluation/completed_stage01/report.json']
    for path in required:
        inputs[str(path.relative_to(ROOT))] = sha(path)
    runner = json.loads((BASE / 'runner/settings.json').read_text())
    policy = json.loads((BASE / 'runtime/settings.json').read_text())
    definitions = json.loads((BASE / 'evaluation/definitions.json').read_text())
    assert runner['arms'] == ['N', 'T'] and runner['operating_belt_cap_m_s'] == .6
    assert runner['duration_s'] == 133. and runner['expected_rows'] == 26601
    assert runner['active_window_s'] == definitions['active_window_s'] == [99.5, 104.]
    assert policy['policy']['horizon_s'] == .5 and policy['policy']['extra_tilt_deg'] == 2.
    assert policy['policy']['extra_rate_rad_s'] == .15
    protocol = dict(iteration='I-85', utc=datetime.now(timezone.utc).isoformat(),
        source_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        source_sha256=sources, input_sha256=inputs, runner_settings=runner,
        policy_settings=policy, definitions=definitions, optical_scene=old84['sensor_scene'],
        original_i82_protocol_sha256=sha(old82_path), original_i82_output_seal_sha256=sha(old82_seal_path),
        original_i82_bindings_verified=dict(sources=93, inputs=59, outputs=456),
        scope='One prospective fresh N/T full133s pair. Old I82/I83 outcomes are known; policy/criteria fixed before these new outcomes. No gain/default/estimator change.',
        execution_order=['N', 'T'], baseline_gate='Fresh N all79/26601 bit-exact I82B060 before T.',
        stop_rule='One fixed candidate only; null, failed, incomplete or non-improving result parks terrain-assisted direction for this task and returns next work to baseline recovery.',
        measurement_boundary='Exact simulated q/v and previous actual commands; native momentum observer/current holding feedback; only previously delivered four-view depth in terrain memory. No future solver contact/terrain query used by control.',
        full_repo_suite_claim=False, no_automatic_adoption=True)
    out.mkdir(parents=True)
    for name, expected in sources.items():
        target = out / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
        assert sha(target) == expected
    (out / 'registration.json').write_text(json.dumps(protocol, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({'registration': str((out / 'registration.json').relative_to(ROOT)),
        'sha256': sha(out / 'registration.json'), 'sources': len(sources), 'inputs': len(inputs),
        'new_physics_started': False}))


if __name__ == '__main__':
    main()
