"""I85 runner contracts; synthetic arrays/dispatch only, never Gazebo physics."""
from pathlib import Path
from types import SimpleNamespace
import copy
import sys

import numpy as np
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_case as runner


def precision(rows=5):
    fields=dict(time_s=np.linspace(98.,100.,rows),exact_applied=np.zeros((rows,5)))
    for name in ('exact_qpos','exact_qvel','exact_observer_wrench','exact_observer_generalized',
                 'exact_observer_interval_mean','exact_previous_applied','truth_time_s','truth_patch_loads_N',
                 'truth_patch_points_m','truth_patch_contact_counts','truth_equivalent_point_m'):
        fields[name]=np.zeros((rows,2))
    for i in range(79-len(fields)):fields['other_'+str(i)]=np.zeros(rows)
    return fields


def test_byte_comparison_distinguishes_negative_zero_and_nan_payloads():
    original=np.array([[0.,np.nan]])
    negative=original.copy();negative[0,0]=-0.
    assert runner.differing_rows(original,negative).tolist()==[True]
    payload=original.copy();payload.view(np.uint64)[0,1]^=np.uint64(1)
    assert runner.differing_rows(original,payload).tolist()==[True]
    assert not runner.differing_rows(original,original.copy()).any()


def test_full_native_comparison_checks_all79_bytes(tmp_path,monkeypatch):
    monkeypatch.setitem(runner.SETTINGS,'expected_rows',5)
    first=precision();first['time_s']=np.linspace(0.,133.,5)
    left,right=tmp_path/'left.npz',tmp_path/'right.npz'
    np.savez(left,**first);np.savez(right,**first)
    assert runner.exact_comparison(left,right)['all79_fields_exact']
    first['exact_observer_wrench'][3,0]=-0.;np.savez(right,**first)
    with pytest.raises(AssertionError,match='exact_observer_wrench'):runner.exact_comparison(left,right)


def test_prefix_allows_later_closed_loop_state_change_only(tmp_path):
    native=precision();candidate={k:v.copy() for k,v in native.items()}
    candidate['exact_applied'][3,0]=.1;candidate['exact_qpos'][4,0]=.2
    n,t=tmp_path/'n.npz',tmp_path/'t.npz';np.savez(n,**native);np.savez(t,**candidate)
    result=runner.prefix_comparison(n,t)
    assert result['first_applied_difference_index']==3
    candidate['exact_observer_wrench'][3,0]=.01;np.savez(t,**candidate)
    with pytest.raises(AssertionError,match='before first applied'):runner.prefix_comparison(n,t)


def test_inactive_reference_change_invalidates_prefix(tmp_path):
    native=precision();candidate={k:v.copy() for k,v in native.items()};candidate['other_0'][0]=-0.
    n,t=tmp_path/'n.npz',tmp_path/'t.npz';np.savez(n,**native);np.savez(t,**candidate)
    with pytest.raises(AssertionError,match='Inactive prefix'):runner.prefix_comparison(n,t)


def test_rate_override_changes_only_angular_copy_and_inactive_identity():
    velocity=np.arange(9,dtype=float);before=velocity.copy()
    inactive=dict(override_angular_reference=False,rate_body_rad_s=np.ones(3))
    assert runner.angular_reference(velocity,inactive) is velocity
    active=dict(override_angular_reference=True,rate_body_rad_s=np.array([.1,.2,.3]))
    changed=runner.angular_reference(velocity,active)
    np.testing.assert_array_equal(velocity,before)
    np.testing.assert_array_equal(changed[[0,1,2,6,7,8]],before[[0,1,2,6,7,8]])
    np.testing.assert_array_equal(changed[3:6],active['rate_body_rad_s'])


def test_persistent_reference_and_feedback_hooks_use_native_dispatch_and_cache():
    data=SimpleNamespace(time=100.5,qpos=np.r_[np.zeros(3),1.,np.zeros(6)],qvel=np.zeros(9))
    controller=SimpleNamespace(plant=SimpleNamespace(data=data),reference_attitude=lambda n,a:np.array([1.,0.,0.,0.]))
    seen=[]
    def feedback(q,v,f,n,m,touching):
        seen.append((v.copy(),f.copy(),n.copy()));return np.zeros(5),dict(reference_qvel=v.copy())
    controller._terrain_feedback=feedback
    class Policy:
        def __init__(self):self.calls=0;self.updates=0;self.cache=None
        def get_reference(self,c,n,a):
            self.calls+=1
            if self.cache is None:
                self.updates+=1;self.cache=dict(quat=np.array([.99995,.01,0.,0.]),native_quat=np.array([1.,0.,0.,0.]),
                    rate_world_rad_s=np.array([.1,.2,0.]),rate_body_rad_s=np.array([.1,.2,0.]),override_angular_reference=True,diagnostics={})
            return copy.deepcopy(self.cache)
        def cached_result(self):return copy.deepcopy(self.cache)
    normal=np.array([0.,0.,1.]);accel=np.zeros(2);vref=np.arange(9,dtype=float)
    def command(c,xy,velocity,acceleration):
        quat=c.reference_attitude(normal,acceleration)
        _,result=c._terrain_feedback(np.zeros(10),vref,np.arange(5,dtype=float),normal,{},True)
        return np.zeros(5),dict(reference_qpos=np.r_[xy,0.,quat,np.zeros(3)],reference_quat=quat,
            heading_command=np.zeros(5),estimate=dict(normal=normal),feedback_reference_qvel=result['reference_qvel'])
    capture=runner.CameraAndPolicy('T',command);capture.controller=controller
    capture.native_reference=controller.reference_attitude;capture.native_feedback=controller._terrain_feedback
    capture.policy=Policy();capture.causal=SimpleNamespace(advance=lambda q,t:dict(captured=None,maximum_delivered_capture_s=100.45),captured_batches=2011,delivered_batches=2010)
    capture.install_policy_hooks(controller)
    _,info=capture.command(controller,np.zeros(2),np.zeros(2),accel)
    np.testing.assert_array_equal(info['reference_quat'],controller.reference_attitude(normal,accel))
    assert capture.policy.calls==2 and capture.policy.updates==1
    np.testing.assert_array_equal(seen[0][0][3:6],[.1,.2,0.])
    np.testing.assert_array_equal(vref,np.arange(9,dtype=float))
    np.testing.assert_array_equal(capture.rows[0]['native_reference_quat'],[1.,0.,0.,0.])


def test_saved_sidecar_keeps_own_native_reference_and_actual_feedback_rate(tmp_path):
    capture=runner.CameraAndPolicy('T',None)
    capture.rows=[dict(time_s=100.,native_reference_quat=np.array([1.,0.,0.,0.]),changed_reference_quat=np.array([.99995,.01,0.,0.]),
        rate_world_rad_s=np.array([.1,0.,0.]),rate_body_rad_s=np.array([.1,0.,0.]),override_angular_reference=True,
        feedback_reference_qvel=np.r_[np.zeros(3),.1,np.zeros(5)],estimated_normal=np.array([0.,0.,1.]),captured_batches=2001,
        delivered_batches=2000,raw_qpos=np.zeros(10),raw_qvel=np.zeros(9),applied=np.zeros(5),
        diagnostics=dict(extra_chart_rad=np.array([.01,0.]),extra_chart_rate_rad_s=np.array([.1,0.]),envelope=.5,map_accepted=True))]
    capture.save(tmp_path)
    with np.load(tmp_path/'policy.npz') as saved:
        np.testing.assert_array_equal(saved['native_reference_quat'][0],[1.,0.,0.,0.])
        assert saved['map_accepted'][0] and saved['window_weight'][0]==.5
        assert saved['feedback_reference_qvel'][0,3]==.1
