"""Seal new recovery definitions/source before reading existing case arrays."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
I82 = ROOT / 'results/current_belt_capacity_20261128'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    out = BASE / 'protocol/frozen_stage01'
    if out.exists():
        raise FileExistsError(out)
    old_path = I82 / 'protocol/frozen_stage01/protocol.json'
    old = json.loads(old_path.read_text())
    assert sha(old_path) == 'ce39ad0f0cd6c3748e764b72d413b45ad20353c1deb641bdbd722c35402dc400'
    for group in ['source_sha256', 'input_sha256']:
        for name, expected in old[group].items():
            assert sha(ROOT / name) == expected, name
    seal_path = I82 / 'campaign/outputs_sealed.json'
    seal = json.loads(seal_path.read_text())
    assert sha(seal_path) == '957e356fc264ee4b38cee442acf3908d053809518223a3c776b269b7806335f8'
    for name, x in seal['files'].items():
        assert sha(I82 / name) == x['sha256'], name
    sources = [Path(__file__).resolve()]
    for folder in ['evaluation', 'verification']:
        sources += sorted((BASE / folder).glob('*.py'))
    assert any(p.name == 'core.py' for p in sources)
    assert any(p.name.startswith('evaluate') for p in sources)
    assert any(p.name.startswith('verify') for p in sources)
    sources += [ROOT / 'results/tangent_heading_routes_20261127/runtime/route.py']
    sources += [ROOT / 'results/tangent_heading_routes_20261127/evaluation/metrics.py']
    inputs = [BASE / 'protocol/definitions.json', old_path, seal_path,
              I82 / 'evaluation/completed_stage01/report.json']
    for arm in ['B030', 'B060']:
        outer = I82 / 'campaign/runs' / arm
        inputs += [outer / 'child/campaign/runs/eight_m100_N/precision.npz',
                   outer / 'outcome.json', outer / 'native_comparison.json',
                   I82 / 'campaign' / (arm + '.observed_exit.json')]
    for folder in ['evaluation', 'verification']:
        inputs += sorted((BASE / folder).glob('contracts*/receipt.json'))
        inputs += sorted((BASE / folder).glob('contracts*/outcome.json'))
    binding = lambda paths: {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths}
    protocol = {
        'iteration': 'I-83', 'registered_before_new_reductions_utc': datetime.now(timezone.utc).isoformat(),
        'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'scope': 'Previously known I-82 outcomes; new descriptive metrics fixed before new reductions, not blind preregistration. No simulator/controller calls.',
        'definitions': json.loads((BASE / 'protocol/definitions.json').read_text()),
        'sources': binding(sources), 'inputs': binding(inputs),
        'original_i82_binding_counts_verified': {'sources': 93, 'inputs': 59, 'closed_outputs': 456},
        'new_physics': False, 'default_change': False
    }
    out.mkdir(parents=True)
    for p in sources:
        target = out / 'source' / p.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, target)
        assert sha(target) == sha(p)
    (out / 'protocol.json').write_text(json.dumps(protocol, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({'protocol': str((out / 'protocol.json').relative_to(ROOT)),
        'sha256': sha(out / 'protocol.json'), 'source_count': len(sources), 'input_count': len(inputs),
        'new_case_array_values_read': False}))


if __name__ == '__main__':
    main()
