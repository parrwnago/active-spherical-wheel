"""Reduce existing closed I-82 recordings using fixed I-83 recovery definitions."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('i83_recovery_core', HERE/'core.py')
core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)


def digest(path):
    data = Path(path).read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def clean(value):
    if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [clean(v) for v in value]
    if isinstance(value, np.ndarray): return clean(value.tolist())
    if isinstance(value, np.generic): return clean(value.item())
    return value


def write_json(path, value):
    path.write_text(json.dumps(clean(value), indent=2, sort_keys=True, allow_nan=False)+'\n')


def selection(t, lo, hi):
    return (t >= lo-1e-9) & (t <= hi+1e-9)


def command_metrics(raw, mask):
    t = raw['time_s']; held = raw['command_held_after_row'].astype(bool)
    selected = held & mask
    duration = np.r_[np.diff(t), 0.]
    request, applied, previous = (raw[k] for k in ('exact_requested', 'exact_applied', 'exact_previous_applied'))
    bounds = raw['exact_input_bounds']
    result = dict(held_seconds=float(duration[selected].sum()), held_intervals=int(selected.sum()),
        terminal_unheld_excluded=True)
    for name, scale in [('own', bounds), ('original_030', np.broadcast_to([1.5, .6, .6, .3, .3], bounds.shape))]:
        clipped = abs(request) > scale+1e-12
        exceeded = abs(applied) > scale+1e-12
        excess = np.linalg.norm((request-np.clip(request, -scale, scale))/scale, axis=1)
        steps = np.linalg.norm((applied-previous)/scale, axis=1)
        result[name] = dict(requested_clipped_any_seconds=float(duration[selected & clipped.any(axis=1)].sum()),
            requested_clipped_each_seconds=np.sum(duration[selected, None]*clipped[selected], axis=0),
            applied_exceeded_any_seconds=float(duration[selected & exceeded.any(axis=1)].sum()),
            applied_exceeded_each_seconds=np.sum(duration[selected, None]*exceeded[selected], axis=0),
            requested_excess=core.stats(excess[selected]), applied_steps=core.stats(steps[selected]),
            dimensional_applied_step_peak=np.max(abs(applied[selected]-previous[selected]), axis=0))
    return result


def window_report(s, mask, definitions):
    keys = ('intended_distance_m', 'global_distance_m', 'timed_position_error_m',
        'spatial_velocity_error_m_s', 'timed_velocity_error_m_s', 'own_up_error_deg',
        'absolute_tilt_deg', 'world_z_rate_rad_s', 'xy_speed_m_s', 'progress_lag_m',
        'along_velocity_error_m_s', 'cross_velocity_error_m_s')
    result = {k: core.stats(abs(s[k][mask]) if k == 'world_z_rate_rad_s' else s[k][mask]) for k in keys}
    t = s['time_s'][mask]
    result['clock_s'] = [float(t[0]), float(t[-1])]
    result['samples'] = len(t)
    for key, bound in [('intended_distance_m', definitions['thresholds']['path_distance_m']),
                       ('timed_position_error_m', definitions['thresholds']['timed_position_m'])]:
        values = s[key][mask]
        result[key].update(integral_m_s=float(np.trapz(values, t)),
            excess_integral_m_s=float(np.trapz(np.maximum(values-bound, 0.), t)),
            peak_time_s=float(t[np.argmax(values)]))
    result['progress_lag_m']['minimum'] = float(np.min(s['progress_lag_m'][mask]))
    result['lower_branch_clamp_samples'] = int(s['lower_branch_clamp'][mask].sum())
    result['upper_branch_clamp_samples'] = int(s['upper_branch_clamp'][mask].sum())
    result['forward_motion_sample_fraction'] = float(np.mean(s['forward_motion'][mask]))
    return result


def assess(raw, definitions):
    t = raw['time_s']; dt = definitions['control_dt_s']; clock_tol = definitions['thresholds']['clock_grid_tolerance_s']
    held = raw['command_held_after_row'].astype(bool)
    integrity = dict(rows=len(t), full_grid=bool(len(t) == definitions['expected_rows'] and
        abs(t[0]) <= clock_tol and abs(t[-1]-definitions['recording_end_s']) <= clock_tol and
        np.all(abs(np.diff(t)-dt) <= clock_tol)),
        finite_required_arrays=all(np.isfinite(a).all() for a in raw.values()),
        held_mask=bool(np.array_equal(held, np.arange(len(t)) < len(t)-1)),
        prior_input_identity=bool(np.array_equal(raw['exact_previous_applied'][1:], raw['exact_applied'][:-1])),
        clipping_identity=bool(np.array_equal(raw['exact_applied'][held],
            np.clip(raw['exact_requested'][held], -raw['exact_input_bounds'][held], raw['exact_input_bounds'][held]))))
    if not all(integrity[k] for k in ('full_grid', 'finite_required_arrays', 'held_mask', 'prior_input_identity', 'clipping_identity')):
        raise AssertionError('Invalid saved recording: '+str(integrity))
    s = core.signals(raw, definitions); good = core.criteria(s, definitions)
    focus = selection(t, definitions['event_anchor_s'], definitions['departure_search_end_s'])
    post = selection(t, definitions['event_anchor_s'], definitions['recording_end_s'])
    moving = (t >= definitions['route']['start_s']-clock_tol) & (t < definitions['route']['start_s']+definitions['route']['moving_duration_s']-clock_tol)
    full = selection(t, 0., definitions['recording_end_s'])
    result = dict(integrity=integrity,
        whole_route=dict(moving_timed_position_error_m=core.stats(s['timed_position_error_m'][moving]),
            moving_global_path_distance_m=core.stats(s['global_distance_m'][moving]),
            full_timed_peak_m=float(np.max(s['timed_position_error_m'])),
            final_goal_error_m=float(np.linalg.norm(s['xy'][-1]-core.path_geometry(definitions['route'])['xy'][-1]))),
        focus=window_report(s, focus, definitions), postanchor=window_report(s, post, definitions),
        recovery={name: core.recovery(t, values, definitions) for name, values in good.items()},
        commands=dict(full=command_metrics(raw, full),
            focus=command_metrics(raw, core.held_window(t, definitions['event_anchor_s'], definitions['departure_search_end_s'], clock_tol)),
            postanchor=command_metrics(raw, post)))
    b = definitions['thresholds']
    components = dict(path_distance=s['intended_distance_m'] <= b['path_distance_m']+b['comparison_tolerance'],
        spatial_velocity=s['spatial_velocity_error_m_s'] <= b['velocity_error_m_s']+b['comparison_tolerance'],
        own_up=s['own_up_error_deg'] <= b['own_reference_up_error_deg']+b['comparison_tolerance'],
        absolute_tilt=s['absolute_tilt_deg'] <= b['absolute_body_tilt_guard_deg']+b['comparison_tolerance'],
        spin=abs(s['world_z_rate_rad_s']) <= b['absolute_world_z_rate_rad_s']+b['comparison_tolerance'],
        timed_position=s['timed_position_error_m'] <= b['timed_position_m']+b['comparison_tolerance'],
        timed_velocity=s['timed_velocity_error_m_s'] <= b['velocity_error_m_s']+b['comparison_tolerance'])
    result['component_good_sample_fractions'] = {name: dict(focus=float(np.mean(values[focus])),
        postanchor=float(np.mean(values[post]))) for name, values in components.items()}
    i = int(np.argmin(abs(t-definitions['event_anchor_s'])))
    result['at_anchor'] = {name: clean(s[name][i]) for name in ('time_s', 'intended_distance_m',
        'global_distance_m', 'projected_u', 'clock_u', 'progress_lag_m', 'spatial_velocity_error_m_s',
        'timed_position_error_m', 'own_up_error_deg', 'absolute_tilt_deg', 'world_z_rate_rad_s')}
    for name, values in good.items():
        s['good__'+name] = values
        row = result['recovery'][name]
        entry = row['primary']['entry_s']
        index = None if entry is None else int(np.argmin(abs(t-entry)))
        row['primary']['entry_lower_branch_clamped'] = None if index is None else bool(s['lower_branch_clamp'][index])
        row['primary']['entry_projected_u'] = None if index is None else float(s['projected_u'][index])
    return result, s


def plot_comparison(cases, signals, definitions, focus):
    lo, hi = (definitions['event_anchor_s'], definitions['departure_search_end_s'] if focus else definitions['recording_end_s'])
    fig, axes = plt.subplots(5, 1, figsize=(12, 11), sharex=True)
    colors = {'B030': '#235fa4', 'B060': '#008c7a'}
    for arm, s in signals.items():
        keep = selection(s['time_s'], lo, hi); t = s['time_s'][keep]; color = colors[arm]
        label = arm+' ('+('0.30' if arm == 'B030' else '0.60')+' m/s)'
        axes[0].plot(t, 1000*s['intended_distance_m'][keep], color=color, label=label+' intended section')
        axes[0].plot(t, 1000*s['global_distance_m'][keep], color=color, ls=':', alpha=.6)
        axes[1].plot(t, 1000*s['spatial_velocity_error_m_s'][keep], color=color, label=label)
        axes[2].plot(t, s['own_up_error_deg'][keep], color=color)
        axes[2].plot(t, s['absolute_tilt_deg'][keep], color=color, ls=':', alpha=.6)
        axes[3].plot(t, np.degrees(abs(s['world_z_rate_rad_s'][keep])), color=color)
        axes[4].plot(t, 1000*s['progress_lag_m'][keep], color=color)
    axes[0].axhline(20., color='k', ls='--', lw=.8); axes[0].set_ylabel('Path distance (mm)')
    axes[1].axhline(20., color='k', ls='--', lw=.8); axes[1].set_ylabel('Spatial velocity\nresidual (mm/s)')
    axes[2].axhline(2., color='k', ls='--', lw=.8); axes[2].axhline(15., color='gray', ls='--', lw=.8)
    axes[2].set_ylabel('Own up / dotted\nabsolute tilt (deg)')
    axes[3].axhline(np.degrees(.05), color='k', ls='--', lw=.8); axes[3].set_ylabel('Absolute world-z\nrotation (deg/s)')
    axes[4].axhline(0., color='gray', lw=.8); axes[4].set_ylabel('Clock minus spatial\nprogress (mm)')
    axes[4].set_xlabel('Recorded simulation time (s)')
    axes[0].legend(loc='upper right', fontsize=8)
    for ax in axes:
        ax.grid(alpha=.25); ax.set_xlim(lo, hi)
    fig.suptitle('I-83 recovery assessment: '+('fixed focus' if focus else 'full follow-through')+
        '\nOriginal I-82 recordings; first rejoin, sustained return and residual rotation are separate')
    fig.tight_layout(rect=(0., 0., 1., .95))
    return fig


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--definitions', type=Path, required=True)
    parser.add_argument('--seal', type=Path, required=True); parser.add_argument('--runs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(); out = args.output; out.mkdir(parents=True, exist_ok=False)
    definitions = json.loads(args.definitions.read_text()); seal = json.loads(args.seal.read_text())
    seal_base = args.seal.resolve().parent.parent
    inputs = {arm: args.runs/arm/'child/campaign/runs/eight_m100_N/precision.npz' for arm in definitions['arms']}
    bindings = {}
    for path in [Path(__file__), HERE/'core.py', HERE/'test_core.py', args.definitions, args.seal, *inputs.values(),
                 ROOT/'results/tangent_heading_routes_20261127/evaluation/metrics.py']:
        bindings[str(path.resolve().relative_to(ROOT))] = digest(path)
    for path in inputs.values():
        relative = str(path.resolve().relative_to(seal_base))
        if digest(path) != seal['files'][relative]: raise AssertionError('I82 sealed input changed: '+relative)
    if not (seal['all_returned_zero'] and seal['source_inputs_unchanged']):
        raise AssertionError('I82 output seal does not establish closed unchanged recordings')
    registration = dict(iteration='I-83', utc=datetime.now(timezone.utc).isoformat(),
        definitions_scope=definitions['scope'], source_and_inputs=bindings,
        note='Created before this reducer opens recorded arrays; parent freeze precedes invocation.',
        new_physics=False, old_outputs_modified=False)
    write_json(out/'registered_before_arrays.json', registration)
    for name in ('core.py', 'test_core.py', 'evaluate.py'): shutil.copy2(HERE/name, out/name)
    shutil.copy2(args.definitions, out/'definitions.json')
    required = ['time_s', 'exact_qpos', 'exact_qvel', 'exact_reference_quat', 'exact_reference_xy',
        'exact_reference_velocity_m_s', 'exact_requested', 'exact_applied', 'exact_previous_applied',
        'exact_input_bounds', 'command_held_after_row']
    cases, all_signals = {}, {}
    for arm, path in inputs.items():
        with np.load(path, allow_pickle=False) as packet:
            raw = {key: packet[key].copy() for key in required}
        cases[arm], all_signals[arm] = assess(raw, definitions)
        np.savez_compressed(out/(arm+'_signals.npz'), **all_signals[arm])
    report = dict(iteration='I-83', scope=definitions['scope'], definitions=definitions,
        new_physics=False, new_controller=False, old_I82_gates_modified=False,
        branch_scope='Only100.5to133s; preanchor full signals retained but branch_applicable=False. Whole-route metrics use global path distance.',
        no_causal_or_global_adoption_claim=True, case_histories_diverge_before_event=True,
        cases=cases, input_source_bindings=bindings)
    write_json(out/'report.json', report)
    lines = ['# I-83: sustained recovery assessment', '', definitions['scope'], '',
        'All elapsed times use the common 100.5 s clock anchor, not a measured disturbance onset.', '',
        '| Criterion | Arm | Classification | First entry (s) | 2s entry / confirmation (s) | Later qualifying exits | Sustained through end |',
        '| --- | --- | --- | ---: | --- | ---: | --- |']
    for name in definitions['criteria']:
        for arm in definitions['arms']:
            row = cases[arm]['recovery'][name]; p = row['primary']
            fmt = lambda value: '—' if value is None else f'{value:.3f}'
            lines.append(f"| {name} | {arm} | {row['classification']} | {fmt(row['first_threshold_entry_s'])} | "
                f"{fmt(p['entry_s'])} / {fmt(p['confirmation_s'])} | {p['later_qualifying_exit_count']} | {row['last_good_tail']['sustained_through_end']} |")
    lines += ['', 'A first threshold crossing is not sustained recovery. Right-censored and no-departure cases retain null recovery times.',
        'Intended-section distance, spatial nominal velocity and raw-reference attitude are separate from clocked tracking and world-upright tilt.',
        'Spin is a separate stricter recovery condition. Later exits can be new terrain disturbances.',
        'The 1s sensitivity, clipping at own/original bounds and complete recovery records are in report.json.', '']
    (out/'summary.md').write_text('\n'.join(lines))
    figures = []
    for focus, name in [(True, 'focus_recovery.png'), (False, 'followthrough_recovery.png')]:
        fig = plot_comparison(cases, all_signals, definitions, focus); fig.savefig(out/name, dpi=150); figures.append(fig)
    with PdfPages(out/'recovery_assessment.pdf') as pdf:
        for fig in figures: pdf.savefig(fig); plt.close(fig)
    write_json(out/'artifact_manifest.json', dict(files={p.name: digest(p) for p in sorted(out.iterdir()) if p.is_file()}))
    print(json.dumps(dict(output=str(out), cases=list(cases), new_physics=False)))


if __name__ == '__main__':
    main()
