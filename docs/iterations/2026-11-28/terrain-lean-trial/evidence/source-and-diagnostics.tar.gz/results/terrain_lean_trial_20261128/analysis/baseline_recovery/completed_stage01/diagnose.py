"""One posthoc diagnostic of the known I-83 B060 return interruption.

Old outcomes are known. This does not read new I-85 case outputs, run a
controller/observer, simulate physics, tune thresholds or change acceptance.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
RAW = ROOT/'results/current_belt_capacity_20261128/campaign/runs/B060/child/campaign/runs/eight_m100_N/precision.npz'
SEAL = ROOT/'results/current_belt_capacity_20261128/campaign/outputs_sealed.json'
CORE = ROOT/'results/recovery_assessment_20261128/evaluation/core.py'
DEFS = ROOT/'results/recovery_assessment_20261128/protocol/definitions.json'
WINDOW = [105.4, 106.1]
SNAPSHOTS = [105.4, 105.5, 105.585, 105.59, 105.7, 105.9, 106., 106.005, 106.1]
FAMILIES = ['shell_A', 'shell_B', 'belt_A', 'belt_B']
BLOCKS = [('XY_position', 0, 2), ('height', 2, 3), ('roll_pitch_attitude', 3, 5),
    ('heading_position', 5, 6), ('derived_rolling_shaft_error', 6, 7),
    ('cyclic_shell_position', 7, 9), ('body_linear_velocity', 9, 12),
    ('body_angular_velocity', 12, 15), ('shaft_velocity', 15, 16), ('shell_velocities', 16, 18)]
COMMANDS = ['exact_equilibrium_command', 'exact_rolling_feedforward', 'exact_support_command',
    'exact_lqr_command', 'exact_transition_command_delta', 'exact_heading_command',
    'exact_fade_command_delta', 'exact_clipping_command_delta']
REQUIRED = ['time_s', 'truth_time_s', 'truth_patch_loads_N', 'truth_patch_contact_counts',
    'exact_qpos', 'exact_qvel', 'exact_reference_quat', 'exact_reference_xy',
    'exact_reference_velocity_m_s', 'exact_reference_qvel', 'exact_feedback_reference_qvel',
    'exact_allocation_drive_reference', 'exact_requested', 'exact_applied', 'exact_previous_applied',
    'exact_input_bounds', 'command_held_after_row', 'exact_feedback_gain', 'exact_error',
    'exact_estimated_support_loads_N', 'exact_estimated_normal', 'exact_effective_phase_rad',
    'exact_sync_weights', *COMMANDS]


def binding(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def clean(value):
    if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)): return [clean(v) for v in value]
    if isinstance(value, np.ndarray): return clean(value.tolist())
    if isinstance(value, np.generic): return clean(value.item())
    return value


def save(path, value):
    path.write_text(json.dumps(clean(value), indent=2, sort_keys=True, allow_nan=False)+'\n')


def dominant(loads):
    return [None if total <= .05 else FAMILIES[int(i)] for total, i in zip(loads.sum(axis=1), np.argmax(loads, axis=1))]


def main():
    out = HERE/'completed_stage01'; out.mkdir(exist_ok=False)
    sources = [Path(__file__), CORE, DEFS, SEAL, RAW,
        ROOT/'results/tangent_heading_routes_20261127/evaluation/command_audit.py',
        ROOT/'results/tangent_heading_routes_20261127/campaign_tools/run_case.py',
        ROOT/'src/spherical_wheel/offroad_control.py', ROOT/'src/spherical_wheel/sim.py',
        ROOT/'results/recovery_assessment_20261128/evaluation/completed_stage01/report.json']
    bindings = {str(p.relative_to(ROOT)): binding(p) for p in sources}
    seal = json.loads(SEAL.read_text())
    raw_relative = str(RAW.relative_to(SEAL.parent.parent))
    if bindings[str(RAW.relative_to(ROOT))] != seal['files'][raw_relative]:
        raise AssertionError('Old B060 recording no longer matches closed I82 seal')
    registration = dict(iteration='I-85 supplementary baseline diagnostic',
        utc=datetime.now(timezone.utc).isoformat(), fixed_window_s=WINDOW, snapshot_s=SNAPSHOTS,
        scope='Posthoc known I83 first-return interruption105.590to106.000; old outcomes known. No new I85 arrays, simulations, control changes, threshold search or acceptance changes.',
        source_and_input_bindings=bindings,
        planned_reductions=['Actual versus clocked/spatial XY velocity', 'Native own-up and absolute tilt',
            'Applied/requested clipping and all command blocks', 'Ten -Kerror blocks and reference-joint excursions',
            'Inferred support versus last1ms instantaneous solver patch loads',
            'Fixed snapshots and largest5ms changes; temporal ordering is not causal proof'],
        truth_timing='Last completed1ms solver sample at command START, not mean over previous5ms hold.',
        command_timing='Row state precedes row new command; previous_applied advanced the state. Snapshots also report previous-row command blocks.')
    save(out/'registered_before_old_arrays.json', registration)
    shutil.copy2(Path(__file__), out/'diagnose.py')
    shutil.copy2(CORE, out/'i83_core.py')
    shutil.copy2(DEFS, out/'i83_definitions.json')
    # No recorded values are opened above this line.
    spec = importlib.util.spec_from_file_location('i85_old_baseline_recovery_core', CORE)
    core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    definitions = json.loads(DEFS.read_text())
    with np.load(RAW, allow_pickle=False) as z: all_raw = {key: z[key].copy() for key in REQUIRED}
    times = all_raw['time_s']
    selected = np.flatnonzero((times >= WINDOW[0]-1e-9) & (times <= WINDOW[1]+1e-9))
    raw = {key: value[selected] for key, value in all_raw.items()}
    t = raw['time_s']; s = core.signals(raw, definitions)
    blocks = {name: -np.einsum('nij,nj->ni', raw['exact_feedback_gain'][:, :, lo:hi], raw['exact_error'][:, lo:hi])
        for name, lo, hi in BLOCKS}
    caps = raw['exact_input_bounds']; requests = raw['exact_requested']; applied = raw['exact_applied']
    reconstruction = sum(raw[key] for key in COMMANDS[:-1])
    checks = dict(clock141rows=bool(len(t) == 141 and np.all(abs(np.diff(t)-.005) <= 1e-9)),
        truth_clock_exact=bool(np.array_equal(raw['truth_time_s'], t)),
        requested_ledger_max_abs_error=float(np.max(abs(reconstruction-requests))),
        applied_ledger_max_abs_error=float(np.max(abs(reconstruction+raw['exact_clipping_command_delta']-applied))),
        lqr_blocks_max_abs_error=float(np.max(abs(sum(blocks.values())-raw['exact_lqr_command']))),
        applied_is_clipped=bool(np.array_equal(applied, np.clip(requests, -caps, caps))),
        zero_angular_reference=bool(not np.any(raw['exact_feedback_reference_qvel'][:, 3:6])))
    if not all(checks[key] for key in ('clock141rows', 'truth_clock_exact', 'applied_is_clipped', 'zero_angular_reference')):
        raise AssertionError(checks)
    if max(checks[k] for k in ('requested_ledger_max_abs_error', 'applied_ledger_max_abs_error', 'lqr_blocks_max_abs_error')) > 1e-7:
        raise AssertionError('Command-block reconstruction exceeds fixed1e-7 arithmetic tolerance')
    estimated = raw['exact_estimated_support_loads_N']; truth = raw['truth_patch_loads_N']
    inferred_family, solver_family = dominant(estimated), dominant(truth)
    clipped = abs(requests) > caps+1e-12
    duration = np.r_[np.diff(t), 0.]
    # All state rows are retained; the hold beginning106.1 is outside the fixed window.
    held = raw['command_held_after_row'].astype(bool) & core.held_window(t, WINDOW[0], WINDOW[1])
    transitions = {}
    for name, labels in [('inferred', inferred_family), ('instantaneous_solver', solver_family)]:
        transitions[name] = [dict(time_s=float(t[i]), previous=labels[i-1], new=labels[i])
            for i in range(1, len(t)) if labels[i] != labels[i-1]]
    statistics = {key: core.stats(s[key]) for key in ('spatial_velocity_error_m_s', 'timed_velocity_error_m_s',
        'own_up_error_deg', 'absolute_tilt_deg', 'intended_distance_m', 'timed_position_error_m')}
    def peaks(name, values):
        a = np.asarray(values); a = a[:, None] if a.ndim == 1 else a
        return [dict(channel=k, time_s=float(t[i]), value=float(a[i, k]))
            for k in range(a.shape[1]) for i in [int(np.argmax(abs(a[:, k])))]]
    extrema = dict(reference_joint_rad_s=peaks('reference', raw['exact_feedback_reference_qvel'][:, 6:9]),
        actual_joint_rad_s=peaks('actual', raw['exact_qvel'][:, 6:9]),
        allocation_mixed_units=peaks('allocation', raw['exact_allocation_drive_reference']),
        requested_mixed_units=peaks('requested', requests))
    changes = {}
    for name, value in [('spatial_velocity_residual', s['spatial_velocity_error_m_s']),
        ('actual_xy_velocity', raw['exact_qvel'][:, :2]), ('joint_reference', raw['exact_feedback_reference_qvel'][:, 6:9]),
        ('requested_scaled_by_caps', requests/caps), ('gain_flattened', raw['exact_feedback_gain'].reshape(len(t), -1)),
        ('current_estimated_normal', raw['exact_estimated_normal'])]:
        a = value[:, None] if value.ndim == 1 else value
        delta = np.linalg.norm(np.diff(a, axis=0), axis=1); i = int(np.argmax(delta))+1
        changes[name] = dict(earliest_largest5ms_change_end_s=float(t[i]), delta_norm=float(delta[i-1]))
    snapshots = []
    for target in SNAPSHOTS:
        i = int(np.argmin(abs(t-target))); source = int(selected[i]); previous = source-1
        previous_blocks = {name: -all_raw['exact_feedback_gain'][previous, :, lo:hi]@all_raw['exact_error'][previous, lo:hi]
            for name, lo, hi in BLOCKS}
        snapshots.append(dict(requested_time_s=target, time_s=float(t[i]), source_index=source,
            actual_velocity_xy_m_s=raw['exact_qvel'][i, :2], clocked_velocity_xy_m_s=raw['exact_reference_velocity_m_s'][i],
            spatial_velocity_xy_m_s=s['spatial_nominal_velocity_m_s'][i],
            spatial_velocity_error_m_s=s['spatial_velocity_error_m_s'][i], along_error_m_s=s['along_velocity_error_m_s'][i],
            cross_error_m_s=s['cross_velocity_error_m_s'][i], own_up_error_deg=s['own_up_error_deg'][i], absolute_tilt_deg=s['absolute_tilt_deg'][i],
            projected_u=s['projected_u'][i], progress_lag_m=s['progress_lag_m'][i],
            inferred_family=inferred_family[i], instantaneous_solver_family=solver_family[i],
            inferred_loads_N=estimated[i], last1ms_solver_loads_N=truth[i], last1ms_resolved_contact_counts=raw['truth_patch_contact_counts'][i],
            current_normal=raw['exact_estimated_normal'][i], effective_phase_rad=raw['exact_effective_phase_rad'][i],
            current_joint_reference_rad_s=raw['exact_feedback_reference_qvel'][i, 6:9], actual_joint_rad_s=raw['exact_qvel'][i, 6:9],
            previous_applied=raw['exact_previous_applied'][i], new_requested=requests[i], new_applied=applied[i],
            command_blocks={key: raw[key][i] for key in COMMANDS}, lqr_error_blocks={key: value[i] for key, value in blocks.items()},
            exact_error18=raw['exact_error'][i],
            preceding_hold=dict(start_s=float(times[previous]), applied=all_raw['exact_applied'][previous],
                requested=all_raw['exact_requested'][previous],
                command_blocks={key: all_raw[key][previous] for key in COMMANDS}, lqr_error_blocks=previous_blocks)))
    report = dict(iteration='I-85 supplementary baseline diagnostic', scope=registration['scope'],
        fixed_window_s=WINDOW, source_recording='I82B060originalnativeLQR.60m_s', verification=checks,
        truth_timing=registration['truth_timing'], command_timing=registration['command_timing'],
        causal_qualification='Sequencing/correlation only; no contact-force interval trace at105s or same-state intervention. This cannot establish the physical cause of the velocity excursion.',
        statistics=statistics, extrema=extrema, largest5ms_changes=changes,
        held_clipping=dict(seconds=float(duration[held].sum()), each_channel_seconds=np.sum(duration[held, None]*clipped[held], axis=0),
            any_seconds=float(duration[held & clipped.any(axis=1)].sum())),
        native_up_2deg_all_pass=bool(np.all(s['own_up_error_deg'] <= 2.+1e-12)),
        absolute_tilt15deg_all_pass=bool(np.all(s['absolute_tilt_deg'] <= 15.+1e-12)),
        instantaneous_family_disagreement_rows=sum(a != b for a, b in zip(inferred_family, solver_family)),
        family_transitions=transitions, snapshots=snapshots)
    save(out/'report.json', report)
    np.savez_compressed(out/'window_signals.npz', **raw, **{'derived__'+k: v for k, v in s.items()},
        **{'lqr_block__'+k: v for k, v in blocks.items()})
    fig, axes = plt.subplots(6, 1, figsize=(12, 12), sharex=True)
    axes[0].plot(t, 1000*s['spatial_velocity_error_m_s'], label='Spatial nominal residual')
    axes[0].plot(t, 1000*s['timed_velocity_error_m_s'], ls=':', label='Clocked residual'); axes[0].axhline(20, color='k', ls='--')
    axes[0].set_ylabel('Velocity error\n(mm/s)'); axes[0].legend(fontsize=8)
    for j, name in enumerate(['X', 'Y']):
        axes[1].plot(t, raw['exact_qvel'][:, j], label='Actual '+name)
        axes[1].plot(t, s['spatial_nominal_velocity_m_s'][:, j], ls='--', label='Spatial nominal '+name)
    axes[1].set_ylabel('World velocity\n(m/s)'); axes[1].legend(ncol=2, fontsize=8)
    for j, name in enumerate(['Shaft', 'Shell A', 'Shell B']):
        axes[2].plot(t, raw['exact_feedback_reference_qvel'][:, 6+j], label=name+' ref')
        axes[2].plot(t, raw['exact_qvel'][:, 6+j], ls=':', label=name+' actual')
    axes[2].set_ylabel('Joint velocity\n(rad/s)'); axes[2].legend(ncol=3, fontsize=7)
    for j, name in enumerate(['Shaft', 'Shell A', 'Shell B', 'Belt A', 'Belt B']): axes[3].plot(t, requests[:, j]/caps[:, j], label=name)
    axes[3].axhline(1, color='k', ls='--'); axes[3].axhline(-1, color='k', ls='--')
    axes[3].set_ylabel('Requested /\nactual input cap'); axes[3].legend(ncol=3, fontsize=7)
    for j, name in enumerate(FAMILIES):
        axes[4].plot(t, estimated[:, j], label=name+' estimated')
        axes[4].plot(t, truth[:, j], ls=':', label=name+' last1ms truth')
    axes[4].set_ylabel('Patch load (N)'); axes[4].legend(ncol=4, fontsize=6)
    axes[5].plot(t, s['own_up_error_deg'], label='Native own-up error'); axes[5].plot(t, s['absolute_tilt_deg'], ls=':', label='Absolute tilt')
    axes[5].set_ylabel('Attitude (deg)'); axes[5].legend(fontsize=8); axes[5].set_xlabel('Command-start physical state time (s)')
    for ax in axes:
        ax.grid(alpha=.25); ax.axvline(105.59, color='gray', ls='--', lw=.8); ax.axvline(106., color='gray', ls='--', lw=.8)
        ax.set_xlim(*WINDOW)
    fig.suptitle('Known old B060 first-return interruption: fixed105.4–106.1s\nLast1ms contact sample; new commands act AFTER each state. No new I85 outputs.')
    fig.tight_layout(rect=(0, 0, 1, .95)); fig.savefig(out/'baseline_return_interruption.png', dpi=150); plt.close(fig)
    save(out/'artifact_manifest.json', dict(files={p.name: binding(p) for p in out.iterdir() if p.is_file()}))
    print(json.dumps(clean(dict(output=str(out), verification=checks, clipping=report['held_clipping'],
        family_transitions=transitions, statistics=statistics)), indent=2))


if __name__ == '__main__': main()
