"""I-85 one bounded terrain-contrast lean anticipation policy.

Only delivered observed-map queries and measured current state are inputs.
Native lean is not smoothed. The added rate differentiates only the extra
correction, retaining the native zero-baseline/yaw-rate convention.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import copy
import math
import numpy as np


class PolicySafetyError(RuntimeError):
    """A declared candidate guard failed; record the trial as invalid/failed."""


@dataclass(frozen=True)
class LeanSettings:
    horizon_s: float = .5
    extra_tilt_deg: float = 2.
    extra_rate_rad_s: float = .15
    time_constant_s: float = .1
    window_start_s: float = 99.5
    window_end_s: float = 104.
    ramp_s: float = 1.
    combined_tilt_guard_deg: float = 28.
    maximum_integrator_step_s: float = .001

    def __post_init__(self):
        values = list(asdict(self).values())
        if not np.isfinite(values).all() or any(v <= 0 for v in values):
            raise ValueError('All policy settings must be finite and positive')
        if self.window_end_s-self.window_start_s < 2*self.ramp_s:
            raise ValueError('Window must contain two nonoverlapping quintic ramps')
        if self.inner_rate_rad_s <= 0:
            raise ValueError('Envelope consumes the complete additional-rate budget')
        if self.maximum_integrator_step_s > self.time_constant_s:
            raise ValueError('SSP-Heun convexity requires substep<=time constant')
        if self.combined_tilt_guard_deg >= 90:
            raise ValueError('Combined reference guard must be below90degrees')

    @property
    def extra_tilt_rad(self): return math.radians(self.extra_tilt_deg)

    @property
    def maximum_envelope_rate_s(self): return 1.875/self.ramp_s

    @property
    def inner_rate_rad_s(self):
        return self.extra_rate_rad_s-self.extra_tilt_rad*self.maximum_envelope_rate_s


def radial_cap(vector, maximum):
    value = np.asarray(vector, float)
    norm = float(np.linalg.norm(value))
    return value.copy() if norm <= maximum else value*(maximum/norm)


def smoothstep(value):
    r = float(np.clip(value, 0., 1.))
    return 10*r**3-15*r**4+6*r**5, 30*r*r*(1-r)*(1-r)


def envelope(time_s, settings):
    t = float(time_s)
    if t <= settings.window_start_s or t >= settings.window_end_s:
        return 0., 0.
    if t < settings.window_start_s+settings.ramp_s:
        w, derivative = smoothstep((t-settings.window_start_s)/settings.ramp_s)
        return w, derivative/settings.ramp_s
    if t > settings.window_end_s-settings.ramp_s:
        w, derivative = smoothstep((settings.window_end_s-t)/settings.ramp_s)
        return w, -derivative/settings.ramp_s
    return 1., 0.


def lean_chart(lean):
    lean = np.asarray(lean, float)
    if lean.shape != (2,) or not np.isfinite(lean).all():
        raise ValueError('Native lean must be a finite horizontal2-vector')
    size = float(np.linalg.norm(lean))
    if size >= 1.:
        raise ValueError('Lean up-vector horizontal norm must be below1')
    return np.zeros(2) if size < 1e-12 else np.arcsin(size)*np.array([-lean[1], lean[0]])/size


def tilt_quaternion(theta):
    theta = np.asarray(theta, float)
    angle = float(np.linalg.norm(theta))
    scale = .5 if angle < 1e-12 else math.sin(angle/2)/angle
    return np.r_[math.cos(angle/2), scale*theta, 0.]


def quaternion_product(first, second):
    a, b = np.asarray(first, float), np.asarray(second, float)
    return np.r_[a[0]*b[0]-a[1:]@b[1:], a[0]*b[1:]+b[0]*a[1:]+np.cross(a[1:], b[1:])]


def rotation(quat):
    q = np.asarray(quat, float); q = q/np.linalg.norm(q)
    w, x, y, z = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
        [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
        [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def left_jacobian(phi):
    phi = np.asarray(phi, float); x, y, z = phi
    skew = np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])
    squared = float(phi@phi)
    if squared < 1e-8:
        a = .5-squared/24.+squared*squared/720.
        b = 1./6.-squared/120.+squared*squared/5040.
    else:
        angle = math.sqrt(squared)
        a = (1.-math.cos(angle))/squared
        b = (angle-math.sin(angle))/(squared*angle)
    return np.eye(3)+a*skew+b*(skew@skew)


def bounded_velocity(difference, settings):
    difference = np.asarray(difference, float)
    norm = float(np.linalg.norm(difference))
    if norm < 1e-15:
        return difference/settings.time_constant_s
    ratio = norm/(settings.inner_rate_rad_s*settings.time_constant_s)
    return difference*(math.tanh(ratio)/ratio/settings.time_constant_s)


def valid_normal(query):
    if not isinstance(query, dict) or not query.get('supported', False):
        return None
    normal = np.asarray(query.get('normal'), float)
    if normal.shape != (3,) or not np.isfinite(normal).all() or normal[2] <= 0:
        return None
    norm = float(np.linalg.norm(normal))
    return None if norm < 1e-12 else normal/norm


class TerrainLeanPolicy:
    """Instance-level adapter; caller owns reference/feedback wrappers.

    get_reference returns a bitwise native quaternion outside the active
    window. Its override flag tells the feedback wrapper to leave native vref
    untouched there. Repeated identical calls at one measured clock are cached.
    """
    def __init__(self, provider, native_reference_attitude, settings=None):
        self.provider = provider
        self.native_reference_attitude = native_reference_attitude
        self.settings = settings or LeanSettings()
        self.reset()

    def reset(self):
        self._time = None
        self._state = np.zeros(2)
        self._held_target = np.zeros(2)
        self._cache = self._cache_key = None
        self.failure = None

    def cached_result(self):
        if self._cache is None:
            raise RuntimeError('No reference evaluated at the current command')
        return copy.deepcopy(self._cache)

    def _advance(self, time_s):
        now = float(time_s)
        if self._time is not None and now < self._time-1e-10:
            raise ValueError('Policy measurement clock moved backwards')
        substeps = 0
        if self._time is not None and now > self._time:
            count = max(1, int(math.ceil((now-self._time)/self.settings.maximum_integrator_step_s)))
            h = (now-self._time)/count
            for _ in range(count):
                first = self._state+h*bounded_velocity(self._held_target-self._state, self.settings)
                self._state = .5*self._state+.5*(first+h*bounded_velocity(self._held_target-first, self.settings))
            substeps = count
        self._time = now
        return substeps

    def get_reference(self, controller, normal, acceleration):
        now = float(controller.plant.data.time)
        n, acceleration = np.asarray(normal, float), np.asarray(acceleration, float)
        if not np.isfinite(now) or n.shape != (3,) or acceleration.shape != (2,) or not np.isfinite(np.r_[n, acceleration]).all():
            raise ValueError('Finite measured time, current normal and XY acceleration required')
        key = (now, n.tobytes(), acceleration.tobytes())
        if self._cache_key is not None and abs(now-self._cache_key[0]) <= 1e-12:
            if key != self._cache_key:
                raise RuntimeError('Same-clock reference arguments changed; do not advance twice')
            return self.cached_result()
        native_quat = np.asarray(self.native_reference_attitude(n, acceleration), float).copy()
        settings = self.settings
        w, wdot = envelope(now, settings)
        in_window = settings.window_start_s <= now <= settings.window_end_s
        substeps = self._advance(now)
        current_query = future_query = None
        target, raw_delta = np.zeros(2), np.zeros(2)
        accepted = False
        current_xy = np.asarray(controller.plant.data.xpos[controller.plant.fork_id, :2], float)-controller.radius*n[:2]
        future_xy = current_xy+settings.horizon_s*np.asarray(controller.plant.data.qvel[:2], float)
        if in_window and self.provider is not None:
            current_query = self.provider.query(current_xy.copy(), at_time_s=now)
            future_query = self.provider.query(future_xy.copy(), at_time_s=now)
            current_normal, future_normal = valid_normal(current_query), valid_normal(future_query)
            if current_normal is not None and future_normal is not None:
                current_theta = lean_chart(controller.lean_vector(current_normal, acceleration))
                future_theta = lean_chart(controller.lean_vector(future_normal, acceleration))
                raw_delta = future_theta-current_theta
                target = radial_cap(raw_delta, settings.extra_tilt_rad)
                accepted = True
        if not in_window:
            self._state[:] = 0.
        self._held_target = target.copy()
        state_rate = bounded_velocity(self._held_target-self._state, settings)
        extra = w*self._state
        extra_rate = w*state_rate+wdot*self._state
        native_theta = lean_chart(controller.lean_vector(n, acceleration))
        total_theta = native_theta+extra
        diagnostics = dict(time_s=now, active_window=in_window, envelope=w, envelope_rate_s=wdot,
            map_accepted=accepted, current_query=current_query, future_query=future_query,
            current_query_xy_m=current_xy, future_query_xy_m=future_xy, horizon_s=settings.horizon_s,
            raw_map_contrast_rad=raw_delta, capped_map_target_rad=target, delta_state_rad=self._state.copy(),
            delta_state_rate_rad_s=state_rate, extra_chart_rad=extra, extra_chart_rate_rad_s=extra_rate,
            native_chart_rad=native_theta, combined_chart_rad=total_theta, integrator_substeps=substeps,
            provider_time_s=now, current_normal_replaced=False,
            angular_rate_scope='Only added correction derivative; native changing-lean/yaw zero-rate convention retained.')
        if np.linalg.norm(total_theta) > math.radians(settings.combined_tilt_guard_deg)+1e-12:
            self.failure = dict(reason='combined_reference_tilt_guard', time_s=now,
                combined_tilt_deg=float(np.degrees(np.linalg.norm(total_theta))),
                guard_deg=settings.combined_tilt_guard_deg, diagnostics=copy.deepcopy(diagnostics))
            raise PolicySafetyError('I85 combined-reference tilt exceeded28degree declared guard')
        if np.linalg.norm(extra) > settings.extra_tilt_rad+1e-12 or np.linalg.norm(extra_rate) > settings.extra_rate_rad_s+1e-12:
            self.failure = dict(reason='additional_reference_bound', time_s=now, diagnostics=copy.deepcopy(diagnostics))
            raise PolicySafetyError('I85 added-reference bound failed')
        override = bool(w > 0. and (np.any(extra != 0.) or np.any(extra_rate != 0.)))
        world_rate = np.zeros(3)
        body_rate = np.zeros(3)
        used_quat = native_quat.copy()
        if override:
            equilibrium_quat = np.asarray(controller.ordinary['equilibrium']['qpos'][3:7], float)
            if np.any(extra != 0.):
                used_quat = quaternion_product(equilibrium_quat, tilt_quaternion(total_theta))
            world_rate = rotation(equilibrium_quat)@left_jacobian(np.r_[total_theta, 0.])@np.r_[extra_rate, 0.]
            body_rotation = np.asarray(controller.plant.data.xmat[controller.plant.fork_id], float).reshape(3, 3)
            body_rate = body_rotation.T@world_rate
        diagnostics.update(native_reference_quat=native_quat.copy(), used_reference_quat=used_quat.copy(),
            extra_world_rate_rad_s=world_rate.copy(), extra_body_rate_rad_s=body_rate.copy(),
            override_angular_reference=override, failure=False)
        self._cache_key = key
        self._cache = dict(quat=used_quat, native_quat=native_quat, rate_world_rad_s=world_rate,
            rate_body_rad_s=body_rate, override_angular_reference=override, diagnostics=diagnostics)
        return self.cached_result()
