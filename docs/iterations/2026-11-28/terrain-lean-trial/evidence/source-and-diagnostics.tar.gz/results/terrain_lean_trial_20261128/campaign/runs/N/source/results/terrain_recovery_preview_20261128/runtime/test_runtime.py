"""I84 static kinematics/delivery contracts: no Gazebo, observer or rollout."""
from pathlib import Path
from types import SimpleNamespace
import sys

import mujoco
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from causal_depth_memory import CausalDepthMemory
from map_preparation import MapPreparationSynchronizer, blended_command, current_guard_error
from shadow_audit import anchor_indices, current_plane, changed_applied
from spherical_wheel.synchronization import ContactSynchronizer
from spherical_wheel.terrain_depth import DepthFrame, FourCameraDepthAdapter, TerrainRayScene, CameraSpec
from spherical_wheel.terrain_memory import TerrainMemory


def fixture():
    model = mujoco.MjModel.from_xml_string('''<mujoco><size nuser_geom="5"/>
    <option><flag contact="disable"/></option><worldbody>
    <geom name="floor" type="plane" size="3 3 .1"/>
    <body name="fork"><freejoint/><inertial mass="1" pos="0 0 .2" diaginertia=".1 .1 .1"/>
    <body name="carrier"><joint name="shaft" axis="0 1 0"/>
    <geom name="belt_A_smooth" type="sphere" size=".15" mass=".1" user="1 .1299038105676658 .15 4 .15"/>
    <geom name="belt_B_smooth" type="sphere" size=".15" mass=".1" user="-1 .1299038105676658 .15 4 .15"/>
    <body name="shell_A"><joint name="shell_A_joint" axis="1 0 0"/>
    <geom name="shell_A_smooth" type="sphere" size=".15" mass=".1" user="1 .002 .1299038105676658 2 .15"/></body>
    <body name="shell_B"><joint name="shell_B_joint" axis="1 0 0"/>
    <geom name="shell_B_smooth" type="sphere" size=".15" mass=".1" user="-1 .002 .1299038105676658 2 .15"/></body>
    </body></body></worldbody></mujoco>''')
    data = mujoco.MjData(model)
    data.qpos[:] = [0., 0., .15, 1., 0., 0., 0., 1., 0., 0.]
    data.qvel[:] = [.12, .09, 0., .05, -.03, .02, 1., .1, -.1]
    data.time = 2.
    mujoco.mj_forward(model, data)
    plant = SimpleNamespace(model=model, data=data, bounds=np.array([1.5,.6,.6,.6,.6]), last_input=np.zeros(5))
    geom = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, 'shell_A_smooth')
    records = [dict(name='shell_A_smooth', geom=geom, body=int(model.geom_bodyid[geom]),
                    pos=np.array([0.,0.,0.]), normal_force=100.)]
    return plant, records


class Plane:
    def __init__(self, failure=None):
        self.calls = []
        self.failure = failure

    def query(self, xy, *, at_time_s):
        xy = np.asarray(xy).copy()
        self.calls.append((xy, at_time_s))
        if self.failure == 'centre' or (self.failure == 'foot' and len(self.calls)%2 == 0):
            return dict(supported=False, reason='fixture_unknown')
        height = .05*xy[0]
        if self.failure == 'inconsistent' and len(self.calls)%2 == 0:
            height += .02
        normal = np.array([-.05,0.,1.]); normal /= np.linalg.norm(normal)
        return dict(supported=True, normal=normal, point_m=np.r_[xy,.05*xy[0]], height_m=height)


def test_unsupported_map_exact_native_fallback_and_no_state_mutation():
    plant, records = fixture(); primary = np.array([.2,.1,-.1,.03,-.02])
    native = ContactSynchronizer(plant)
    expected = native.preview(primary, records, (np.zeros(3),np.array([0.,0.,1.])))
    before = (plant.data.qpos.copy(), plant.data.qvel.copy(), plant.model.geom_surfacevel.copy())
    mapped = MapPreparationSynchronizer(native, Plane('centre'))
    actual = mapped.preview(primary, records, (np.zeros(3),np.array([0.,0.,1.])))
    assert actual == expected
    for after, old in zip((plant.data.qpos,plant.data.qvel,plant.model.geom_surfacevel),before):
        np.testing.assert_array_equal(after, old)
    assert mapped.last_map_diagnostics['parent_preview_calls'] == 1


def test_mapped_future_target_keeps_current_values_load_exclusion_and_bounds():
    plant, records = fixture(); primary = np.array([.2,.1,-.1,.03,-.02])
    native = ContactSynchronizer(plant); ground=(np.zeros(3),np.array([0.,0.,1.]))
    expected = native.preview(primary, records, ground)
    provider=Plane(); mapped=MapPreparationSynchronizer(native,provider)
    actual=mapped.preview(primary,records,ground)
    assert provider.calls and {t for _,t in provider.calls} == {2.}
    assert current_guard_error(expected,actual) == 0.
    assert expected['blend_weights'][1] == actual['blend_weights'][1] == 0.
    assert any(x['selected_future_map_accepted'] for x in mapped.last_map_diagnostics['selected_targets'])
    assert np.linalg.norm(blended_command(primary,actual)-blended_command(primary,expected)) > 1e-6
    assert np.all(abs(np.asarray(actual['commands'])) <= plant.bounds)
    for item in actual['targets']:
        assert item['blend_weight'] <= (.35 if item['name'].startswith('shell') else 1.)


@pytest.mark.parametrize('failure',['foot','inconsistent'])
def test_incomplete_or_inconsistent_foot_returns_native(failure):
    plant, records=fixture(); native=ContactSynchronizer(plant);ground=(np.zeros(3),np.array([0.,0.,1.]))
    expected=native.preview(np.zeros(5),records,ground)
    mapped=MapPreparationSynchronizer(native,Plane(failure))
    assert mapped.preview(np.zeros(5),records,ground) == expected
    assert mapped.last_map_diagnostics['accepted_future_supports'] == 0


def test_identical_stationary_pose_never_queries_map():
    plant,records=fixture();plant.data.qvel[:]=0.;mujoco.mj_forward(plant.model,plant.data)
    provider=Plane();mapped=MapPreparationSynchronizer(ContactSynchronizer(plant),provider)
    mapped.preview(records=records,ground=(np.zeros(3),np.array([0.,0.,1.])))
    assert not provider.calls


def test_four_view_queue_delivers_once_causally_and_rejects_backfill():
    def frames(qpos,capture,delivery):
        return tuple(DepthFrame(str(i),np.ones((1,1)),np.ones((1,1),bool),np.eye(3),np.eye(4),np.eye(4),capture,delivery) for i in range(4))
    memory=TerrainMemory(); causal=CausalDepthMemory(SimpleNamespace(render_batch=frames),memory)
    assert causal.advance([],0.)['delivered_batches']==0
    assert causal.advance([],.045)['delivered_batches']==0
    assert causal.advance([],.05)['delivered_batches']==1
    assert causal.advance([],.05)['delivered_batches']==0
    assert causal.captured_batches==2 and causal.delivered_batches==1
    assert memory.observed_cells(.05)['last_capture_s'].max()==0.
    with pytest.raises(ValueError,match='exact capture-time'):
        causal.advance([],.105)
    with pytest.raises(ValueError,match='current delivery'):
        causal.query([0,0],at_time_s=.06)


def test_static_sensor_masks_first_robot_hit_and_frames_have_no_scene_metadata():
    scene=TerrainRayScene.from_xml_string('<mujoco><worldbody><geom name="ground" type="plane" size="3 3 .1"/><geom name="robot" type="box" size=".2 .2 .1" pos="0 0 .5"/></worldbody></mujoco>',['ground'],['robot'])
    transform=np.diag([1.,-1.,-1.,1.]);transform[:3,3]=[0.,0.,1.]
    camera=CameraSpec('test',1,1,np.eye(3),transform,.08,2.)
    frame=FourCameraDepthAdapter(scene,[camera]).render_batch([],0.,.05)[0]
    assert not frame.valid_mask.any()
    assert not any(hasattr(frame,name) for name in ('scene','normal','hit_ids','geom_id'))


def test_anchor_union_native_plane_hold_and_fade_clip_identity():
    indices,uniform,dense=anchor_indices(np.arange(26601)*.005)
    assert uniform.sum()==267 and dense.sum()==901 and len(indices)==1158
    plant,_=fixture();plant.fork_id=mujoco.mj_name2id(plant.model,mujoco.mjtObj.mjOBJ_BODY,'fork')
    normal=np.array([0.,0.,1.]);first=current_plane(None,plant,normal,[],.15)
    assert current_plane(first,plant,np.array([.1,0.,.99]),[],.15) is first
    new=current_plane(first,plant,normal,[{}],.15)
    assert new is not first
    arrays=dict(exact_drive_fade=np.array([.25]),exact_requested=np.array([[0.,0.,0.,.59,0.]]))
    applied,requested=changed_applied(arrays,0,np.zeros(5),np.array([1.,0.,0.,.1,0.]),plant.bounds)
    np.testing.assert_array_equal(applied,np.array([.25,0.,0.,.6,0.]))
    assert requested[3]>.6
