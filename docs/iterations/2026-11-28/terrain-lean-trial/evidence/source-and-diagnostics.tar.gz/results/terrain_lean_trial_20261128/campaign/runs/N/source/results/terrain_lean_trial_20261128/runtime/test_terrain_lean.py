"""Synthetic I-85 reference contracts; no recorded arrays or physics calls."""
from dataclasses import asdict, replace
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('terrain_lean_contracts', HERE/'terrain_lean.py')
policy = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = policy
spec.loader.exec_module(policy)


class Provider:
    def __init__(self, function):
        self.function = function
        self.calls = []
        self.available = True

    def query(self, xy, at_time_s):
        self.calls.append((np.array(xy).copy(), at_time_s))
        return dict(supported=self.available, normal=np.asarray(self.function(xy), float),
                    at_time_s=at_time_s, reason='synthetic_observed' if self.available else 'unknown')


class Controller:
    def __init__(self, native_lean=None, equilibrium=None, body_rotation=None):
        self.radius = .1
        self.native_lean = native_lean
        self.reference_calls = []
        R = np.eye(3) if body_rotation is None else body_rotation
        data = SimpleNamespace(time=0., qvel=np.r_[.04, 0., np.zeros(7)],
            xpos=np.array([[.2, .3, .4]]), xmat=np.array([R.reshape(-1)]))
        self.plant = SimpleNamespace(data=data, fork_id=0)
        q = np.zeros(10); q[3] = 1.
        if equilibrium is not None: q[3:7] = equilibrium
        self.ordinary = dict(equilibrium=dict(qpos=q))

    def lean_vector(self, normal, acceleration):
        if self.native_lean is not None:
            return np.asarray(self.native_lean)+np.asarray(acceleration)/9.81-np.asarray(normal)[:2]
        return np.asarray(acceleration)/9.81-np.asarray(normal)[:2]

    def reference(self, normal, acceleration):
        self.reference_calls.append((np.array(normal).copy(), np.array(acceleration).copy()))
        theta = policy.lean_chart(self.lean_vector(normal, acceleration))
        return policy.quaternion_product(self.ordinary['equilibrium']['qpos'][3:7], policy.tilt_quaternion(theta))


def slope_map(xy):
    n = np.array([.8*xy[0], 0., 1.])
    return n/np.linalg.norm(n)


class TerrainLeanContracts(unittest.TestCase):
    def make(self, provider=None, **kwargs):
        c = Controller(**kwargs)
        p = policy.TerrainLeanPolicy(provider, c.reference)
        return c, p

    def step(self, c, p, t, normal=(0., 0., 1.), acceleration=(0., 0.)):
        c.plant.data.time = t
        return p.get_reference(c, normal, acceleration)

    def test_envelope_exact_endpoints_and_declared_rate_budget(self):
        s = policy.LeanSettings()
        for t in [0., 99.5, 104., 133.]: self.assertEqual(policy.envelope(t, s), (0., 0.))
        for t in [100.5, 101.8, 103.]: self.assertEqual(policy.envelope(t, s), (1., 0.))
        rates = [abs(policy.envelope(t, s)[1]) for t in np.linspace(99.5, 104., 901)]
        self.assertAlmostEqual(max(rates), 1.875)
        self.assertAlmostEqual(s.inner_rate_rad_s+s.extra_tilt_rad*max(rates), .15)
        with self.assertRaises(ValueError): replace(s, ramp_s=.1)

    def test_machine_settings_exactly_match_tested_policy(self):
        stored = json.loads((HERE/'settings.json').read_text())
        s = policy.LeanSettings()
        self.assertEqual(stored['policy'], asdict(s))
        self.assertEqual(stored['derived']['inner_rate_rad_s'], s.inner_rate_rad_s)
        self.assertEqual(stored['derived']['maximum_envelope_rate_s'], s.maximum_envelope_rate_s)

    def test_same_plane_yields_bitwise_native_and_no_rate_override(self):
        c, p = self.make(Provider(lambda xy: [0., 0., 1.]))
        for t in [99.5, 99.75, 100.5, 102., 103.5, 104.]:
            row = self.step(c, p, t)
            np.testing.assert_array_equal(row['quat'], row['native_quat'])
            np.testing.assert_array_equal(row['rate_body_rad_s'], np.zeros(3))
            self.assertFalse(row['override_angular_reference'])

    def test_map_delta_is_future_minus_current_not_absolute_normal(self):
        c, p = self.make(Provider(slope_map))
        row = self.step(c, p, 100.)
        now = policy.lean_chart(c.lean_vector(slope_map([.2, .3]), [0., 0.]))
        future = policy.lean_chart(c.lean_vector(slope_map([.22, .3]), [0., 0.]))
        np.testing.assert_allclose(row['diagnostics']['raw_map_contrast_rad'], future-now, atol=1e-15)
        self.assertLess(np.linalg.norm(future-now), np.linalg.norm(now))

    def test_queries_use_current_delivery_clock_and_measured_velocity(self):
        provider = Provider(slope_map); c, p = self.make(provider)
        normal = np.array([.1, .2, np.sqrt(.95)])
        self.step(c, p, 100., normal)
        self.assertEqual([t for _, t in provider.calls], [100., 100.])
        np.testing.assert_allclose(provider.calls[0][0], [.19, .28], atol=1e-15)
        np.testing.assert_allclose(provider.calls[1][0], [.21, .28], atol=1e-15)
        np.testing.assert_array_equal(c.reference_calls[0][0], normal)

    def test_same_time_calls_cache_without_alias_or_query(self):
        provider = Provider(slope_map); c, p = self.make(provider)
        first = self.step(c, p, 100.)
        first['quat'][:] = 5.
        again = self.step(c, p, 100.)
        self.assertEqual(len(provider.calls), 2)
        self.assertEqual(len(c.reference_calls), 1)
        self.assertLess(np.linalg.norm(again['quat']), 1.01)
        with self.assertRaises(RuntimeError): self.step(c, p, 100., acceleration=(.1, 0.))

    def test_bounds_include_filter_and_window_fade(self):
        provider = Provider(lambda xy: slope_map(xy) if int(provider.calls.__len__()/2)%2 else [-.6, 0., .8])
        c, p = self.make(provider)
        for t in 99.5+np.arange(901)*.005:
            row = self.step(c, p, float(t))
            self.assertLessEqual(np.linalg.norm(row['diagnostics']['extra_chart_rad']), np.radians(2.)+1e-12)
            self.assertLessEqual(np.linalg.norm(row['diagnostics']['extra_chart_rate_rad_s']), .15+1e-12)
            self.assertLessEqual(np.linalg.norm(row['rate_world_rad_s']), .15+1e-12)

    def test_unknown_map_returns_state_smoothly_without_replacing_normal(self):
        provider = Provider(slope_map); c, p = self.make(provider)
        for t in 99.5+np.arange(301)*.005: before = self.step(c, p, float(t))
        provider.available = False
        row = self.step(c, p, 101.005)
        self.assertFalse(row['diagnostics']['map_accepted'])
        np.testing.assert_array_equal(row['diagnostics']['capped_map_target_rad'], np.zeros(2))
        self.assertGreater(np.linalg.norm(row['diagnostics']['extra_chart_rad']), 0.)
        self.assertLess(np.linalg.norm(row['diagnostics']['extra_chart_rad']-before['diagnostics']['extra_chart_rad']), .15*.005+1e-12)
        self.assertFalse(row['diagnostics']['current_normal_replaced'])

    def test_outside_window_returns_original_quaternion_after_active_history(self):
        c, p = self.make(Provider(slope_map))
        for t in 99.5+np.arange(300)*.005: self.step(c, p, float(t))
        for t in [104., 104.005, 105.]:
            row = self.step(c, p, t)
            np.testing.assert_array_equal(row['quat'], row['native_quat'])
            self.assertFalse(row['override_angular_reference'])

    def test_added_rate_body_frame_matches_world_frame(self):
        eq = np.array([np.cos(.25), 0., 0., np.sin(.25)])
        body = policy.rotation(np.array([np.cos(.3), np.sin(.3), 0., 0.]))
        c, p = self.make(Provider(slope_map), equilibrium=eq, body_rotation=body)
        self.step(c, p, 100.)
        row = self.step(c, p, 100.005)
        np.testing.assert_allclose(body@row['rate_body_rad_s'], row['rate_world_rad_s'], atol=1e-15)
        self.assertGreater(np.linalg.norm(row['rate_world_rad_s']), 0.)

    def test_left_jacobian_extra_rate_matches_finite_rotation_derivative(self):
        theta = np.array([.2, -.1]); derivative = np.array([.05, .08]); h = 1e-6
        R = policy.rotation(policy.tilt_quaternion(theta))
        Rp = policy.rotation(policy.tilt_quaternion(theta+h*derivative))
        Rm = policy.rotation(policy.tilt_quaternion(theta-h*derivative))
        skew = ((Rp-Rm)/(2*h))@R.T
        measured = np.array([skew[2, 1], skew[0, 2], skew[1, 0]])
        expected = policy.left_jacobian(np.r_[theta, 0.])@np.r_[derivative, 0.]
        np.testing.assert_allclose(measured, expected, atol=3e-11, rtol=0.)

    def test_combined_tilt_guard_is_explicit_failure_not_silent_projection(self):
        c, p = self.make(Provider(slope_map), native_lean=np.array([-np.sin(np.radians(27.9)), 0.]))
        with self.assertRaises(policy.PolicySafetyError):
            for t in 99.5+np.arange(301)*.005: self.step(c, p, float(t))
        self.assertEqual(p.failure['reason'], 'combined_reference_tilt_guard')
        self.assertGreater(p.failure['combined_tilt_deg'], 28.)

    def test_reset_clears_cache_and_forecast_state(self):
        provider = Provider(slope_map); c, p = self.make(provider)
        self.step(c, p, 100.); self.step(c, p, 100.005)
        self.assertGreater(np.linalg.norm(p.cached_result()['diagnostics']['extra_chart_rad']), 0.)
        p.reset()
        row = self.step(c, p, 100.)
        np.testing.assert_array_equal(row['diagnostics']['delta_state_rad'], np.zeros(2))
        self.assertIsNone(p.failure)


if __name__ == '__main__': unittest.main(verbosity=2)
