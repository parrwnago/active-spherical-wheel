"""I84 observed-map changes to future incoming preparation only.

The parent algorithm remains unchanged. No observer/controller/terrain truth is
called here. Current supports always use the caller's original observer plane.
"""
from __future__ import annotations

import mujoco
import numpy as np

from spherical_wheel.synchronization import ContactSynchronizer


class MapPreparationSynchronizer(ContactSynchronizer):
    def __init__(self, native, provider, foot_consistency_m=.003):
        super().__init__(native.plant, **{name: getattr(native, name) for name in (
            'lookahead_s', 'transition_margin_m', 'shell_speed_limit_rad_s',
            'shell_speed_gain_Nms', 'shell_blend_limit', 'lever_regularization_m')})
        if not np.isfinite(foot_consistency_m) or foot_consistency_m <= 0:
            raise ValueError('Positive finite footprint consistency tolerance required')
        self.provider = provider
        self.foot_consistency_m = float(foot_consistency_m)
        self._anchor_qpos = None
        self._anchor_time_s = None
        self._map_cache = {}
        self.last_map_diagnostics = None

    def _support(self, patch, data):
        native = super()._support(patch, data)
        if (self._anchor_qpos is None or data is not self._data or
                np.array_equal(data.qpos, self._anchor_qpos)):
            return native
        key = (patch['name'], data.qpos.tobytes())
        if key in self._map_cache:
            return self._map_cache[key][0]
        item = dict(patch=patch['name'], accepted=False,
                    anchor_time_s=self._anchor_time_s, future_pose=True)
        if self.provider is None:
            item['reason'] = 'no_observed_provider'
            self._map_cache[key] = (native, item)
            return native
        centre = data.xpos[patch['body']]
        surface = self.provider.query(centre[:2].copy(), at_time_s=self._anchor_time_s)
        item['centre_query'] = surface
        if not surface.get('supported', False):
            item['reason'] = 'centre:' + surface.get('reason', 'unsupported')
            self._map_cache[key] = (native, item)
            return native
        normal = np.asarray(surface['normal'], float)
        plane_point = np.asarray(surface['point_m'], float)
        if (normal.shape != (3,) or plane_point.shape != (3,) or
                not np.isfinite(normal).all() or not np.isfinite(plane_point).all() or
                np.linalg.norm(normal) < 1e-12 or normal[2] <= 0):
            item['reason'] = 'invalid_supported_plane'
            self._map_cache[key] = (native, item)
            return native
        normal = normal / np.linalg.norm(normal)
        point = centre - patch['radius'] * normal
        foot = self.provider.query(point[:2].copy(), at_time_s=self._anchor_time_s)
        item['foot_query'] = foot
        if not foot.get('supported', False):
            item['reason'] = 'foot:' + foot.get('reason', 'unsupported')
            self._map_cache[key] = (native, item)
            return native
        expected_height = float(plane_point[2] - normal[:2] @ (point[:2] - plane_point[:2]) / normal[2])
        difference = abs(float(foot['height_m']) - expected_height)
        item['foot_height_disagreement_m'] = difference
        if not np.isfinite(difference) or difference > self.foot_consistency_m + 1e-12:
            item['reason'] = 'nonlocal_surface_disagreement'
            self._map_cache[key] = (native, item)
            return native
        axis = data.xmat[patch['body']].reshape(3, 3)[:, 0]
        signed_x = patch['sign'] * float(np.dot(-patch['radius'] * normal, axis))
        margin = signed_x - patch['lower']
        if patch['name'].startswith('shell'):
            margin = min(margin, patch['upper'] - signed_x)
        gap = float(np.dot(point - plane_point, normal))
        mapped = (point.copy(), normal.copy(), float(margin), gap)
        item.update(accepted=True, reason='complete_observed_centre_and_foot',
                    mapped_margin_m=float(margin), mapped_gap_m=gap)
        self._map_cache[key] = (mapped, item)
        return mapped

    def preview(self, primary_command=None, records=None, ground=None):
        if self._anchor_qpos is not None:
            raise RuntimeError('Serialize map-preparation preview calls')
        self._anchor_qpos = self.plant.data.qpos.copy()
        self._anchor_time_s = float(self.plant.data.time)
        self._map_cache = {}
        try:
            result = super().preview(primary_command, records=records, ground=ground)
            selected = []
            for target in result['targets']:
                predicted = self._anchor_qpos.copy()
                mujoco.mj_integratePos(self.plant.model, predicted, self.plant.data.qvel,
                                      float(target['lookahead_s']))
                record = self._map_cache.get((target['name'], predicted.tobytes()))
                item = dict(patch=target['name'], command_index=target['command_index'],
                            blend_weight=target['blend_weight'],
                            selected_future_map_accepted=bool(record and record[1]['accepted']),
                            lookahead_s=target['lookahead_s'])
                if record:
                    item['query'] = record[1]
                selected.append(item)
            self.last_map_diagnostics = dict(anchor_time_s=self._anchor_time_s,
                selected_targets=selected, future_support_queries=len(self._map_cache),
                accepted_future_supports=sum(x[1]['accepted'] for x in self._map_cache.values()),
                rejection_reasons=[x[1]['reason'] for x in self._map_cache.values() if not x[1]['accepted']],
                current_support_uses_native_plane=True, provider_query_time='anchor_only',
                parent_preview_calls=1)
            return result
        finally:
            self._anchor_qpos = None
            self._anchor_time_s = None


def blended_command(primary, preview):
    weights = np.asarray(preview['blend_weights'], float)
    return (1. - weights) * np.asarray(primary, float) + weights * np.asarray(preview['commands'], float)


def current_guard_error(native, mapped):
    """Independent comparison of values that the map must never change."""
    errors = [float(np.max(np.abs(np.asarray(native['outgoing_tangential_velocity_m_s']) -
                                 np.asarray(mapped['outgoing_tangential_velocity_m_s']))))]
    for first, second in zip(native['targets'], mapped['targets']):
        if first['name'] != second['name']:
            raise AssertionError('Native/map target order differs')
        for name in ('normal_load_N', 'normal_load_fraction', 'current_patch_margin_m'):
            errors.append(abs(float(first[name]) - float(second[name])))
        errors.append(float(np.max(np.abs(np.asarray(first['actual_tangential_velocity_m_s']) -
                                           np.asarray(second['actual_tangential_velocity_m_s'])))))
        if first['normal_load_fraction'] >= .05 and second['blend_weight'] != 0:
            raise AssertionError('Map preparation overrode a currently loaded drive')
    return max(errors, default=0.)
