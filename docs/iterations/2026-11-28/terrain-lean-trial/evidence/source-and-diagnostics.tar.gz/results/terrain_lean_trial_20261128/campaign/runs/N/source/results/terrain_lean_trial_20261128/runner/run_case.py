"""One I85 fresh native/T pair through the untouched I82 B060 harness."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import traceback

import mujoco
import numpy as np

from spherical_wheel.offroad_control import OffroadController
from spherical_wheel.terrain_depth import TerrainRayScene, FourCameraDepthAdapter, four_camera_rig
from spherical_wheel.terrain_memory import TerrainMemory, MemorySettings


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
SETTINGS = json.loads((HERE/'settings.json').read_text())
PRECISION_CHILD = Path('native/child/campaign/runs/eight_m100_N/precision.npz')


def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
    return value.hexdigest()


def safe(value):
    if isinstance(value,dict):return {str(k):safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [safe(v) for v in value]
    if isinstance(value,Path):return str(value)
    if isinstance(value,np.ndarray):return safe(value.tolist())
    if isinstance(value,np.generic):return safe(value.item())
    if isinstance(value,float) and not np.isfinite(value):return None
    return value


def save(path,value):
    with Path(path).open('x') as stream:
        json.dump(safe(value),stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec)
    sys.modules[name]=result;spec.loader.exec_module(result);return result


def preflight(path,arm):
    protocol=json.loads(Path(path).read_text())
    if protocol.get('iteration')!='I-85' or protocol.get('runner_settings')!=SETTINGS:
        raise ValueError('Frozen I85 protocol with exact runner settings required')
    if arm not in SETTINGS['arms']:raise ValueError('One N/T arm required')
    for group in ('source_sha256','input_sha256'):
        for name,expected in protocol[group].items():
            if sha(ROOT/name)!=expected:raise AssertionError('Frozen source/input changed: '+name)
    if protocol['source_sha256'].get(str(Path(__file__).relative_to(ROOT)))!=sha(__file__):
        raise AssertionError('I85 runner source absent from protocol')
    return protocol


def differing_rows(left,right):
    a,b=np.asarray(left),np.asarray(right)
    if a.shape!=b.shape or a.dtype!=b.dtype:raise ValueError('Equal shape and dtype required for byte comparison')
    if not len(a):return np.zeros(0,bool)
    return np.any(np.ascontiguousarray(a).view(np.uint8).reshape(len(a),-1)!=
                  np.ascontiguousarray(b).view(np.uint8).reshape(len(b),-1),axis=1)


def exact_comparison(first,second):
    """All inherited precision fields, including observer and reference history."""
    with np.load(first,allow_pickle=False) as a,np.load(second,allow_pickle=False) as b:
        if set(a.files)!=set(b.files) or len(a.files)!=79:
            raise AssertionError('Exact original79-field precision schema required')
        different=[name for name in a.files if a[name].shape!=b[name].shape or a[name].dtype!=b[name].dtype or
                   differing_rows(a[name],b[name]).any()]
        if different:raise AssertionError('Native B060 replay differs: '+','.join(different))
        if len(a['time_s'])!=SETTINGS['expected_rows'] or abs(float(a['time_s'][-1])-133.)>1e-8:
            raise AssertionError('Complete original native133s clock required')
        return dict(all79_fields_exact=True,comparison='dtype/shape and every uint8 byte, including signed zero/NaN payload',rows=len(a['time_s']),end_time_s=float(a['time_s'][-1]))


def prefix_comparison(native,candidate):
    with np.load(native,allow_pickle=False) as n,np.load(candidate,allow_pickle=False) as t:
        common=min(len(n['time_s']),len(t['time_s']))
        if set(n.files)!=set(t.files) or len(n.files)!=79:raise AssertionError('Native/T precision schemas differ')
        before=np.flatnonzero(t['time_s'][:common]<SETTINGS['active_window_s'][0]-1e-9)
        different=[key for key in n.files if differing_rows(n[key][before],t[key][before]).any()]
        if different:raise AssertionError('Inactive prefix changed: '+','.join(different))
        changed=np.flatnonzero(differing_rows(n['exact_applied'][:common],t['exact_applied'][:common]))
        first=None if not len(changed) else int(changed[0])
        through=common if first is None else first+1
        for key in ('time_s','exact_qpos','exact_qvel','exact_observer_wrench','exact_observer_generalized','exact_observer_interval_mean','exact_previous_applied',
                    'truth_time_s','truth_patch_loads_N','truth_patch_points_m','truth_patch_contact_counts','truth_equivalent_point_m'):
            if differing_rows(n[key][:through],t[key][:through]).any():
                raise AssertionError('State/observer history changed before first applied difference: '+key)
        return dict(all79_inactive_prefix_exact=True,inactive_prefix_rows=len(before),
                    first_applied_difference_index=first,
                    first_applied_difference_time_s=None if first is None else float(t['time_s'][first]),
                    state_observer_prefix_through_first_applied_difference_exact=True)


def angular_reference(vref,result):
    """Only angular feedback-reference slots may change; no input vector mutation."""
    if not result['override_angular_reference']:return vref
    changed=np.asarray(vref,float).copy();changed[3:6]=result['rate_body_rad_s']
    np.testing.assert_array_equal(changed[np.r_[0:3,6:len(changed)]],np.asarray(vref)[np.r_[0:3,6:len(changed)]])
    return changed


class CameraAndPolicy:
    def __init__(self,arm,native_command):
        self.arm,self.native_command=arm,native_command
        self.controller=self.causal=self.policy=None
        self.rows=[];self.observed=[]
        self.depths=[];self.masks=[];self.poses=[];self.capture_times=[];self.delivery_times=[]
        self.reference_calls=self.feedback_calls=0
        self.native_reference=None;self.native_feedback=None

    def initialize(self,controller):
        self.controller=controller
        previous=json.loads((ROOT/SETTINGS['sensor_registration']).read_text())
        sensor=previous['sensor_scene'];model=mujoco.MjModel.from_xml_path(str(ROOT/sensor['model_xml']))
        scene=TerrainRayScene(model,np.flatnonzero(model.geom_group==0),np.flatnonzero(model.geom_group==1),sensor['metadata'])
        self.adapter=FourCameraDepthAdapter(scene,four_camera_rig())
        memory=TerrainMemory(MemorySettings(**previous['settings']['memory']))
        causal_module=module(ROOT/SETTINGS['causal_module'],'_i85_unchanged_causal_memory')
        self.causal=causal_module.CausalDepthMemory(self.adapter,memory,SETTINGS['capture_hz'],SETTINGS['latency_s'])
        self.native_reference=controller.reference_attitude
        self.native_feedback=controller._terrain_feedback
        if self.arm=='T':
            policy_module=module(ROOT/SETTINGS['policy_module'],'_i85_frozen_terrain_lean_policy')
            self.policy=policy_module.TerrainLeanPolicy(self.causal,self.native_reference)
            self.install_policy_hooks(controller)

    def install_policy_hooks(self,controller):
        def reference(normal,acceleration):
            self.reference_calls+=1
            return self.policy.get_reference(controller,normal,acceleration)['quat'].copy()
        def feedback(qref,vref,feedforward,normal,measurement,touching):
            self.feedback_calls+=1
            original_normal=np.asarray(normal).copy();original_feedforward=np.asarray(feedforward).copy()
            result=self.policy.cached_result()
            supplied=angular_reference(vref,result)
            value=self.native_feedback(qref,supplied,feedforward,normal,measurement,touching)
            np.testing.assert_array_equal(normal,original_normal)
            np.testing.assert_array_equal(feedforward,original_feedforward)
            return value
        controller.reference_attitude=reference
        controller._terrain_feedback=feedback

    def command(self,controller,xy,velocity,acceleration):
        if self.controller is None:self.initialize(controller)
        if controller is not self.controller:raise AssertionError('Only one native controller per arm allowed')
        data=controller.plant.data
        self.observed.append(dict(time_s=float(data.time),qpos=data.qpos.copy(),qvel=data.qvel.copy(),
                                  xy=np.asarray(xy).copy(),velocity=np.asarray(velocity).copy(),acceleration=np.asarray(acceleration).copy()))
        batch=self.causal.advance(data.qpos,data.time)
        if batch['captured'] is not None:
            frames=batch['captured'];self.depths.append(np.stack([f.depth_m for f in frames]));self.masks.append(np.stack([f.valid_mask for f in frames]))
            self.poses.append(np.stack([f.world_from_camera for f in frames]));self.capture_times.append(frames[0].capture_time_s);self.delivery_times.append(frames[0].delivered_at_s)
        applied,info=self.native_command(controller,xy,velocity,acceleration)
        np.testing.assert_array_equal(info['reference_qpos'][:2],np.asarray(xy))
        if np.any(info['heading_command']):raise AssertionError('Heading helper unexpectedly enabled')
        normal=np.asarray(info['estimate']['normal'])
        native_quat=self.native_reference(normal,acceleration)
        if self.policy is None:
            policy_result=dict(quat=np.asarray(info['reference_quat']).copy(),native_quat=native_quat,
                rate_world_rad_s=np.zeros(3),rate_body_rad_s=np.zeros(3),override_angular_reference=False,diagnostics={})
        else:
            policy_result=self.policy.cached_result()
            np.testing.assert_array_equal(policy_result['native_quat'],native_quat)
            np.testing.assert_array_equal(policy_result['quat'],info['reference_quat'])
        self.rows.append(dict(time_s=float(data.time),native_reference_quat=native_quat,
            changed_reference_quat=np.asarray(info['reference_quat']).copy(),
            rate_world_rad_s=policy_result['rate_world_rad_s'],rate_body_rad_s=policy_result['rate_body_rad_s'],
            override_angular_reference=policy_result['override_angular_reference'],
            feedback_reference_qvel=np.asarray(info['feedback_reference_qvel']).copy(),
            diagnostics=policy_result['diagnostics'],estimated_normal=normal.copy(),
            captured_batches=self.causal.captured_batches,delivered_batches=self.causal.delivered_batches,
            maximum_delivered_capture_s=batch['maximum_delivered_capture_s'],
            raw_qpos=data.qpos.copy(),raw_qvel=data.qvel.copy(),applied=np.asarray(applied).copy(),
            reference_calls_at_record=self.reference_calls,feedback_calls_at_record=self.feedback_calls))
        return applied,info

    def save(self,out):
        save(out/'policy_records.json',dict(iteration='I-85',arm=self.arm,rows=self.rows))
        if self.rows:
            names=('time_s','native_reference_quat','changed_reference_quat','rate_world_rad_s','rate_body_rad_s',
                   'override_angular_reference','feedback_reference_qvel','estimated_normal','captured_batches','delivered_batches','raw_qpos','raw_qvel','applied')
            arrays={name:np.asarray([row[name] for row in self.rows]) for name in names}
            for name,default in (('extra_chart_rad',np.zeros(2)),('extra_chart_rate_rad_s',np.zeros(2)),
                                 ('delta_state_rad',np.zeros(2)),('delta_state_rate_rad_s',np.zeros(2)),
                                 ('current_query_xy_m',np.zeros(2)),('future_query_xy_m',np.zeros(2))):
                arrays[name]=np.asarray([row['diagnostics'].get(name,default) for row in self.rows])
            arrays['window_weight']=np.asarray([row['diagnostics'].get('envelope',0.) for row in self.rows])
            arrays['map_accepted']=np.asarray([row['diagnostics'].get('map_accepted',False) for row in self.rows],bool)
            for field in ('current_query','future_query'):
                arrays[field+'_supported']=np.asarray([bool((row['diagnostics'].get(field) or {}).get('supported',False)) for row in self.rows])
            np.savez_compressed(out/'policy.npz',**arrays)
        if self.observed:
            np.savez_compressed(out/'observed_states.npz',**{name:np.asarray([row[name] for row in self.observed])
                                  for name in ('time_s','qpos','qvel','xy','velocity','acceleration')})
        if self.depths:
            np.savez_compressed(out/'depth_batches.npz',depth_m=np.stack(self.depths),valid_mask=np.stack(self.masks),
                world_from_camera=np.stack(self.poses),capture_time_s=self.capture_times,delivered_at_s=self.delivery_times,
                intrinsics=np.stack([c.intrinsics for c in self.adapter.cameras]),body_from_camera=np.stack([c.body_from_camera for c in self.adapter.cameras]),
                camera_names=np.array([c.name for c in self.adapter.cameras]))
        save(out/'instrumentation_receipt.json',dict(iteration='I-85',arm=self.arm,completed_commands=len(self.rows),
            observed_states=len(self.observed),camera_batches_captured=len(self.depths),
            camera_batches_delivered=0 if self.causal is None else self.causal.delivered_batches,
            pending_camera_batches=0 if self.causal is None else len(self.causal._queue),
            reference_hook_calls=self.reference_calls,feedback_hook_calls=self.feedback_calls,
            native_current_holding_normal_and_feedforward_unchanged=True,
            native_reference_rule='Original unmodified native formula at THIS arm current estimated normal/acceleration; not same-clockN target',
            inner_metadata='Inherited I82 B060 labels describe the reused harness; this outer I85 receipt and protocol define the candidate reference intervention.',
            policy_failure=None if self.policy is None else getattr(self.policy,'failure',None)))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--registration',type=Path,required=True)
    parser.add_argument('--arm',choices=SETTINGS['arms'],required=True)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--native-baseline',type=Path)
    parser.add_argument('--preflight-only',action='store_true')
    parser.add_argument('--run',action='store_true')
    args=parser.parse_args();protocol=preflight(args.registration,args.arm)
    if args.preflight_only:
        print(json.dumps(dict(iteration='I-85',passed=True,arm=args.arm,physics_run=False)));return
    if not args.run or args.output is None:raise SystemExit('Explicit --run and NEW --output required')
    if args.arm=='T':
        if args.native_baseline is None:raise ValueError('T requires freshly completed native N')
        baseline=json.loads((args.native_baseline/'outcome.json').read_text())
        if not baseline.get('baseline_all79_exact') or not baseline.get('physical_horizon_reached'):
            raise ValueError('Fresh native N full133s/all79 parity must pass before T')
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    save(out/'registered_before_physics.json',dict(iteration='I-85',arm=args.arm,
        utc=datetime.now(timezone.utc).isoformat(),registration_sha256=sha(args.registration),
        source_sha256=protocol['source_sha256'],input_sha256=protocol['input_sha256'],runner_settings=SETTINGS,
        authority='This outer I85 registration defines N/T; inner I82 metadata is inherited and does not describe the terrain-reference candidate.'))
    for name in protocol['source_sha256']:
        target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
    native_command=OffroadController.command;capture=CameraAndPolicy(args.arm,native_command)
    returned=False;failure=None
    try:
        old=module(ROOT/SETTINGS['old_runner'],'_i85_unchanged_i82_runner')
        argv=[str(ROOT/SETTINGS['old_runner']),'--protocol',str(ROOT/SETTINGS['old_protocol']),
              '--arm','B060','--output',str(out/'native'),'--native-baseline',str(ROOT/SETTINGS['old_native030']),'--run']
        def hooked(controller,xy,velocity,acceleration):
            return capture.command(controller,xy,velocity,acceleration)
        with patch.object(sys,'argv',argv),patch.object(OffroadController,'command',hooked):old.main()
        returned=True
    except BaseException as error:
        failure=dict(type=type(error).__name__,traceback=traceback.format_exc(),
            classification='POLICY_SAFETY_STOP' if type(error).__name__=='PolicySafetyError' else 'NATIVE_RUNNER_EXCEPTION',
            policy_failure=None if capture.policy is None else getattr(capture.policy,'failure',None))
        save(out/'failure.json',failure)
    finally:
        capture.save(out)
    result=dict(iteration='I-85',arm=args.arm,runner_recording_completed=returned,
        physical_horizon_reached=False,baseline_all79_exact=False,physical_failure=None if failure is None else failure['classification'],
        actual_observed_end_s=None if not capture.observed else capture.observed[-1]['time_s'],
        inherited_native_output=str(out/'native'),precision_exists=(out/PRECISION_CHILD).is_file())
    validation_failure=None
    if returned:
        try:
            inner=json.loads((out/'native/outcome.json').read_text());result.update(physical_horizon_reached=inner['physical_horizon_reached'],physical_failure=inner['physical_failure'])
            if args.arm=='N':
                parity=exact_comparison(ROOT/SETTINGS['old_native060']/'child/campaign/runs/eight_m100_N/precision.npz',out/PRECISION_CHILD)
                save(out/'native_parity.json',parity);result['baseline_all79_exact']=True
            else:
                prefix=prefix_comparison(args.native_baseline/PRECISION_CHILD,out/PRECISION_CHILD);save(out/'native_prefix.json',prefix)
            receipt=json.loads((out/'native/capacity_receipt.json').read_text())
            counts=receipt['native_command_preview_counts']
            if counts['commands']!=len(capture.rows) or counts['previews']!=len(capture.rows):raise AssertionError('Exactly one native preview per command required')
            if receipt['cap_m_s']!=.6 or not receipt['config_and_design_unchanged']:raise AssertionError('Fixed capacity/design identity changed')
            with np.load(out/PRECISION_CHILD,allow_pickle=False) as precision:
                np.testing.assert_array_equal(precision['time_s'],np.asarray([row['time_s'] for row in capture.rows]))
                if not np.all(precision['native_observer_update_count']==1):raise AssertionError('Exactly one observer update per command required')
        except BaseException as error:
            validation_failure=dict(type=type(error).__name__,traceback=traceback.format_exc(),classification='POST_RUN_INTEGRITY_FAILURE')
            save(out/'validation_failure.json',validation_failure)
    result['post_run_integrity_passed']=returned and validation_failure is None
    save(out/'outcome.json',result)
    preflight(args.registration,args.arm)
    save(out/'artifact_manifest.json',dict(iteration='I-85',arm=args.arm,files={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=sha(p))
        for p in sorted(out.rglob('*')) if p.is_file()}))
    print(json.dumps(safe(result)),flush=True)
    if failure is not None or validation_failure is not None:raise SystemExit(2)


if __name__=='__main__':main()
