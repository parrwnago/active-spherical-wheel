"""I85 fixed one-pair evaluation using frozen I83 recovery arithmetic."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import shutil
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
I83=ROOT/'results/recovery_assessment_20261128/evaluation'


def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x);return x


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb')as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def safe(x):
    if isinstance(x,dict):return{k:safe(v)for k,v in x.items()}
    if isinstance(x,(list,tuple)):return[safe(v)for v in x]
    if isinstance(x,np.ndarray):return safe(x.tolist())
    if isinstance(x,np.generic):return x.item()
    return x


def save(p,x):
    with Path(p).open('x')as f:json.dump(safe(x),f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')


def decide(native,candidate,hard,nonnull,definitions):
    checks=[dict(name=k,actual=bool(v),limit=True,passed=bool(v))for k,v in hard.items()]
    def add(name,actual,limit,passed):checks.append(dict(name=name,actual=actual,limit=limit,passed=bool(passed)))
    n=native.get('entry_s');c=candidate.get('entry_s')
    latest=None if n is None else n-definitions['primary']['minimum_entry_improvement_s']
    add('primary_two_second_entry',c,latest,c is not None and latest is not None and c<=latest+1e-9)
    add('primary_uninterrupted_good_through_133',candidate.get('persistent',False),True,candidate.get('persistent',False))
    minimum=definitions['primary']['minimum_active_normalized_applied_change']
    add('nonnull_active_applied_change',nonnull,minimum,nonnull>=minimum)
    for key,(ratio,offset)in definitions['nonregression'].items():
        a,b=native.get(key),candidate.get(key);limit=None if a is None else ratio*a+offset
        add('nonregression_'+key,b,limit,b is not None and limit is not None and np.isfinite(b)and b<=limit+1e-12)
    for index in range(5):
        a=native.get('clipping_each_s',[None]*5)[index];b=candidate.get('clipping_each_s',[None]*5)[index]
        limit=None if a is None else a+definitions['clipping']['each_channel_extra_seconds_max']
        add('clipping_channel'+str(index),b,limit,b is not None and limit is not None and b<=limit+1e-12)
    a=native.get('clipping_any_s');b=candidate.get('clipping_any_s');limit=None if a is None else a+definitions['clipping']['any_channel_extra_seconds_max']
    add('clipping_any',b,limit,b is not None and limit is not None and b<=limit+1e-12)
    passed=all(x['passed']for x in checks)
    return dict(status='ACCEPT_SINGLE_CASE_ONLY'if passed else'STOP_CANDIDATE',passed=passed,checks=checks,automatic_adoption=False,no_tuning_or_retry=True)


def assessment_raw(raw,native_rule_quat):
    required=['time_s','exact_qpos','exact_qvel','exact_reference_quat','exact_reference_xy','exact_reference_velocity_m_s',
        'exact_requested','exact_applied','exact_previous_applied','exact_input_bounds','command_held_after_row']
    common={key:raw[key]for key in required};common['exact_reference_quat']=native_rule_quat
    return common


def metrics(raw,native_rule_quat,same_clock_n_quat,recovery_defs,old):
    common=assessment_raw(raw,native_rule_quat)
    assessed,s=old.assess(common,recovery_defs)
    actual_up=old.core.rotation(raw['exact_qpos'][:,3:7])[:,:,2]
    def up_error(reference):
        reference_up=old.core.rotation(reference)[:,:,2]
        return np.degrees(np.arccos(np.clip(np.sum(actual_up*reference_up,axis=1),-1.,1.)))
    own_error=up_error(raw['exact_reference_quat'])
    t=s['time_s'];full=np.ones(len(t),bool);moving=(t>=3.-1e-9)&(t<123.-1e-9);focus=(t>=100.5-1e-9)&(t<=104.+1e-9)
    acceleration=np.linalg.norm((raw['exact_qvel'][10:,:3]-raw['exact_qvel'][:-10,:3])/.05,axis=1)
    p=assessed['recovery']['path_motion']
    m=dict(entry_s=p['primary']['entry_s'],confirmation_s=p['primary']['confirmation_s'],persistent=p['last_good_tail']['sustained_through_end'],
        moving_timed_rms_m=float(np.sqrt(np.mean(s['timed_position_error_m'][moving]**2))),
        moving_global_rms_m=float(np.sqrt(np.mean(s['global_distance_m'][moving]**2))),moving_global_peak_m=float(s['global_distance_m'][moving].max()),
        full_timed_peak_m=float(s['timed_position_error_m'].max()),final_goal_m=assessed['whole_route']['final_goal_error_m'],
        native_rule_up_peak_deg=float(s['own_up_error_deg'].max()),native_rule_up_rms_deg=float(np.sqrt(np.mean(s['own_up_error_deg']**2))),
        own_up_peak_deg=float(own_error.max()),own_up_rms_deg=float(np.sqrt(np.mean(own_error**2))),
        absolute_tilt_peak_deg=float(s['absolute_tilt_deg'].max()),xy_speed_peak_m_s=float(s['xy_speed_m_s'].max()),
        world_z_abs_peak_rad_s=float(abs(s['world_z_rate_rad_s']).max()),acceleration_50ms_peak_m_s2=float(acceleration.max()),
        original_scale_command_step_peak=assessed['commands']['full']['original_030']['applied_steps']['maximum'],
        clipping_each_s=assessed['commands']['full']['own']['requested_clipped_each_seconds'],clipping_any_s=assessed['commands']['full']['own']['requested_clipped_any_seconds'],
        focus_path_peak_m=float(s['intended_distance_m'][focus].max()),focus_spatial_velocity_peak_m_s=float(s['spatial_velocity_error_m_s'][focus].max()),
        focus_native_rule_up_peak_deg=float(s['own_up_error_deg'][focus].max()),focus_absolute_tilt_peak_deg=float(s['absolute_tilt_deg'][focus].max()),
        focus_world_z_abs_peak_rad_s=float(abs(s['world_z_rate_rad_s'][focus]).max()))
    s['own_target_up_error_deg']=own_error;s['native_rule_up_error_deg']=s['own_up_error_deg']
    s['same_clock_N_up_error_deg']=up_error(same_clock_n_quat)
    return m,assessed,s


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--runs',type=Path,required=True);ap.add_argument('--registration',type=Path,required=True);ap.add_argument('--seal',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();out=args.output.resolve()
    if out.exists():raise FileExistsError(out)
    definitions=json.loads((HERE/'definitions.json').read_text());recovery_defs=json.loads((ROOT/definitions['recovery_definitions']).read_text())
    paths=dict(source=Path(__file__).resolve(),definitions=HERE/'definitions.json',tests=HERE/'test_gates.py',registration=args.registration.resolve(),seal=args.seal.resolve(),
        i83_core=I83/'core.py',i83_wrapper=I83/'evaluate.py',i83_definitions=ROOT/definitions['recovery_definitions'],
        old_native=ROOT/'results/current_belt_capacity_20261128/campaign/runs/B060/child/campaign/runs/eight_m100_N/precision.npz')
    for arm in ['N','T']:
        paths[arm+'_precision']=args.runs.resolve()/arm/'native/child/campaign/runs/eight_m100_N/precision.npz'
        paths[arm+'_outcome']=args.runs.resolve()/arm/'outcome.json'
    paths['T_policy']=args.runs.resolve()/'T/policy.npz'
    bindings={k:dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p))for k,p in paths.items()}
    seal=json.loads(paths['seal'].read_text());base=args.seal.resolve().parent.parent
    for arm in ['N','T']:
        p=paths[arm+'_precision'];item=seal['files'][str(p.relative_to(base))];assert item['sha256']==sha(p)and item['bytes']==p.stat().st_size
    out.mkdir(parents=True);(out/'source').mkdir()
    for key in ['source','definitions','tests','i83_core','i83_wrapper','i83_definitions']:
        target=out/'source'/key;shutil.copyfile(paths[key],target)
    save(out/'registered_before_arrays.json',dict(iteration='I-85',utc=datetime.now(timezone.utc).isoformat(),files=bindings,scope=definitions['scope']))
    old=module(I83/'evaluate.py','i85_frozen_i83_evaluator')
    with np.load(paths['old_native'],allow_pickle=False)as z:expected={k:z[k]for k in z.files}
    raws={}
    for arm in ['N','T']:
        with np.load(paths[arm+'_precision'],allow_pickle=False)as z:raws[arm]={k:z[k]for k in z.files}
    with np.load(paths['T_policy'],allow_pickle=False)as z:
        policy_time=z['time_s'];native_rule_quat=z['native_reference_quat']
    assert len(expected)==79
    native_parity=all(raws['N'][k].dtype==v.dtype and raws['N'][k].shape==v.shape and raws['N'][k].tobytes()==v.tobytes()for k,v in expected.items())
    hard=dict(native_all79_bit_exact=native_parity);cases={};signals={};summaries={}
    hard['T_native_rule_export']=bool(np.array_equal(policy_time,raws['T']['time_s'])and native_rule_quat.shape==(len(policy_time),4)and np.isfinite(native_rule_quat).all()and np.all(abs(np.linalg.norm(native_rule_quat,axis=1)-1.)<=1e-9))
    outside=(policy_time<99.5-1e-9)|(policy_time>104.+1e-9)
    hard['T_native_rule_unshaped_outside_window']=bool(np.array_equal(native_rule_quat[outside],raws['T']['exact_reference_quat'][outside]))
    for arm,raw in raws.items():
        t=raw['time_s'];outcome=json.loads(paths[arm+'_outcome'].read_text())
        complete=len(t)==26601 and abs(t[0])<=1e-9 and abs(t[-1]-133.)<=1e-9 and np.all(abs(np.diff(t)-.005)<=1e-9)
        hard[arm+'_complete_finite']=bool(complete and outcome.get('physical_failure')is None and np.isfinite(raw['exact_qpos']).all()and np.isfinite(raw['exact_qvel']).all())
        held=raw['command_held_after_row'].astype(bool);bounds=raw['exact_input_bounds']
        hard[arm+'_input_identity']=bool(np.array_equal(held,np.arange(len(t))<len(t)-1)and np.array_equal(raw['exact_previous_applied'][1:],raw['exact_applied'][:-1])and np.array_equal(raw['exact_applied'][held],np.clip(raw['exact_requested'][held],-bounds[held],bounds[held]))and np.all(bounds==definitions['operating_bounds']))
        hard[arm+'_heading_off']=bool(np.all(raw['exact_heading_command']==0.))
        if complete:
            unshaped=raw['exact_reference_quat']if arm=='N'else native_rule_quat
            summaries[arm],cases[arm],signals[arm]=metrics(raw,unshaped,raws['N']['exact_reference_quat'],recovery_defs,old)
            np.savez_compressed(out/(arm+'_signals.npz'),**signals[arm])
        else:summaries[arm]={};cases[arm]=dict(partial_recording=True,actual_end_s=float(t[-1]),outcome=outcome)
    prefix=raws['N']['time_s']<99.5-1e-9;prefix_count=int(prefix.sum());candidate=raws['T']
    hard['candidate_exact_prefix_all79']=bool(len(candidate['time_s'])>=prefix_count and all(candidate[k].dtype==raws['N'][k].dtype and candidate[k][:prefix_count].tobytes()==raws['N'][k][:prefix_count].tobytes()for k in expected))
    anchor=int(round(99.5/.005));boundary_keys=['exact_qpos','exact_qvel','exact_observer_wrench','exact_observer_generalized','exact_observer_interval_mean','exact_previous_applied','exact_estimated_normal','exact_estimated_support_loads_N','exact_estimated_contact_point_m']+[k for k in expected if k.startswith('truth_')]
    hard['candidate_measurement_boundary99p5']=bool(len(candidate['time_s'])>anchor and all(candidate[k][anchor].tobytes()==raws['N'][k][anchor].tobytes()for k in boundary_keys))
    common_n=min(len(raws['N']['time_s']),len(candidate['time_s']));active=(raws['N']['time_s'][:common_n]>=99.5-1e-9)&(raws['N']['time_s'][:common_n]<=104.+1e-9)
    delta=np.linalg.norm((candidate['exact_applied'][:common_n]-raws['N']['exact_applied'][:common_n])/np.array(definitions['operating_bounds']),axis=1)
    nonnull=float(delta[active].max())if active.any()else 0.
    decision=decide(summaries['N'],summaries['T'],hard,nonnull,definitions)
    save(out/'report.json',dict(iteration='I-85',definitions=definitions,decision=decision,hard_checks=hard,metrics=summaries,cases=cases,active_applied_normalized_difference_peak=nonnull,
        common_native_rule_attitude_reference=True,same_clock_N_attitude_diagnostic_separate=True,own_target_tracking_separate=True,no_new_physics=True,no_automatic_adoption=True))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    fig,axes=plt.subplots(4,1,figsize=(11,10),sharex=True)
    for arm,s in signals.items():
        mask=(s['time_s']>=99.5-1e-9)&(s['time_s']<=133.+1e-9);t=s['time_s'][mask]
        for ax,key,scale in zip(axes,['intended_distance_m','spatial_velocity_error_m_s','native_rule_up_error_deg','world_z_rate_rad_s'],[1000,1000,1.,180/np.pi]):ax.plot(t,scale*abs(s[key][mask]),label=arm)
    for ax,y,label in zip(axes,[20.,20.,2.,.05*180/np.pi],['Intended path distance(mm)','Spatial velocity residual(mm/s)','Unshaped native-rule up error(deg)','Absolute world-z spin(deg/s)']):
        ax.axhline(y,ls='--',c='gray');ax.axvspan(99.5,104.,alpha=.07);ax.set_ylabel(label);ax.grid(alpha=.2);ax.legend()
    axes[-1].set_xlabel('Recorded physical time(s)');fig.suptitle('I-85: '+decision['status']+' | primary2s recovery and common native-rule attitude reference');fig.tight_layout(rect=(0,0,1,.95));fig.savefig(out/'comparison.png',dpi=140)
    with PdfPages(out/'comparison.pdf')as pdf:pdf.savefig(fig)
    plt.close(fig)
    assert all(sha(paths[k])==v['sha256']for k,v in bindings.items())
    save(out/'artifact_manifest.json',dict(iteration='I-85',files={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(out.rglob('*'))if p.is_file()}))
    print(json.dumps(dict(status=decision['status'],checks=len(decision['checks']),failed=[x['name']for x in decision['checks']if not x['passed']])) ,flush=True)


if __name__=='__main__':main()
