"""Focused I85 acceptance contracts; no new trial arrays or physics."""
from pathlib import Path
import json
import unittest
import numpy as np
from evaluate import decide,assessment_raw


class GateContracts(unittest.TestCase):
    def setUp(self):
        self.d=json.loads(Path(__file__).with_name('definitions.json').read_text())
        self.n={k:1.for k in self.d['nonregression']};self.n.update(entry_s=117.675,clipping_each_s=[0.]*5,clipping_any_s=0.)
        self.c=dict(self.n,entry_s=116.675,persistent=True)

    def test_exact_one_second_benefit_and_persistence_required(self):
        self.assertTrue(decide(self.n,self.c,dict(valid=True),.001,self.d)['passed'])
        self.c['entry_s']=116.680
        self.assertFalse(decide(self.n,self.c,dict(valid=True),.001,self.d)['passed'])
        self.c['entry_s']=116.675;self.c['persistent']=False
        self.assertFalse(decide(self.n,self.c,dict(valid=True),.001,self.d)['passed'])

    def test_null_candidate_stops_even_if_recovery_values_improve(self):
        self.assertFalse(decide(self.n,self.c,dict(valid=True),0.,self.d)['passed'])
        self.assertFalse(decide(self.n,{},dict(valid=False),0.,self.d)['passed'])

    def test_common_attitude_failure_cannot_be_hidden_by_own_target(self):
        self.c['native_rule_up_peak_deg']=self.n['native_rule_up_peak_deg']+1.001
        self.c['own_up_peak_deg']=0.
        result=decide(self.n,self.c,dict(valid=True),.001,self.d)
        self.assertFalse(result['passed'])
        self.assertTrue(any(x['name']=='nonregression_native_rule_up_peak_deg'and not x['passed']for x in result['checks']))

    def test_assessment_boundary_excludes_truth_nans_and_uses_native_rule(self):
        keys=['time_s','exact_qpos','exact_qvel','exact_reference_quat','exact_reference_xy','exact_reference_velocity_m_s',
            'exact_requested','exact_applied','exact_previous_applied','exact_input_bounds','command_held_after_row']
        raw={key:np.zeros(1)for key in keys};raw['truth_patch_points_m']=np.array([np.nan]);native=np.array([[1.,0.,0.,0.]])
        selected=assessment_raw(raw,native)
        self.assertEqual(set(selected),set(keys))
        self.assertIs(selected['exact_reference_quat'],native)
        self.assertTrue(all(np.isfinite(x).all()for x in selected.values()))


if __name__=='__main__':unittest.main(verbosity=2)
