"""Clocked causal delivery of four captured views; no controller access."""
from __future__ import annotations

from collections import deque

import numpy as np


class CausalDepthMemory:
    def __init__(self, adapter, memory, capture_hz=20., latency_s=.05):
        if not np.isfinite([capture_hz, latency_s]).all() or capture_hz <= 0 or latency_s < 0:
            raise ValueError('Positive capture rate and nonnegative latency required')
        self._adapter, self.memory = adapter, memory
        self.capture_hz, self.latency_s = float(capture_hz), float(latency_s)
        self._queue = deque()
        self._next_capture = 0
        self._last_time = None
        self.captured_batches = self.delivered_batches = 0
        self.maximum_delivered_capture_s = None

    def advance(self, qpos, time_s):
        now = float(time_s)
        if not np.isfinite(now) or now < 0 or (self._last_time is not None and now < self._last_time - 1e-10):
            raise ValueError('Monotone finite measurement clock required')
        expected = self._next_capture / self.capture_hz
        captured = None
        if now >= expected - 1e-10:
            if abs(now - expected) > 1e-9:
                raise ValueError('Missing exact capture-time measured pose; do not backfill from a later pose')
            captured = tuple(self._adapter.render_batch(np.asarray(qpos, float).copy(), now, now + self.latency_s))
            if len(captured) != 4:
                raise AssertionError('Exactly four camera frames are required')
            if any(abs(f.capture_time_s-now)>1e-10 or abs(f.delivered_at_s-(now+self.latency_s))>1e-10 for f in captured):
                raise AssertionError('Adapter changed requested capture/delivery timestamps')
            self._queue.append(captured)
            self._next_capture += 1
            self.captured_batches += 1
        delivered = 0
        while self._queue and max(f.delivered_at_s for f in self._queue[0]) <= now + 1e-10:
            batch = self._queue.popleft()
            self.memory.ingest(batch, available_at_s=now)
            self.maximum_delivered_capture_s = max(f.capture_time_s for f in batch)
            self.delivered_batches += 1
            delivered += 1
        self._last_time = now
        return dict(captured=captured, delivered_batches=delivered, pending_batches=len(self._queue),
                    maximum_delivered_capture_s=self.maximum_delivered_capture_s)

    def query(self, xy, *, at_time_s):
        if self._last_time is None or abs(float(at_time_s)-self._last_time)>1e-10:
            raise ValueError('Map query must use the current delivery/measurement clock')
        return self.memory.query(xy, at_time_s=at_time_s)
