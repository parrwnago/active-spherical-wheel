"""Prospective presentation checks; no new trial arrays, models or rendering."""
import unittest
import numpy as np
from render import display_moments, ARMS, CAPS, LABELS


class RenderContracts(unittest.TestCase):
    def test_shared_event_grid_retains_entire_goal_hold(self):
        x=display_moments(99.5,133.)
        np.testing.assert_array_equal(x,np.arange(995,1331)/10.)
        self.assertEqual(len(x),336)
        self.assertEqual(int(np.sum((x>=123.)&(x<=133.))),101)

    def test_both_arms_have_same_capacity_and_distinct_policy_labels(self):
        self.assertEqual(ARMS,('N','T'));self.assertEqual(CAPS,dict(N=.6,T=.6))
        self.assertIn('Native',LABELS['N']);self.assertIn('Terrain-informed lean',LABELS['T'])

    def test_non_grid_time_window_is_rejected(self):
        with self.assertRaises(ValueError):display_moments(99.55,133.)


if __name__=='__main__':unittest.main(verbosity=2)
