"""Registered I84 causal four-camera shadow audit; no dynamics integration."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
import argparse
import hashlib
import json
import shutil
import traceback

import mujoco
import numpy as np

from spherical_wheel.contact_sensing import SupportLocator
from spherical_wheel.synchronization import ContactSynchronizer
from spherical_wheel.terrain_depth import FourCameraDepthAdapter, TerrainRayScene, four_camera_rig
from spherical_wheel.terrain_memory import MemorySettings, TerrainMemory

from causal_depth_memory import CausalDepthMemory
from map_preparation import MapPreparationSynchronizer, blended_command, current_guard_error


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
SETTINGS = json.loads((HERE / 'settings.json').read_text())
FAMILIES = ('shell_A', 'shell_B', 'belt_A', 'belt_B')
REQUIRED_COLUMNS = ('time_s', 'exact_qpos', 'exact_qvel', 'exact_previous_applied',
    'exact_applied', 'exact_requested', 'exact_observer_wrench', 'exact_estimated_normal',
    'exact_estimated_support_loads_N', 'exact_sync_weights', 'exact_transition_command_delta',
    'exact_equilibrium_command', 'exact_rolling_feedforward', 'exact_support_command',
    'exact_lqr_command', 'exact_heading_command', 'exact_fade_command_delta',
    'exact_clipping_command_delta', 'exact_drive_fade', 'exact_input_bounds')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def safe(value):
    if isinstance(value, dict): return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [safe(v) for v in value]
    if isinstance(value, Path): return str(value)
    if isinstance(value, np.ndarray): return safe(value.tolist())
    if isinstance(value, np.generic): return safe(value.item())
    if isinstance(value, float) and not np.isfinite(value): return None
    return value


def save(path, document):
    with Path(path).open('x') as stream:
        json.dump(safe(document), stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def preflight(path):
    protocol = json.loads(Path(path).read_text())
    if protocol.get('iteration') != 'I-84' or protocol.get('settings') != SETTINGS:
        raise ValueError('Frozen I84 registration with exact settings is required')
    for group in ('source_sha256', 'input_sha256'):
        for name, expected in protocol[group].items():
            if sha(ROOT / name) != expected:
                raise AssertionError('Registered source/input changed: ' + name)
    if protocol['source_sha256'].get(str(Path(__file__).relative_to(ROOT))) != sha(__file__):
        raise AssertionError('Audit source absent from frozen registration')
    for name in SETTINGS['inputs'].values():
        if name not in protocol['input_sha256']:
            raise AssertionError('Mandatory input absent from registration: ' + name)
    return protocol


def anchor_indices(times):
    times = np.asarray(times, float)
    expected = np.arange(SETTINGS['expected_rows']) * SETTINGS['control_dt_s']
    if times.shape != expected.shape or np.max(abs(times - expected)) > 1e-9:
        raise ValueError('Complete original 133s native clock required')
    uniform = np.arange(len(times)) % int(round(SETTINGS['uniform_anchor_stride_s'] / SETTINGS['control_dt_s'])) == 0
    low, high = SETTINGS['dense_anchor_window_s']
    dense = (times >= low - 1e-9) & (times <= high + 1e-9)
    return set(np.flatnonzero(uniform | dense).tolist()), uniform, dense


class MeasuredMirror:
    """Captured model and measured q/v/input only; never an integrated plant."""
    def __init__(self, model_xml, config, bounds):
        self.config = config
        self.model = mujoco.MjModel.from_xml_path(str(model_xml))
        self.model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
        self.data = mujoco.MjData(self.model)
        self.bounds = np.asarray(bounds, float).copy()
        self.last_input = np.zeros(5)
        self.dt = SETTINGS['control_dt_s']
        self.ground = self.terrain = None
        self.fork_id = int(mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, 'fork'))
        self._belts = []
        for side in ('A', 'B'):
            ids = [mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_GEOM, 'belt_' + side + suffix)
                   for suffix in ('', '_smooth')]
            if ids[0] < 0:
                raise ValueError('Captured mirror lacks belt geometry')
            self._belts.append([int(g) for g in ids if g >= 0])

    def set_measurement(self, qpos, qvel, time_s, previous_applied):
        applied = np.asarray(previous_applied, float)
        if applied.shape != (5,) or np.any(abs(applied) > self.bounds + 1e-12):
            raise ValueError('Previous actual command exceeds recorded operating bounds')
        self.data.qpos[:] = qpos
        self.data.qvel[:] = qvel
        self.data.time = float(time_s)
        self.last_input[:] = applied
        self.data.ctrl[:] = applied[:3]
        for index, ids in enumerate(self._belts):
            self.model.geom_surfacevel[ids] = 0.
            self.model.geom_surfacevel[ids, 1] = applied[3 + index]
        self.model.flg_surfacevel = 1
        # Contacts disabled: this evaluates measured-state frames/Jacobians.
        mujoco.mj_forward(self.model, self.data)
        if self.data.ncon != 0:
            raise AssertionError('Measured mirror acquired a solved contact')


def current_plane(previous, mirror, normal, records, radius):
    if previous is None or records:
        return (mirror.data.xpos[mirror.fork_id].copy() - radius * np.asarray(normal), np.asarray(normal).copy())
    return previous


def native_pre_sync(arrays, index):
    return (arrays['exact_equilibrium_command'][index] + arrays['exact_rolling_feedforward'][index] +
            arrays['exact_support_command'][index] + arrays['exact_lqr_command'][index])


def changed_applied(arrays, index, native_blended, map_blended, bounds):
    delta = np.asarray(map_blended) - np.asarray(native_blended)
    delta[:3] *= float(arrays['exact_drive_fade'][index])
    requested = arrays['exact_requested'][index] + delta
    return np.clip(requested, -bounds, bounds), requested


def numerical_error(first, second):
    return float(np.max(np.abs(np.asarray(first, float) - np.asarray(second, float))))


def run(args, protocol):
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    started = perf_counter()
    try:
        # All capture/metric/source definitions are preserved before np.load.
        save(out / 'registered_before_arrays.json', dict(iteration='I-84',
            utc=datetime.now(timezone.utc).isoformat(), registration_sha256=sha(args.registration),
            settings=SETTINGS, source_sha256=protocol['source_sha256'], input_sha256=protocol['input_sha256'],
            no_new_physics=True, no_controller_command=True, no_observer_update=True))
        shutil.copyfile(args.registration, out / 'frozen_registration.json')
        for name in protocol['source_sha256']:
            target = out / 'source' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, target)
        paths = {key: ROOT / value for key, value in SETTINGS['inputs'].items()}
        config = json.loads(paths['config'].read_text())
        sensor = protocol['sensor_scene']
        optical_model = mujoco.MjModel.from_xml_path(str(ROOT / sensor['model_xml']))
        environment = np.flatnonzero(optical_model.geom_group == 0)
        robot = np.flatnonzero(optical_model.geom_group == 1)
        scene = TerrainRayScene(optical_model, environment, robot, sensor['metadata'])
        # Scene source/crop/assets were sealed by registration before any arrays.
        save(out / 'sensor_scene_binding_before_arrays.json', sensor)
        with np.load(paths['precision'], allow_pickle=False) as saved:
            if not set(REQUIRED_COLUMNS).issubset(saved.files):
                raise ValueError('Captured native command/observer decomposition is incomplete')
            arrays = {name: saved[name].copy() for name in REQUIRED_COLUMNS}
        times = arrays['time_s']
        anchors, uniform, dense = anchor_indices(times)
        mirror = MeasuredMirror(paths['model_xml'], config, SETTINGS['operating_bounds'])
        radius = float(config['geometry']['sphere_radius_m'])
        weight = float(mirror.model.body_subtreemass[mirror.fork_id]) * abs(float(config['simulation']['gravity_m_s2'][2]))
        locator = SupportLocator(mirror.model, mirror.fork_id, radius, float(config['contact']['friction'][0]), .05 * weight)
        native = ContactSynchronizer(mirror)
        adapter = FourCameraDepthAdapter(scene, four_camera_rig())
        memory = TerrainMemory(MemorySettings(**SETTINGS['memory']))
        causal = CausalDepthMemory(adapter, memory, SETTINGS['capture_hz'], SETTINGS['latency_s'])
        mapped = MapPreparationSynchronizer(native, causal, SETTINGS['foot_consistency_m'])
        if native.lookahead_s != SETTINGS['lookahead_s']:
            raise AssertionError('Native preparation horizon differs from registration')
        plane, rows, capture_times, delivered_times = None, [], [], []
        depths, masks, poses, capture_wall = [], [], [], []
        rejection_reasons = Counter()
        for index, time_s in enumerate(times):
            mirror.set_measurement(arrays['exact_qpos'][index], arrays['exact_qvel'][index], time_s,
                                   arrays['exact_previous_applied'][index])
            records = locator.records(mirror.data, arrays['exact_observer_wrench'][index, :3],
                                      arrays['exact_observer_wrench'][index, 3:])
            plane = current_plane(plane, mirror, arrays['exact_estimated_normal'][index], records, radius)
            before_capture = perf_counter()
            batch = causal.advance(arrays['exact_qpos'][index], time_s)
            if batch['captured'] is not None:
                frames = batch['captured']
                capture_times.append(time_s)
                delivered_times.append(time_s + SETTINGS['latency_s'])
                depths.append(np.stack([frame.depth_m for frame in frames]))
                masks.append(np.stack([frame.valid_mask for frame in frames]))
                poses.append(np.stack([frame.world_from_camera for frame in frames]))
                capture_wall.append(perf_counter()-before_capture)
            if index not in anchors:
                continue
            bounds = np.asarray(arrays['exact_input_bounds'][index])
            if not np.array_equal(bounds, mirror.bounds):
                raise AssertionError('Captured native operating bounds differ')
            primary = native_pre_sync(arrays, index)
            native_preview = native.preview(primary, records=records, ground=plane)
            native_blended = blended_command(primary, native_preview)
            native_delta = native_blended - primary
            reconstructed_requested = (native_blended + arrays['exact_heading_command'][index] +
                                       arrays['exact_fade_command_delta'][index])
            loads = np.array([sum(max(0., float(r['normal_force'])) for r in records
                                  if r['name'] == family or r['name'].startswith(family+'_')) for family in FAMILIES])
            parity = dict(sync_weights=numerical_error(native_preview['blend_weights'], arrays['exact_sync_weights'][index]),
                transition_delta=numerical_error(native_delta, arrays['exact_transition_command_delta'][index]),
                requested=numerical_error(reconstructed_requested, arrays['exact_requested'][index]),
                applied=numerical_error(np.clip(reconstructed_requested,-bounds,bounds), arrays['exact_applied'][index]),
                estimated_loads=numerical_error(loads, arrays['exact_estimated_support_loads_N'][index]))
            map_preview = mapped.preview(primary, records=records, ground=plane)
            map_blended = blended_command(primary, map_preview)
            map_applied, map_requested = changed_applied(arrays, index, native_blended, map_blended, bounds)
            guard_error = current_guard_error(native_preview, map_preview)
            diagnostic = mapped.last_map_diagnostics
            rejection_reasons.update(diagnostic['rejection_reasons'])
            complete_opportunity = any(item['selected_future_map_accepted'] and item['blend_weight'] > 0.
                                       for item in diagnostic['selected_targets'])
            change = float(np.linalg.norm((map_applied-arrays['exact_applied'][index])/bounds))
            low, high = SETTINGS['gate_focus_window_s']
            focus = low-1e-9 <= time_s <= high+1e-9
            qualifies = complete_opportunity and change >= SETTINGS['gate_normalized_applied_change']
            rows.append(dict(index=index, time_s=time_s, uniform=bool(uniform[index]), dense=bool(dense[index]),
                focus=focus, native_parity_errors=parity, current_guard_error=guard_error,
                complete_future_map_nonzero_blend=complete_opportunity, normalized_applied_change=change,
                potential_gate_opportunity=qualifies, native_preview=native_preview, map_preview=map_preview,
                map_diagnostics=diagnostic, native_pre_sync=primary,
                native_applied=arrays['exact_applied'][index], map_shadow_applied=map_applied,
                map_shadow_requested=map_requested, observer_plane=plane,
                maximum_delivered_capture_s=batch['maximum_delivered_capture_s']))
            if len(rows) % 100 == 0:
                print(json.dumps(dict(stage='causal_shadow', anchors=len(rows), time_s=float(time_s),
                                      captured_batches=causal.captured_batches, wall_s=perf_counter()-started)), flush=True)
        maximum_parity = max(max(row['native_parity_errors'].values()) for row in rows)
        maximum_guard = max(row['current_guard_error'] for row in rows)
        qualifying = sum(row['focus'] and row['potential_gate_opportunity'] for row in rows)
        integrity = maximum_parity <= SETTINGS['gate_native_and_current_guard_tolerance'] and maximum_guard <= SETTINGS['gate_native_and_current_guard_tolerance']
        potential = integrity and qualifying >= SETTINGS['gate_minimum_focus_opportunities']
        save(out / 'rows.json', dict(iteration='I-84', rows=rows))
        np.savez_compressed(out / 'depth_batches.npz', capture_time_s=capture_times, delivered_at_s=delivered_times,
            depth_m=np.stack(depths), valid_mask=np.stack(masks), world_from_camera=np.stack(poses),
            intrinsics=np.stack([camera.intrinsics for camera in adapter.cameras]),
            body_from_camera=np.stack([camera.body_from_camera for camera in adapter.cameras]),
            camera_names=np.array([camera.name for camera in adapter.cameras]), capture_wall_s=capture_wall)
        save(out / 'scene_metadata.json', scene.metadata)
        report = dict(iteration='I-84', native_rows=len(times), audit_anchors=len(rows),
            uniform_anchors=int(np.sum(uniform)), dense_anchors=int(np.sum(dense)),
            focus_anchors=sum(row['focus'] for row in rows), focus_qualifying_opportunities=qualifying,
            maximum_native_parity_error=maximum_parity, maximum_current_guard_error=maximum_guard,
            integrity_passed=integrity, potential_gate_passed=potential,
            decision=('INVALID_SHADOW_RECONSTRUCTION' if not integrity else
                      'POTENTIAL_FOR_FROZEN_LIVE_COMPARISON_ROOT_DECISION_REQUIRED' if potential else
                      'STOP_NO_REGISTERED_FOCUS_UTILITY_NO_LIVE_TRIAL'),
            camera_batches_captured=causal.captured_batches, camera_batches_delivered=causal.delivered_batches,
            pending_batches=len(causal._queue), rejection_reasons=dict(rejection_reasons),
            assumptions=['ideal finite-view four-camera depth', 'perfect capture-time pose', 'static 2.5D map',
                         'CV future pose', 'no load/friction/contact-force prediction'],
            no_new_physics=True, no_controller_command=True, no_observer_update=True,
            shadow_command_changes_are_not_motion_results=True, wall_s=perf_counter()-started)
        preflight(args.registration)
        save(out / 'report.json', report)
        files = {str(path.relative_to(out)): dict(bytes=path.stat().st_size, sha256=sha(path))
                 for path in sorted(out.rglob('*')) if path.is_file()}
        save(out / 'artifact_manifest.json', dict(iteration='I-84', files=files))
        print(json.dumps(safe(report)), flush=True)
    except BaseException:
        save(out / 'failure.json', dict(iteration='I-84', traceback=traceback.format_exc(), no_new_physics=True))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--registration', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--run-audit', action='store_true')
    args = parser.parse_args()
    protocol = preflight(args.registration)
    if args.preflight_only:
        print(json.dumps(dict(iteration='I-84', passed=True, arrays_read=False, physics_run=False)))
        return
    if not args.run_audit or args.output is None:
        raise SystemExit('Explicit --run-audit and new --output required')
    run(args, protocol)


if __name__ == '__main__':
    main()
