"""Adversarial synthetic contracts for the independent I83 recovery audit."""
import unittest
import numpy as np
from independent import curve, project_section, inverse_progress, spatial_reference, attitude, episodes


class RecoveryContracts(unittest.TestCase):
    def test_wrong_lobe_cannot_claim_last_quarter_recovery(self):
        wrong_lobe = curve(np.array([.125]))
        self.assertGreater(project_section(wrong_lobe)['distance_m'][0], .25)

    def test_exact_section_nodes_and_both_clamped_endpoints(self):
        u = np.array([.75, .875, 1.])
        x = project_section(curve(u))
        np.testing.assert_allclose(x['distance_m'], 0., atol=1e-14)
        np.testing.assert_allclose(x['projected_u'], u, atol=1e-14)
        self.assertTrue(x['lower_endpoint'][0]); self.assertTrue(x['upper_endpoint'][-1])
        self.assertFalse(x['lower_endpoint'][1])

    def test_projection_is_on_segment_not_nearest_vertex(self):
        nodes = curve(np.array([3500., 3501.])/4096.)
        p = .25*nodes[0]+.75*nodes[1]
        x = project_section(p[None, :])
        self.assertLess(x['distance_m'][0], 1e-14)
        self.assertAlmostEqual(x['projected_u'][0], 3500.75/4096., places=13)

    def test_nominal_velocity_uses_inverse_clock_and_zero_end_speed(self):
        r = np.array([0., .1, .5, .8, 1.])
        u = 10*r**3-15*r**4+6*r**5
        np.testing.assert_allclose(inverse_progress(u), r, atol=1e-12)
        ref = spatial_reference(u)
        np.testing.assert_allclose(ref['nominal_time_s'], 3+120*r, atol=1e-10)
        np.testing.assert_array_equal(ref['velocity_m_s'][[0, -1]], np.zeros((2, 2)))
        np.testing.assert_allclose(np.linalg.norm(ref['tangent_xy'], axis=1), 1., atol=1e-14)

    def test_tilted_terrain_reference_is_balanced_and_negative_spin_retained(self):
        a = np.deg2rad(10.)/2
        q = np.array([[np.cos(a), np.sin(a), 0., 0.]])
        result = attitude(q, q, [[0., 0., -.5]])
        self.assertAlmostEqual(result['absolute_tilt_deg'][0], 10., places=10)
        self.assertLess(result['own_up_error_deg'][0], 1e-6)
        self.assertLess(result['world_z_rate_rad_s'][0], -.49)

    def test_short_entry_is_distinct_from_two_second_recovery(self):
        t = np.arange(10050, 10401)/100.
        good = ((t >= 100.7) & (t <= 100.9)) | (t >= 101.2)
        out = episodes(t, good, horizon_s=104.)
        self.assertEqual(out['first_entry_s'], 100.7)
        self.assertEqual(out['first_sustained_entry_s'], 101.2)
        self.assertEqual(out['first_sustained_confirmation_s'], 103.2)
        self.assertTrue(out['anchor_outside_left_censored'])

    def test_sustained_recovery_can_have_later_qualifying_reexit(self):
        t = np.arange(10050, 10801)/100.
        good = ((t >= 100.7) & (t <= 103.)) | (t >= 103.3)
        out = episodes(t, good, horizon_s=108.)
        self.assertEqual(out['qualifying_reexit_count_after_first_dwell'], 1)
        self.assertEqual(out['terminal_persistent_entry_s'], 103.3)
        self.assertTrue(out['terminal_persistent_sustained'])

    def test_short_terminal_crossing_is_censored_not_recovered(self):
        t = np.arange(10050, 10401)/100.
        out = episodes(t, t >= 103., horizon_s=104.)
        self.assertEqual(out['first_entry_s'], 103.)
        self.assertIsNone(out['first_sustained_entry_s'])
        self.assertTrue(out['right_censored_insufficient_dwell'])
        self.assertFalse(out['terminal_persistent_sustained'])

    def test_missing_horizon_never_establishes_terminal_persistence(self):
        t = np.arange(10050, 10401)/100.
        out = episodes(t, t >= 101., horizon_s=133.)
        self.assertIsNotNone(out['first_sustained_entry_s'])
        self.assertFalse(out['complete_horizon'])
        self.assertFalse(out['terminal_persistent_sustained'])

    def test_exit_sample_span_threshold_and_sensitivity_are_explicit(self):
        t = np.arange(10050, 10401)/100.
        good = np.ones(len(t), bool)
        good[(t >= 100.6) & (t <= 100.69)] = False
        out = episodes(t, good, horizon_s=104.)
        self.assertEqual(len(out['sampled_bad_runs']), 1)
        self.assertEqual(len(out['qualifying_exit_runs']), 0)
        one = episodes(t, t >= 102.5, horizon_s=104., dwell_s=1.)
        two = episodes(t, t >= 102.5, horizon_s=104., dwell_s=2.)
        self.assertIsNotNone(one['first_sustained_entry_s'])
        self.assertIsNone(two['first_sustained_entry_s'])


if __name__ == '__main__': unittest.main(verbosity=2)
