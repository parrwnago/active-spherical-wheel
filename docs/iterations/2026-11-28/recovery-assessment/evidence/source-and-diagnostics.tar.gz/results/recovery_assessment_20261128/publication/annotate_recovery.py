"""Append I83 recovery annotations to existing I82 recorded video frames only.

This is retrospective presentation, with no geometry rendering, control or
physics. Original source MP4 remains unchanged. All recovery decisions come
from already closed, independently checked 200 Hz analysis records.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
FPS = 10
SOURCE_WIDTH, SOURCE_HEIGHT = 1600, 1010
OUTPUT_HEIGHT = 1460
FONT = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()


def save(p, x):
    with Path(p).open('x') as f:
        json.dump(x, f, indent=2, sort_keys=True, allow_nan=False); f.write('\n')


def source_indices(start=100.5, end=133.):
    if not np.isfinite([start, end]).all() or start < 0. or end < start:
        raise ValueError('Finite ordered physical clocks required')
    first, last = round(start*FPS), round(end*FPS)
    if abs(first/FPS-start) > 1e-9 or abs(last/FPS-end) > 1e-9:
        raise ValueError('Clip endpoints must lie on original 10 fps grid')
    return np.arange(first, last+1, dtype=int)


def recorded_status(row):
    p = row['primary']
    if p['status'] == 'no_qualifying_departure': return 'No qualifying departure; recovery time N/A'
    if p['entry_s'] is None: return 'No 2 s interval observed by 133 s (right-censored)'
    return f"Recorded 2 s interval: {p['entry_s']:.3f} to {p['confirmation_s']:.3f} s"


def lookup(times, moment):
    i = int(np.argmin(abs(times-moment)))
    if abs(times[i]-moment) > 1e-8: raise ValueError('Missing registered analysis state at video time')
    return i


def append_panel(rgb, moment, signals, report, definitions):
    from PIL import Image, ImageDraw, ImageFont
    frame = Image.new('RGB', (SOURCE_WIDTH, OUTPUT_HEIGHT), (12, 22, 31))
    frame.paste(Image.fromarray(rgb), (0, 0))
    draw = ImageDraw.Draw(frame)
    title = ImageFont.truetype(str(FONT), 25); normal = ImageFont.truetype(str(FONT), 20)
    small = ImageFont.truetype(str(FONT), 17)
    white, gray = (234, 239, 244), (177, 192, 204)
    green, red = (80, 210, 153), (246, 133, 115)
    draw.line((0, SOURCE_HEIGHT, SOURCE_WIDTH, SOURCE_HEIGHT), fill=(130, 151, 170), width=2)
    draw.text((20, 1020), f'I-83 recovery assessment | t = {moment:.2f} s | retrospective annotations', font=title, fill=white)
    draw.text((20, 1055), 'Path motion: section distance <=20 mm, spatial velocity error <=20 mm/s, own up error <=2 deg, tilt <=15 deg.', font=normal, fill=gray)
    draw.text((20, 1082), 'Strict motion adds |world-z spin| <=0.05 rad/s (2.865 deg/s). Common 100.5 s anchor is not physical disturbance onset.', font=normal, fill=gray)
    panel_records = {}
    for number, arm in enumerate(['B030', 'B060']):
        x = 20+number*800; y = 1120; s = signals[arm]; t = s['time_s']; i = lookup(t, moment)
        motion = bool(s['good__path_motion'][i]); strict = bool(s['good__path_full'][i])
        draw.text((x, y), arm+' | belt cap '+('0.30' if arm == 'B030' else '0.60')+' m/s', font=title, fill=white)
        draw.text((x, y+34), 'Instant path: '+('IN BAND' if motion else 'OUTSIDE'), font=normal, fill=green if motion else red)
        draw.text((x+350, y+34), 'Strict (+spin): '+('IN BAND' if strict else 'OUTSIDE'), font=normal, fill=green if strict else red)
        draw.text((x, y+62), f"Distance {1000*s['intended_distance_m'][i]:.1f} mm | dv {1000*s['spatial_velocity_error_m_s'][i]:.1f} mm/s | up {s['own_up_error_deg'][i]:.2f} deg", font=normal, fill=gray)
        draw.text((x, y+88), f"|Spin| {np.rad2deg(abs(s['world_z_rate_rad_s'][i])):.2f} deg/s | tilt {s['absolute_tilt_deg'][i]:.2f} deg", font=normal, fill=gray)
        row = report['cases'][arm]['recovery']['path_motion']; full = report['cases'][arm]['recovery']['path_full']
        first = row['first_threshold_entry_s']; one = row['secondary']['entry_s']
        fmt = lambda value: 'not observed' if value is None else f'{value:.3f} s'
        draw.text((x, y+115), 'First entry: '+fmt(first)+' | 1 s entry: '+fmt(one), font=normal, fill=gray)
        draw.text((x, y+142), recorded_status(row), font=normal, fill=white)
        left = 'Onset left-censored at anchor' if row['outside_at_anchor'] else 'Inside band at anchor; fixed departure search ends 104 s'
        draw.text((x, y+169), left, font=small, fill=gray)
        draw.text((x, y+192), f"Later qualifying exits: {row['primary']['later_qualifying_exit_count']} | strict: "+('2 s observed' if full['primary']['entry_s'] is not None else 'no 2 s return'), font=small, fill=gray)
        for k, name in enumerate(['path_motion', 'path_full']):
            top = y+219+k*29; left_x, right_x = x+125, x+755
            draw.text((x, top-1), 'Path' if k == 0 else '+ spin', font=small, fill=gray)
            keep = (t >= definitions['event_anchor_s']-1e-9) & (t <= definitions['recording_end_s']+1e-9)
            state = s['good__'+name][keep]; times = t[keep]
            draw.rectangle((left_x, top, right_x, top+17), fill=(39, 112, 83))
            changes = np.diff(np.r_[False, ~state, False].astype(np.int8))
            for a, b in zip(np.flatnonzero(changes == 1), np.flatnonzero(changes == -1)-1):
                a_x = left_x+(times[a]-100.5)/32.5*(right_x-left_x)
                b_x = left_x+(times[b]-100.5)/32.5*(right_x-left_x)
                draw.rectangle((a_x, top, max(a_x+1., b_x), top+17), fill=(160, 65, 59))
            now = left_x+(moment-100.5)/32.5*(right_x-left_x)
            draw.line((now, top-2, now, top+19), fill=white, width=2)
        panel_records[arm] = dict(source_state_row=i, path_motion_good=motion, path_full_good=strict)
    draw.text((20, 1420), 'Ribbons: 100.5 to 133 s, green in band / red outside. Decisions use every 5 ms state; labels show 10 fps. Later exits may be new terrain.', font=small, fill=gray)
    return np.asarray(frame), panel_records


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--canonical', type=Path, required=True)
    ap.add_argument('--verification', type=Path, required=True)
    ap.add_argument('--definitions', type=Path, required=True)
    ap.add_argument('--root-registration', type=Path, required=True)
    ap.add_argument('--source-video', type=Path, required=True)
    ap.add_argument('--source-metadata', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args(); out = args.output.resolve()
    if out.exists(): raise FileExistsError(out)
    files = dict(source=Path(__file__).resolve(), font=FONT, definitions=args.definitions.resolve(),
        root_registration=args.root_registration.resolve(), source_video=args.source_video.resolve(),
        source_metadata=args.source_metadata.resolve(), report=args.canonical.resolve()/'report.json',
        verification=args.verification.resolve()/'report.json')
    for arm in ['B030', 'B060']: files[arm+'_signals'] = args.canonical.resolve()/(arm+'_signals.npz')
    bindings = {name: dict(path=str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p), bytes=p.stat().st_size, sha256=sha(p)) for name, p in files.items()}
    metadata = json.loads(files['source_metadata'].read_text())
    assert metadata['iteration'] == 'I-82' and metadata['video']['all_frames_decoded']
    assert metadata['fps'] == FPS and metadata['frames'] == 1331
    assert bindings['source_video']['sha256'] == metadata['video']['sha256']
    assert json.loads(files['verification'].read_text())['passed']
    definitions = json.loads(files['definitions'].read_text()); report = json.loads(files['report'].read_text())
    assert report['definitions'] == definitions and report['iteration'] == 'I-83'
    out.mkdir(parents=True); (out/'source').mkdir(); shutil.copyfile(files['source'], out/'source'/files['source'].name)
    save(out/'registered_before_arrays_and_video.json', dict(iteration='I-83', utc=datetime.now(timezone.utc).isoformat(), files=bindings,
        policy='Existing I82 frames only, unchanged original movie, appended retrospective panel. No geometry render, observer/controller or physics.',
        video_grid=dict(fps=FPS, physical_start_s=100.5, physical_end_s=133., speed=1., source_frame_indices=[1005, 1330], output_frames=326),
        caution='Full posthoc ribbons/recorded entry times describe the closed analysis; they are not information supplied to live control.'))
    signals = {}
    for arm in ['B030', 'B060']:
        with np.load(files[arm+'_signals'], allow_pickle=False) as z: signals[arm] = {key: z[key] for key in z.files}
    import imageio.v2 as imageio
    import imageio_ffmpeg
    wanted = source_indices(); video = out/'recovery_100p5_133_B030_B060.mp4'; schedule = []
    stream = imageio_ffmpeg.read_frames(str(files['source_video']), input_params=['-threads', '1'], output_params=['-threads', '1'])
    source_info = next(stream)
    assert source_info['size'] == (SOURCE_WIDTH, SOURCE_HEIGHT) and source_info['fps'] == FPS
    count = source_count = 0
    writer = imageio.get_writer(video, fps=FPS, codec='libx264', macro_block_size=2, quality=None,
        ffmpeg_log_level='error', ffmpeg_params=['-crf', '20', '-preset', 'fast', '-threads', '2'])
    try:
        for frame_number, pixels in enumerate(stream):
            source_count += 1
            if frame_number < wanted[0] or frame_number > wanted[-1]: continue
            moment = frame_number/FPS
            rgb = np.frombuffer(pixels, np.uint8).reshape(SOURCE_HEIGHT, SOURCE_WIDTH, 3)
            composite, panels = append_panel(rgb, moment, signals, report, definitions)
            writer.append_data(composite); count += 1
            if count in [1, 11, 164, 326]: imageio.imwrite(out/f'frame_{moment:.2f}s.jpg', composite, quality=95)
            schedule.append(dict(output_frame=count-1, source_frame=frame_number, physical_time_s=moment, panels=panels))
            if count % 100 == 0: print(json.dumps(dict(frames=count, physical_time_s=moment)), flush=True)
    finally:
        writer.close(); stream.close()
    assert count == 326 and source_count == 1331
    stream = imageio_ffmpeg.read_frames(str(video), input_params=['-threads', '1'], output_params=['-threads', '1'])
    info = next(stream); decoded = 0
    assert info['size'] == (SOURCE_WIDTH, OUTPUT_HEIGHT) and info['fps'] == FPS
    try:
        for i, pixels in enumerate(stream):
            decoded += 1
            if i in [0, 10, 163, 325]:
                from PIL import Image
                Image.frombytes('RGB', info['size'], pixels).save(out/f'decoded_{i:04d}.jpg', quality=95)
    finally: stream.close()
    assert decoded == 326 and abs(info['duration']-32.6) < .03
    assert all(sha(files[name]) == item['sha256'] for name, item in bindings.items())
    save(out/'display_schedule.json', schedule)
    save(out/'metadata.json', dict(iteration='I-83', source_frame_indices=[1005, 1330], source_frames_read=source_count,
        frames=326, decoded_frames=decoded, all_frames_decoded=True, fps=FPS, playback_speed=1., nominal_window_s=[100.5, 133.],
        container_duration_s=info['duration'], dimensions=[SOURCE_WIDTH, OUTPUT_HEIGHT], bytes=video.stat().st_size,
        sha256=sha(video), path=str(video.relative_to(ROOT)), source_video_sha256=bindings['source_video']['sha256'],
        no_new_render_or_physics=True, original_inputs_unchanged=True,
        qualification='Retrospective recovery annotations on original recorded Gazebo/DART video; 200 Hz decisions displayed at 10 fps.'))
    save(out/'artifact_manifest.json', dict(iteration='I-83', files={str(p.relative_to(out)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(out.rglob('*')) if p.is_file()}))
    print(json.dumps(dict(video=str(video), frames=count, all_frames_decoded=True, sha256=sha(video))), flush=True)


if __name__ == '__main__': main()
