"""Synthetic I-83 scoring contracts; no recorded robot arrays are loaded."""
import importlib.util
import json
from pathlib import Path
import unittest
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i83_core_contracts', HERE/'core.py')
core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
DEFINITIONS = json.loads((HERE.parent/'protocol/definitions.json').read_text())


class RecoveryContracts(unittest.TestCase):
    def setUp(self):
        self.defs = json.loads(json.dumps(DEFINITIONS))
        self.defs.update(event_anchor_s=0., departure_search_end_s=1., recording_end_s=6.)
        self.t = np.arange(1201)*.005

    def test_grid_subset_preserves_original_resolution(self):
        p = core.path_geometry(self.defs['route'])
        self.assertEqual(len(p['xy']), 4097)
        self.assertEqual(len(p['branch_xy']), 1025)
        np.testing.assert_array_equal(p['branch_xy'], p['xy'][3072:])

    def test_wrong_lobe_global_nearness_does_not_mean_intended_rejoin(self):
        p = core.path_geometry(self.defs['route'])
        point = p['xy'][1024:1025]
        g = core.project_segments(point, p['xy'], p['u'])
        b = core.project_segments(point, p['branch_xy'], p['branch_u'])
        self.assertLess(g['distance_m'][0], 1e-12)
        self.assertGreater(b['distance_m'][0], .2)

    def test_segment_projection_not_vertex_distance_and_tie_smallest_u(self):
        p = np.array([[0., 0.], [1., 0.], [0., 0.]])
        r = core.project_segments([[.25, .2]], p, [0., .5, 1.])
        self.assertAlmostEqual(r['distance_m'][0], .2)
        self.assertAlmostEqual(r['u'][0], .125)
        self.assertEqual(r['segment_index'][0], 0)

    def test_inverse_clock_and_velocity_endpoints(self):
        r = np.array([0., .03, .25, .5, .72, .97, 1.])
        u = core.progress(r)
        np.testing.assert_allclose(core.inverse_progress(u), r, atol=2e-12, rtol=0.)
        v, tangent = core.spatial_velocity(np.array([0., .5, 1.]), self.defs['route'])
        np.testing.assert_array_equal(v[[0, -1]], np.zeros((2, 2)))
        np.testing.assert_allclose(np.linalg.norm(tangent, axis=1), 1., atol=2e-16)
        self.assertGreater(np.linalg.norm(v[1]), 0.)

    def test_two_second_dwell_needs401_states(self):
        good = np.zeros(len(self.t), bool); good[100:500] = True
        r = core.recovery(self.t, good, self.defs)
        self.assertTrue(r['primary']['right_censored'])
        self.assertEqual(r['secondary']['entry_s'], .5)
        good[500] = True
        r = core.recovery(self.t, good, self.defs)
        self.assertEqual(r['primary']['entry_s'], .5)
        self.assertEqual(r['primary']['confirmation_s'], 2.5)

    def test_accumulated_clock_still_uses401_validated_states(self):
        t = np.empty(601); t[0] = 100.5
        for i in range(1, len(t)):
            t[i] = t[i-1]+.005
        self.defs.update(event_anchor_s=100.5, departure_search_end_s=101., recording_end_s=103.5)
        good = np.zeros(len(t), bool); good[100:501] = True
        r = core.recovery(t, good, self.defs)
        self.assertEqual(r['primary']['entry_s'], t[100])
        self.assertEqual(r['primary']['confirmation_s'], t[500])

    def test_inside_without_qualifying_departure_not_zero_recovery(self):
        good = np.ones(len(self.t), bool); good[40:60] = False
        r = core.recovery(self.t, good, self.defs)
        self.assertEqual(r['classification'], 'no_qualifying_departure')
        self.assertIsNone(r['primary']['entry_s'])
        self.assertFalse(r['primary']['right_censored'])
        self.assertTrue(r['last_good_tail']['sustained_through_end'])

    def test_bad_run100ms_qualifies_and_late_new_departure_excluded(self):
        good = np.ones(len(self.t), bool); good[40:61] = False
        r = core.recovery(self.t, good, self.defs)
        self.assertEqual(r['classification'], 'observed_qualifying_departure')
        self.assertAlmostEqual(r['departure_start_s'], .2)
        self.assertAlmostEqual(r['departure_confirmation_s'], .3)
        self.assertAlmostEqual(r['primary']['entry_s'], .305)
        good = np.ones(len(self.t), bool); good[300:400] = False
        self.assertEqual(core.recovery(self.t, good, self.defs)['classification'], 'no_qualifying_departure')

    def test_left_censored_onset_and_insufficient_terminal_tail(self):
        good = np.zeros(len(self.t), bool); good[1100:] = True
        r = core.recovery(self.t, good, self.defs)
        self.assertEqual(r['classification'], 'left_censored_onset')
        self.assertIsNone(r['departure_confirmation_s'])
        self.assertEqual(r['first_threshold_entry_s'], 5.5)
        self.assertEqual(r['primary']['right_censoring_reason'], 'insufficient_terminal_tail')
        self.assertFalse(r['last_good_tail']['sustained_through_end'])

    def test_recovery_can_exit_later_and_not_persist_to_end(self):
        good = np.zeros(len(self.t), bool); good[100:701] = True
        good[710:800] = True; good[821:] = True
        r = core.recovery(self.t, good, self.defs)
        self.assertEqual(r['primary']['entry_s'], .5)
        self.assertEqual(r['primary']['later_short_bad_run_count'], 1)
        self.assertEqual(r['primary']['later_qualifying_exit_count'], 1)
        self.assertAlmostEqual(r['primary']['first_later_qualifying_exit_s'], 4.)
        self.assertFalse(r['last_good_tail']['sustained_through_end'])
        expected = np.mean(good[self.t >= 2.5-1e-12])
        self.assertEqual(r['primary']['remaining_good_sample_fraction'], expected)

    def test_clock_gap_cannot_complete_sustained_return(self):
        good = np.zeros(len(self.t), bool); good[100:] = True
        with self.assertRaises(ValueError):
            core.recovery(np.delete(self.t, 200), np.delete(good, 200), self.defs)

    def test_world_z_and_reference_up_are_distinct_from_absolute_tilt(self):
        angle = np.radians(10.)
        q = np.array([[0., 0., 0., np.cos(angle/2), np.sin(angle/2), 0., 0., 0., 0., 0.]])
        v = np.zeros((1, 9)); v[0, 5] = 1.
        raw = dict(time_s=np.array([100.5]), exact_qpos=q, exact_qvel=v,
            exact_reference_quat=q[:, 3:7].copy(), exact_reference_xy=q[:, :2].copy(),
            exact_reference_velocity_m_s=np.zeros((1, 2)))
        s = core.signals(raw, self.defs)
        self.assertAlmostEqual(s['own_up_error_deg'][0], 0., delta=1e-6)
        self.assertAlmostEqual(s['absolute_tilt_deg'][0], 10.)
        self.assertAlmostEqual(s['world_z_rate_rad_s'][0], np.cos(angle))

    def test_free_spin_does_not_fail_path_motion_but_fails_path_full(self):
        s = dict(intended_distance_m=np.array([.001]), own_up_error_deg=np.array([.1]),
            absolute_tilt_deg=np.array([10.]), world_z_rate_rad_s=np.array([.1]),
            spatial_velocity_error_m_s=np.array([.001]), timed_position_error_m=np.array([.001]),
            timed_velocity_error_m_s=np.array([.001]))
        good = core.criteria(s, self.defs)
        self.assertTrue(good['path_motion'][0])
        self.assertFalse(good['path_full'][0])


if __name__ == '__main__':
    unittest.main(verbosity=2)
