"""Independently audit I83 raw-state signals, predicates and full recovery ledgers."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import numpy as np
import independent

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
I82 = ROOT/'results/current_belt_capacity_20261128'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()


def safe(value):
    if isinstance(value, np.ndarray): return value.tolist()
    if isinstance(value, np.generic): return value.item()
    if isinstance(value, dict): return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [safe(x) for x in value]
    return value


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(safe(value), f, indent=2, sort_keys=True, allow_nan=False); f.write('\n')


def ledger_node(row):
    names = {'geometric', 'path_motion', 'path_full', 'timed_motion', 'timed_full'}
    found = []
    def visit(item):
        if not isinstance(item, dict): return
        if names.issubset(item) and all(isinstance(item[n], dict) and 'classification' in item[n] for n in names):
            found.append(item)
        for v in item.values(): visit(v)
    visit(row)
    if len(found) != 1: raise ValueError('Canonical case must have exactly one five-criterion recovery ledger')
    return found[0]


def compare_ledger(actual, expected, path='', differences=None):
    """No silent key/None/censor/count omissions in the full public ledger."""
    differences = [] if differences is None else differences
    if isinstance(expected, dict):
        if set(actual) != set(expected): raise ValueError(('Ledger schema differs', path, sorted(set(actual)-set(expected)), sorted(set(expected)-set(actual))))
        for k in expected: compare_ledger(actual[k], expected[k], path+'/'+k, differences)
    elif isinstance(expected, list):
        if len(actual) != len(expected): raise ValueError(('Ledger list differs', path, len(actual), len(expected)))
        for i, (a, e) in enumerate(zip(actual, expected)): compare_ledger(a, e, path+'/'+str(i), differences)
    elif isinstance(expected, bool) or expected is None or isinstance(expected, str):
        if actual != expected: raise ValueError(('Ledger value differs', path, actual, expected))
    elif isinstance(expected, int):
        if actual != expected: raise ValueError(('Ledger count differs', path, actual, expected))
        differences.append(dict(path=path, absolute_difference=0.))
    else:
        delta = abs(float(actual)-float(expected))
        if not np.isfinite(delta) or delta > 1e-9: raise ValueError(('Ledger scalar differs', path, actual, expected, delta))
        differences.append(dict(path=path, absolute_difference=delta))
    return differences


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base', type=Path, default=BASE)
    ap.add_argument('--root-registration', type=Path, required=True)
    ap.add_argument('--canonical', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args(); base = args.base.resolve(); canonical = args.canonical.resolve(); out = args.output.resolve()
    if out.exists(): raise FileExistsError(out)
    definitions = json.loads((base/'protocol/definitions.json').read_text())
    assert definitions['iteration'] == 'I-83'
    assert definitions['route']['intended_u_interval'] == [.75, 1.]
    assert definitions['route']['full_polyline_vertices'] == 4097
    assert definitions['route']['rotation_deg'] == 113.
    assert definitions['route']['moving_duration_s'] == 120. and definitions['route']['start_s'] == 3.
    paths = dict(source=Path(__file__).resolve(), independent=Path(independent.__file__).resolve(),
        tests=Path(__file__).resolve().with_name('test_independent.py'), definitions=base/'protocol/definitions.json',
        root_registration=args.root_registration.resolve(), canonical_report=canonical/'report.json', input_seal=I82/'campaign/outputs_sealed.json')
    for arm in ['B030', 'B060']:
        paths[arm+'_raw'] = I82/'campaign/runs'/arm/'child/campaign/runs/eight_m100_N/precision.npz'
        paths[arm+'_signals'] = canonical/(arm+'_signals.npz')
    bindings = {name: dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size, sha256=sha(p)) for name, p in paths.items()}
    old_seal = json.loads(paths['input_seal'].read_text())
    for arm in ['B030', 'B060']:
        rel = str(paths[arm+'_raw'].relative_to(I82))
        assert old_seal['files'][rel]['sha256'] == bindings[arm+'_raw']['sha256']
    out.mkdir(parents=True); (out/'source').mkdir()
    for name in ['source', 'independent', 'tests']: shutil.copyfile(paths[name], out/'source'/paths[name].name)
    write(out/'registered_before_arrays.json', dict(iteration='I-83', utc=datetime.now(timezone.utc).isoformat(), files=bindings,
        scope='Independent raw-state reconstruction and all five full recovery ledgers; no canonical metric imports, simulator calls or new physics.',
        numeric_policy='Boolean predicates, ledger keys/status/censors/counts exact; numeric ledger values <=1e-9; signal comparisons logged individually.'))
    canonical_report = json.loads(paths['canonical_report'].read_text())
    comparison_rows = []; predicate_rows = []; ledger_differences = []; recovered = {}
    for arm in ['B030', 'B060']:
        with np.load(paths[arm+'_raw'], allow_pickle=False) as raw:
            t = raw['time_s']
            assert len(t) == definitions['expected_rows'] and abs(t[0]) <= 1e-9 and abs(t[-1]-133.) <= 1e-9
            assert np.all(abs(np.diff(t)-.005) <= 1e-9)
            signals = independent.raw_signals(raw, definitions)
        checks = independent.predicates(signals, definitions)
        with np.load(paths[arm+'_signals'], allow_pickle=False) as saved:
            for key, ours in signals.items():
                theirs = saved[key]
                assert ours.shape == theirs.shape, (arm, key, ours.shape, theirs.shape)
                if ours.dtype.kind in 'biu':
                    assert np.array_equal(ours, theirs), (arm, key)
                    delta = 0.; tolerance = 0.
                else:
                    delta = float(np.max(abs(ours-theirs)))
                    tolerance = 5e-6 if key == 'own_up_error_deg' else 1e-9
                    assert np.isfinite(ours).all() and delta <= tolerance, (arm, key, delta, tolerance)
                comparison_rows.append(dict(arm=arm, signal=key, rows=len(ours), maximum_absolute_difference=delta, tolerance=tolerance))
            for key, good in checks.items():
                candidates = ['good__'+key, 'criterion__'+key, 'good_'+key, key]
                saved_key = next((k for k in candidates if k in saved), None)
                assert saved_key is not None, ('Missing saved predicate', arm, key, saved.files)
                assert np.array_equal(good, saved[saved_key]), (arm, key)
                predicate_rows.append(dict(arm=arm, criterion=key, rows=len(good), sample_exact=True))
        recovered[arm] = {key: independent.recovery_ledger(signals['time_s'], good, definitions) for key, good in checks.items()}
        node = ledger_node(canonical_report['cases'][arm])
        ledger_differences.extend(compare_ledger(recovered[arm], {k: node[k] for k in checks}, arm+'/recovery'))
        np.savez_compressed(out/(arm+'_independent_signals.npz'), **signals, **{'good__'+k: v for k, v in checks.items()})
    assert all(sha(paths[name]) == item['sha256'] for name, item in bindings.items())
    write(out/'report.json', dict(iteration='I-83', passed=True, no_new_physics=True, canonical_metric_imports=False,
        all_signal_checks=comparison_rows, all_predicate_checks=predicate_rows,
        all_nested_recovery_ledgers_equal=True, numeric_ledger_leaves=len(ledger_differences),
        maximum_ledger_difference=max((x['absolute_difference'] for x in ledger_differences), default=0.),
        cases=recovered, inputs_unchanged=True,
        qualification='Posthoc descriptive metrics of previously known I82 outcomes; not blind preregistration, a new physical experiment or altered I82 acceptance gates.'))
    files = {str(p.relative_to(out)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(out.rglob('*')) if p.is_file()}
    write(out/'artifact_manifest.json', dict(iteration='I-83', files=files))
    print(json.dumps(dict(passed=True, signal_arrays=len(comparison_rows), predicate_arrays=len(predicate_rows), numeric_ledger_leaves=len(ledger_differences))))


if __name__ == '__main__': main()
