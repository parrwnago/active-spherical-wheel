"""Build a verified small presentation bundle from closed I83/I84 artifacts."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / 'visual_bundle_stage01'


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    files = {
        'video/recovery_100p5_133_B030_B060.mp4': 'results/recovery_assessment_20261128/publication/video_stage01/recovery_100p5_133_B030_B060.mp4',
        'recovery/recovery_assessment.pdf': 'results/recovery_assessment_20261128/evaluation/completed_stage01/recovery_assessment.pdf',
        'recovery/followthrough_recovery.png': 'results/recovery_assessment_20261128/evaluation/completed_stage01/followthrough_recovery.png',
        'recovery/report.json': 'results/recovery_assessment_20261128/evaluation/completed_stage01/report.json',
        'recovery/independent_audit.json': 'results/recovery_assessment_20261128/verification/completed_stage01/report.json',
        'terrain/terrain_preview_shadow_assessment.pdf': 'results/terrain_recovery_preview_20261128/publication/completed_stage02/terrain_preview_shadow_assessment.pdf',
        'terrain/focus_shadow_applicability.png': 'results/terrain_recovery_preview_20261128/publication/completed_stage02/focus_shadow_applicability.png',
        'terrain/causal_depth_queries_100p5.png': 'results/terrain_recovery_preview_20261128/publication/completed_stage02/causal_depth_queries_100p5.png',
        'terrain/report.json': 'results/terrain_recovery_preview_20261128/audit/stage01/report.json',
        'terrain/decomposition.json': 'results/terrain_recovery_preview_20261128/analysis/decomposition_stage01/report.json',
        'terrain/independent_audit.json': 'results/terrain_recovery_preview_20261128/verification/completed_stage01/report.json',
        'study/CHATGPT_CONTROL_CONTEXT.md': 'docs/CHATGPT_CONTROL_CONTEXT.md',
        'study/TEAMMATE_HANDOFF.md': 'docs/TEAMMATE_HANDOFF.md'
    }
    manifest = {'iterations': ['I-83', 'I-84'], 'scope': 'Presentation artifacts. I83 annotates old recorded physics; I84 is a causal depth/shadow action audit, not a live map-assisted controller trial.', 'files': {}}
    for name, source in files.items():
        p = ROOT / source
        manifest['files'][name] = {'source': source, 'bytes': p.stat().st_size,
                                   'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    OUT.mkdir(parents=True)
    archive = OUT / 'I83-I84-recovery-and-terrain.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name, source in files.items():
            z.write(ROOT / source, name)
        z.writestr('manifest.json', json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.infolist()) == len(files) + 1
        for name, x in manifest['files'].items():
            content = z.read(name)
            assert len(content) == x['bytes'] and hashlib.sha256(content).hexdigest() == x['sha256']
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    report = {'archive': str(archive.relative_to(ROOT)), 'bytes': archive.stat().st_size,
              'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
              'members': len(files) + 1, 'all_members_crc_sha_verified': True}
    (OUT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
