"""Pure presentation contracts; no recorded video or state arrays are loaded."""
import unittest
import numpy as np
from annotate_recovery import source_indices, recorded_status, lookup


class AnnotationContracts(unittest.TestCase):
    def test_exact_original_clip_grid_and_endpoint_count(self):
        x = source_indices()
        self.assertEqual(len(x), 326)
        np.testing.assert_array_equal(x, np.arange(1005, 1331))
        with self.assertRaises(ValueError): source_indices(100.55, 133.)

    def test_censoring_and_no_departure_are_not_zero_time_recovery(self):
        a = dict(primary=dict(status='no_qualifying_departure', entry_s=None))
        b = dict(primary=dict(status='right_censored', entry_s=None))
        self.assertIn('N/A', recorded_status(a))
        self.assertIn('right-censored', recorded_status(b))
        c = dict(primary=dict(status='sustained_recovery', entry_s=103., confirmation_s=105.))
        self.assertIn('103.000 to 105.000', recorded_status(c))

    def test_clock_lookup_rejects_missing_analysis_state(self):
        self.assertEqual(lookup(np.array([100.5, 100.505, 100.51]), 100.505), 1)
        with self.assertRaises(ValueError): lookup(np.array([100.5, 100.51]), 100.505)


if __name__ == '__main__': unittest.main(verbosity=2)
