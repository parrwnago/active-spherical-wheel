"""I-83 pure recovery scoring of saved I-82 state histories.

No controller, simulator, terrain query or outcome-dependent parameter choice.
Analytic eight geometry follows the frozen I-76 metrics source; this module
does not import it. All assessment thresholds come from the registered JSON.
"""
import numpy as np


def stats(values):
    a = np.asarray(values, float)
    finite = np.isfinite(a)
    if not len(a) or not finite.all():
        return dict(count=len(a), finite_count=int(finite.sum()), complete=False,
                    mean=None, rms=None, p95=None, maximum=None)
    return dict(count=len(a), finite_count=len(a), complete=True,
                mean=float(np.mean(a)), rms=float(np.sqrt(np.mean(a*a))),
                p95=float(np.percentile(a, 95)), maximum=float(np.max(a)))


def rotation(quat):
    q = np.asarray(quat, float)
    n = np.linalg.norm(q, axis=1)
    q = np.divide(q, n[:, None], out=np.full_like(q, np.nan), where=n[:, None] > 1e-12)
    w, x, y, z = q.T
    return np.stack([1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w),
        2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w),
        2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)], axis=1).reshape(-1, 3, 3)


def progress(r):
    r = np.clip(np.asarray(r, float), 0., 1.)
    return 10*r**3-15*r**4+6*r**5


def inverse_progress(u):
    u = np.clip(np.asarray(u, float), 0., 1.)
    low, high = np.zeros_like(u), np.ones_like(u)
    for _ in range(60):
        mid = (low+high)/2.
        below = progress(mid) < u
        low = np.where(below, mid, low)
        high = np.where(below, high, mid)
    return np.where(u <= 0., 0., np.where(u >= 1., 1., (low+high)/2.))


def shape(u):
    u = np.asarray(u, float)
    return np.column_stack((.5*np.sin(2*np.pi*u), .25*np.sin(4*np.pi*u)))


def shape_derivative(u):
    u = np.asarray(u, float)
    return np.column_stack((np.pi*np.cos(2*np.pi*u), np.pi*np.cos(4*np.pi*u)))


def route_rotation(route):
    angle = np.radians(route['rotation_deg'])
    return np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])


def path_geometry(route):
    u = np.linspace(0., 1., route['full_polyline_vertices'])
    R = route_rotation(route)
    origin = np.asarray(route['anchor_origin_m'])+R@np.asarray(route['local_offset_m'])
    xy = shape(u)@R.T+origin
    arclength = np.r_[0., np.cumsum(np.linalg.norm(np.diff(xy, axis=0), axis=1))]
    lo, hi = route['intended_u_interval']
    keep = (u >= lo-1e-15) & (u <= hi+1e-15)
    return dict(u=u, xy=xy, arclength=arclength, branch_u=u[keep], branch_xy=xy[keep])


def project_segments(xy, path_xy, path_u, chunk=128):
    """Finite-segment nearest point; first segment gives smallest-u exact tie."""
    xy, path_xy, path_u = map(lambda a: np.asarray(a, float), (xy, path_xy, path_u))
    a, delta = path_xy[:-1], np.diff(path_xy, axis=0)
    denominator = np.sum(delta*delta, axis=1)
    if len(a) < 1 or np.any(denominator <= 0.):
        raise ValueError('Projection needs nondegenerate ordered path segments')
    out = {k: [] for k in ('distance_m', 'u', 'point_xy', 'segment_index', 'segment_fraction')}
    for start in range(0, len(xy), chunk):
        p = xy[start:start+chunk]
        relative = p[:, None, :]-a[None, :, :]
        fraction = np.clip(np.sum(relative*delta[None, :, :], axis=2)/denominator, 0., 1.)
        error = relative-fraction[:, :, None]*delta[None, :, :]
        distance2 = np.sum(error*error, axis=2)
        segment = np.argmin(distance2, axis=1)
        row = np.arange(len(p)); f = fraction[row, segment]
        out['distance_m'].append(np.sqrt(distance2[row, segment]))
        out['u'].append(path_u[segment]+f*(path_u[segment+1]-path_u[segment]))
        out['point_xy'].append(a[segment]+f[:, None]*delta[segment])
        out['segment_index'].append(segment)
        out['segment_fraction'].append(f)
    return {k: np.concatenate(v, axis=0) for k, v in out.items()}


def spatial_velocity(u, route):
    r = inverse_progress(u)
    rate = 30*r*r*(1.-r)*(1.-r)/route['moving_duration_s']
    derivative = shape_derivative(u)@route_rotation(route).T
    return derivative*rate[:, None], derivative/np.linalg.norm(derivative, axis=1)[:, None]


def runs(t, values, wanted=True, dt=.005, tolerance=1e-12):
    """Runs use sampled-state span; a missing clock step breaks a run."""
    t, values = np.asarray(t, float), np.asarray(values, bool)
    result = []; start = None
    for i in range(len(t)):
        match = bool(values[i]) == wanted
        gap = i > 0 and abs(t[i]-t[i-1]-dt) > max(tolerance, 1e-9)
        if start is not None and (not match or gap):
            end = i-1
            result.append(dict(start_index=start, end_index=end,
                start_s=float(t[start]), end_s=float(t[end]), span_s=float(t[end]-t[start]),
                samples=end-start+1))
            start = None
        if match and start is None:
            start = i
    if start is not None:
        end = len(t)-1
        result.append(dict(start_index=start, end_index=end, start_s=float(t[start]),
            end_s=float(t[end]), span_s=float(t[end]-t[start]), samples=end-start+1))
    return result


def recovery(t, good, definitions):
    t, good = np.asarray(t, float), np.asarray(good, bool)
    anchor, end = definitions['event_anchor_s'], definitions['recording_end_s']
    tol = definitions['thresholds']['comparison_tolerance']
    clock_tol = definitions['thresholds']['clock_grid_tolerance_s']
    dt = definitions['control_dt_s']
    mask = (t >= anchor-clock_tol) & (t <= end+clock_tol)
    t, good = t[mask], good[mask]
    if not len(t) or abs(t[0]-anchor) > clock_tol or abs(t[-1]-end) > clock_tol:
        raise ValueError('Recovery requires complete anchor-to-end state coverage')
    if np.any(abs(np.diff(t)-dt) > clock_tol):
        raise ValueError('Recovery clock must contain every registered state')
    true_runs = runs(t, good, True, dt, clock_tol)
    bad_runs = runs(t, good, False, dt, clock_tol)
    exit_dwell = definitions['thresholds']['qualifying_exit_s']
    exit_intervals = int(round(exit_dwell/dt))
    qualified_bad = [r for r in bad_runs if r['samples'] >= exit_intervals+1]
    outside = not bool(good[0])
    if outside:
        departure = bad_runs[0]
        classification = 'left_censored_onset'
    else:
        departure = next((r for r in qualified_bad
            if r['start_s'] <= definitions['departure_search_end_s']+clock_tol), None)
        classification = 'observed_qualifying_departure' if departure else 'no_qualifying_departure'
    search_start = None if departure is None else departure['start_s']
    eligible_good = [] if departure is None else [r for r in true_runs if r['start_index'] >= departure['start_index']]
    first_threshold = eligible_good[0]['start_s'] if eligible_good else None

    def sustained(dwell):
        dwell_intervals = int(round(dwell/dt))
        row = next((r for r in eligible_good if r['samples'] >= dwell_intervals+1), None)
        found = row is not None
        confirmation = None
        confirmation_index = None
        if found:
            confirmation_index = row['start_index']+dwell_intervals
            confirmation = float(t[confirmation_index])
        later_bad = [] if not found else [r for r in bad_runs if r['start_index'] > confirmation_index]
        later_qualifying = [r for r in later_bad if r['samples'] >= exit_intervals+1]
        remaining = None if not found else float(np.mean(good[confirmation_index:]))
        terminal_run = true_runs[-1] if true_runs and true_runs[-1]['end_index'] == len(t)-1 else None
        censor_reason = None
        if departure is not None and not found:
            censor_reason = ('no_threshold_entry' if first_threshold is None else
                ('insufficient_terminal_tail' if terminal_run and terminal_run['samples'] < dwell_intervals+1
                 else 'no_sustained_good_run'))
        return dict(dwell_s=dwell, status=('no_qualifying_departure' if departure is None else
            ('sustained_recovery' if found else 'right_censored')),
            entry_s=None if not found else row['start_s'], confirmation_s=confirmation,
            elapsed_entry_from_anchor_s=None if not found else row['start_s']-anchor,
            elapsed_confirmation_from_anchor_s=None if not found else confirmation-anchor,
            elapsed_entry_from_observed_departure_s=None if not found or outside else row['start_s']-search_start,
            onset_left_censored=outside, right_censored=bool(departure is not None and not found),
            right_censoring_reason=censor_reason,
            first_later_bad_state_s=None if not later_bad else later_bad[0]['start_s'],
            first_later_qualifying_exit_s=None if not later_qualifying else later_qualifying[0]['start_s'],
            later_qualifying_exit_count=len(later_qualifying),
            later_short_bad_run_count=sum(r['samples'] < exit_intervals+1 for r in later_bad),
            later_bad_runs=later_bad, remaining_good_sample_fraction=remaining)

    tail = true_runs[-1] if true_runs and true_runs[-1]['end_index'] == len(t)-1 else None
    return dict(classification=classification, outside_at_anchor=outside,
        departure_start_s=None if departure is None else departure['start_s'],
        departure_confirmation_s=(None if departure is None or outside else
            float(t[departure['start_index']+exit_intervals])),
        first_threshold_entry_s=first_threshold,
        first_threshold_entry_elapsed_from_anchor_s=None if first_threshold is None else first_threshold-anchor,
        first_good_state_from_anchor_s=None if not true_runs else true_runs[0]['start_s'],
        primary=sustained(definitions['thresholds']['primary_dwell_s']),
        secondary=sustained(definitions['thresholds']['secondary_dwell_s']),
        final_good_state=bool(good[-1]),
        last_good_tail=dict(start_s=None if tail is None else tail['start_s'],
            span_s=0. if tail is None else tail['span_s'],
            samples=0 if tail is None else tail['samples'],
            sustained_through_end=bool(tail and tail['samples'] >= int(round(definitions['thresholds']['primary_dwell_s']/dt))+1)),
        postanchor_good_sample_fraction=float(np.mean(good)),
        postanchor_bad_runs=bad_runs,
        short_bad_runs_preserved=True, duration_convention='t[last_state]-t[first_state]')


def signals(raw, definitions):
    t, q, v = raw['time_s'], raw['exact_qpos'], raw['exact_qvel']
    geometry = path_geometry(definitions['route'])
    branch = project_segments(q[:, :2], geometry['branch_xy'], geometry['branch_u'])
    global_projection = project_segments(q[:, :2], geometry['xy'], geometry['u'])
    spatial_v, tangent = spatial_velocity(branch['u'], definitions['route'])
    spatial_error = v[:, :2]-spatial_v
    normal = np.column_stack((-tangent[:, 1], tangent[:, 0]))
    R = rotation(q[:, 3:7]); Rref = rotation(raw['exact_reference_quat'])
    up, upref = R[:, :, 2], Rref[:, :, 2]
    omega = np.einsum('nij,nj->ni', R, v[:, 3:6])
    clock_r = np.clip((t-definitions['route']['start_s'])/definitions['route']['moving_duration_s'], 0., 1.)
    clock_u = progress(clock_r)
    projected_s = np.interp(branch['u'], geometry['u'], geometry['arclength'])
    clock_s = np.interp(clock_u, geometry['u'], geometry['arclength'])
    result = dict(time_s=t, xy=q[:, :2], actual_velocity_xy_m_s=v[:, :2],
        intended_distance_m=branch['distance_m'], global_distance_m=global_projection['distance_m'],
        projected_u=branch['u'], global_projected_u=global_projection['u'],
        projected_point_xy=branch['point_xy'], projected_segment_index=branch['segment_index'],
        projected_segment_fraction=branch['segment_fraction'],
        lower_branch_clamp=branch['u'] <= definitions['route']['intended_u_interval'][0]+1e-12,
        upper_branch_clamp=branch['u'] >= definitions['route']['intended_u_interval'][1]-1e-12,
        projected_arclength_m=projected_s, clock_u=clock_u, clock_arclength_m=clock_s,
        progress_lag_m=clock_s-projected_s, spatial_nominal_velocity_m_s=spatial_v,
        spatial_nominal_speed_m_s=np.linalg.norm(spatial_v, axis=1),
        spatial_velocity_error_m_s=np.linalg.norm(spatial_error, axis=1),
        along_velocity_m_s=np.sum(v[:, :2]*tangent, axis=1),
        along_velocity_error_m_s=np.sum(spatial_error*tangent, axis=1),
        cross_velocity_error_m_s=np.sum(spatial_error*normal, axis=1),
        forward_motion=np.sum(v[:, :2]*tangent, axis=1) >= 0.,
        timed_position_error_m=np.linalg.norm(q[:, :2]-raw['exact_reference_xy'], axis=1),
        timed_velocity_error_m_s=np.linalg.norm(v[:, :2]-raw['exact_reference_velocity_m_s'], axis=1),
        own_up_error_deg=np.degrees(np.arccos(np.clip(np.sum(up*upref, axis=1), -1., 1.))),
        absolute_tilt_deg=np.degrees(np.arccos(np.clip(up[:, 2], -1., 1.))),
        world_z_rate_rad_s=omega[:, 2], xy_speed_m_s=np.linalg.norm(v[:, :2], axis=1))
    return result


def criteria(signals, definitions):
    s, b = signals, definitions['thresholds']; tol = b['comparison_tolerance']
    geometric = s['intended_distance_m'] <= b['path_distance_m']+tol
    attitude = ((s['own_up_error_deg'] <= b['own_reference_up_error_deg']+tol)
        & (s['absolute_tilt_deg'] <= b['absolute_body_tilt_guard_deg']+tol))
    spin = abs(s['world_z_rate_rad_s']) <= b['absolute_world_z_rate_rad_s']+tol
    path = geometric & attitude & (s['spatial_velocity_error_m_s'] <= b['velocity_error_m_s']+tol)
    timed = attitude & (s['timed_position_error_m'] <= b['timed_position_m']+tol) & (
        s['timed_velocity_error_m_s'] <= b['velocity_error_m_s']+tol)
    return dict(geometric=geometric, path_motion=path, path_full=path & spin,
                timed_motion=timed, timed_full=timed & spin)
