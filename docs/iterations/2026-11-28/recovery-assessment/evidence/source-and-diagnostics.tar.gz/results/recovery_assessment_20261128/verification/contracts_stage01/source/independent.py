"""Independent recovery arithmetic; no controller, simulator or scoring imports."""
from __future__ import annotations
import numpy as np


def curve(u):
    u = np.asarray(u, dtype=float)
    a = np.deg2rad(113.)
    rot = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    local = np.column_stack((.5*np.sin(2*np.pi*u), .25*np.sin(4*np.pi*u)))
    origin = np.array([-2.4, 10.])+rot@np.array([.5, 0.])
    return local@rot.T+origin


def project_section(xy, global_path=False):
    """Exact segment projection, original 4097-grid last quarter, first tie."""
    xy = np.asarray(xy, dtype=float)
    if xy.ndim != 2 or xy.shape[1] != 2 or not np.isfinite(xy).all():
        raise ValueError('Finite XY rows required')
    first = 0 if global_path else 3072
    u = np.arange(first, 4097, dtype=float)/4096.
    nodes = curve(u); start = nodes[:-1]; segment = np.diff(nodes, axis=0)
    denominator = np.einsum('ij,ij->i', segment, segment)
    dist = np.empty(len(xy)); selected_u = np.empty(len(xy)); point = np.empty_like(xy)
    segment_index = np.empty(len(xy), dtype=np.int64)
    fraction = np.empty(len(xy))
    for i in range(0, len(xy), 64):
        delta = xy[i:i+64, None, :]-start[None, :, :]
        f = np.clip(np.einsum('nsi,si->ns', delta, segment)/denominator, 0., 1.)
        residual = delta-f[:, :, None]*segment
        squared = np.einsum('nsi,nsi->ns', residual, residual)
        k = squared.argmin(axis=1)
        j = np.arange(len(k)); selected_f = f[j, k]
        sl = slice(i, i+len(k))
        dist[sl] = np.sqrt(squared[j, k]); segment_index[sl] = k+first
        fraction[sl] = selected_f; selected_u[sl] = (k+first+selected_f)/4096.
        point[sl] = start[k]+selected_f[:, None]*segment[k]
    return dict(distance_m=dist, projected_u=selected_u, projected_xy_m=point,
                global_segment_index=segment_index, segment_fraction=fraction,
                lower_endpoint=selected_u <= .75+1e-12, upper_endpoint=selected_u >= 1.-1e-12)


def inverse_progress(u, iterations=60):
    """Invert fixed monotonic quintic progress, without any recorded motion."""
    u = np.asarray(u, dtype=float)
    if not np.isfinite(u).all() or np.any((u < 0.) | (u > 1.)):
        raise ValueError('Progress must be finite in [0, 1]')
    lo = np.zeros_like(u); hi = np.ones_like(u)
    for _ in range(iterations):
        r = (lo+hi)/2.
        value = r*r*r*(10.+r*(-15.+6.*r))
        low = value < u
        lo = np.where(low, r, lo); hi = np.where(low, hi, r)
    return np.where(u == 0., 0., np.where(u == 1., 1., (lo+hi)/2.))


def spatial_reference(u):
    u = np.asarray(u, dtype=float)
    r = inverse_progress(u)
    a = np.deg2rad(113.)
    rot = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    derivative = np.column_stack((np.pi*np.cos(2*np.pi*u), np.pi*np.cos(4*np.pi*u)))@rot.T
    tangent = derivative/np.linalg.norm(derivative, axis=1)[:, None]
    progress_rate = (30.*r*r*(1.-r)*(1.-r))/120.
    return dict(nominal_time_s=3.+120.*r, tangent_xy=tangent,
                velocity_m_s=derivative*progress_rate[:, None])


def attitude(q, reference_quat, body_rate):
    def axes(quat):
        quat = np.asarray(quat, dtype=float)
        norm = np.sqrt(np.sum(quat*quat, axis=1))
        if np.any(norm <= 0.) or not np.isfinite(quat).all():
            raise ValueError('Finite nonzero quaternion rows required')
        w, x, y, z = (quat/norm[:, None]).T
        up = np.column_stack((2.*(x*z+w*y), 2.*(y*z-w*x), 1.-2.*(x*x+y*y)))
        z_in_body = np.column_stack((2.*(x*z-w*y), 2.*(y*z+w*x), 1.-2.*(x*x+y*y)))
        return up, z_in_body
    up, z_in_body = axes(q); reference_up, _ = axes(reference_quat)
    return dict(absolute_tilt_deg=np.rad2deg(np.arccos(np.clip(up[:, 2], -1., 1.))),
                own_up_error_deg=np.rad2deg(np.arccos(np.clip(np.sum(up*reference_up, axis=1), -1., 1.))),
                world_z_rate_rad_s=np.sum(z_in_body*np.asarray(body_rate), axis=1))


def raw_signals(raw, definitions):
    """Reconstruct every public geometric/motion signal from raw robot states."""
    t, q, v = raw['time_s'], raw['exact_qpos'], raw['exact_qvel']
    branch = project_section(q[:, :2]); whole = project_section(q[:, :2], global_path=True)
    reference = spatial_reference(branch['projected_u'])
    velocity_error = v[:, :2]-reference['velocity_m_s']
    tangent = reference['tangent_xy']; left = np.column_stack((-tangent[:, 1], tangent[:, 0]))
    full_u = np.arange(4097)/4096.; nodes = curve(full_u)
    arc = np.r_[0., np.cumsum(np.hypot(np.diff(nodes[:, 0]), np.diff(nodes[:, 1])))]
    r = np.clip((t-3.)/120., 0., 1.)
    clock_u = 10*r**3-15*r**4+6*r**5
    projected_arc = np.interp(branch['projected_u'], full_u, arc)
    clock_arc = np.interp(clock_u, full_u, arc)
    a = attitude(q[:, 3:7], raw['exact_reference_quat'], v[:, 3:6])
    return dict(time_s=t, xy=q[:, :2], actual_velocity_xy_m_s=v[:, :2],
        intended_distance_m=branch['distance_m'], global_distance_m=whole['distance_m'],
        projected_u=branch['projected_u'], global_projected_u=whole['projected_u'],
        projected_point_xy=branch['projected_xy_m'], projected_segment_index=branch['global_segment_index']-3072,
        projected_segment_fraction=branch['segment_fraction'], lower_branch_clamp=branch['lower_endpoint'],
        upper_branch_clamp=branch['upper_endpoint'], projected_arclength_m=projected_arc,
        clock_u=clock_u, clock_arclength_m=clock_arc, progress_lag_m=clock_arc-projected_arc,
        spatial_nominal_velocity_m_s=reference['velocity_m_s'], spatial_nominal_speed_m_s=np.hypot(*reference['velocity_m_s'].T),
        spatial_velocity_error_m_s=np.hypot(*velocity_error.T), along_velocity_m_s=np.sum(v[:, :2]*tangent, axis=1),
        along_velocity_error_m_s=np.sum(velocity_error*tangent, axis=1), cross_velocity_error_m_s=np.sum(velocity_error*left, axis=1),
        forward_motion=np.sum(v[:, :2]*tangent, axis=1) >= 0.,
        timed_position_error_m=np.hypot(*(q[:, :2]-raw['exact_reference_xy']).T),
        timed_velocity_error_m_s=np.hypot(*(v[:, :2]-raw['exact_reference_velocity_m_s']).T),
        xy_speed_m_s=np.hypot(v[:, 0], v[:, 1]), **a)


def predicates(s, definitions):
    b = definitions['thresholds']; e = b['comparison_tolerance']
    path = s['intended_distance_m'] <= b['path_distance_m']+e
    attitude_good = (s['own_up_error_deg'] <= b['own_reference_up_error_deg']+e) & (s['absolute_tilt_deg'] <= b['absolute_body_tilt_guard_deg']+e)
    spin = abs(s['world_z_rate_rad_s']) <= b['absolute_world_z_rate_rad_s']+e
    path_motion = path & attitude_good & (s['spatial_velocity_error_m_s'] <= b['velocity_error_m_s']+e)
    timed = (s['timed_position_error_m'] <= b['timed_position_m']+e) & (s['timed_velocity_error_m_s'] <= b['velocity_error_m_s']+e) & attitude_good
    return dict(geometric=path, path_motion=path_motion, path_full=path_motion & spin,
                timed_motion=timed, timed_full=timed & spin)


def contiguous_runs(mask):
    mask = np.asarray(mask, dtype=bool)
    if mask.ndim != 1: raise ValueError('One-dimensional predicate required')
    changes = np.diff(np.r_[False, mask, False].astype(np.int8))
    return list(zip(np.flatnonzero(changes == 1).tolist(), (np.flatnonzero(changes == -1)-1).tolist()))


def sampled_runs(t, mask):
    """Inclusive sample endpoints; span, not next unobserved-state interval."""
    t = np.asarray(t, dtype=float)
    if t.ndim != 1 or len(t) != len(mask) or np.any(np.diff(t) <= 0.) or not np.isfinite(t).all():
        raise ValueError('Finite strictly increasing matching sample times required')
    return [dict(start_index=a, end_index=b, start_s=float(t[a]), end_s=float(t[b]),
                 span_s=float(t[b]-t[a]), samples=b-a+1) for a, b in contiguous_runs(mask)]


def episodes(t, good, *, anchor_s=100.5, horizon_s=133., dwell_s=2., exit_s=.1, departure_search_end_s=104.):
    """Sampled recovery ledger; no fixed event onset is inferred from the data.

    This helper is tested before outcomes. Final CLI adapts its report keys to
    the separately frozen public definitions without importing canonical code.
    """
    t = np.asarray(t, dtype=float); good = np.asarray(good, dtype=bool)
    selected = (t >= anchor_s-1e-9) & (t <= horizon_s+1e-9)
    times = t[selected]; valid = good[selected]
    if not len(times): raise ValueError('No assessment samples')
    runs = sampled_runs(times, valid); bad = sampled_runs(times, ~valid)
    qualifying_bad = [x for x in bad if x['span_s'] >= exit_s-1e-9]
    good_long = [x for x in runs if x['span_s'] >= dwell_s-1e-9]
    inside_anchor = bool(valid[0])
    first_departure = next((x for x in qualifying_bad if x['start_s'] <= departure_search_end_s+1e-9), None)
    event = not inside_anchor or first_departure is not None
    origin = anchor_s if not inside_anchor else first_departure['start_s'] if first_departure else None
    if event:
        eligible_good = valid & (times >= origin-1e-9)
        first_entry = float(times[np.flatnonzero(eligible_good)[0]]) if eligible_good.any() else None
        first = next((x for x in good_long if x['start_s'] >= origin-1e-9), None)
    else:
        first_entry = first = None
    confirmation = None
    if first:
        eligible = np.flatnonzero((times >= first['start_s']+dwell_s-1e-9) & (times <= first['end_s']+1e-9))
        confirmation = float(times[eligible[0]])
    tail_good = runs[-1] if runs and runs[-1]['end_index'] == len(times)-1 else None
    full_horizon = abs(times[-1]-horizon_s) <= 1e-9
    terminal_sustained = bool(full_horizon and tail_good and tail_good['span_s'] >= dwell_s-1e-9)
    after = [] if first is None else [x for x in qualifying_bad if x['start_s'] > confirmation+1e-9]
    remaining = None if confirmation is None else float(np.mean(valid[times >= confirmation-1e-9]))
    return dict(anchor_s=anchor_s, horizon_s=horizon_s, observed_end_s=float(times[-1]),
        complete_horizon=bool(full_horizon), anchor_good=bool(valid[0]), anchor_outside_left_censored=bool(not valid[0]),
        classification='outside_at_anchor_left_censored' if not inside_anchor else 'qualifying_departure' if event else 'no_qualifying_departure',
        departure_start_s=origin,
        departure_confirmation_s=None if not inside_anchor or first_departure is None else next(float(x) for x in times if x >= first_departure['start_s']+exit_s-1e-9),
        first_entry_s=first_entry, first_entry_elapsed_s=None if first_entry is None else first_entry-anchor_s,
        dwell_s=dwell_s, exit_s=exit_s, first_sustained_entry_s=None if first is None else first['start_s'],
        first_sustained_confirmation_s=confirmation,
        first_sustained_elapsed_s=None if first is None else first['start_s']-anchor_s,
        qualifying_exit_runs=qualifying_bad, sampled_bad_runs=bad, sampled_good_runs=runs,
        qualifying_reexit_count_after_first_dwell=len(after),
        first_qualifying_reexit_start_s=after[0]['start_s'] if after else None,
        remaining_good_fraction_after_confirmation=remaining,
        terminal_persistent_sustained=terminal_sustained,
        terminal_persistent_entry_s=tail_good['start_s'] if terminal_sustained else None,
        right_censored_insufficient_dwell=bool(not first and tail_good and tail_good['span_s'] < dwell_s-1e-9),
        right_censored=bool(event and first is None), no_sustained_recovery=bool(event and first is None))


def recovery_ledger(t, good, definitions):
    """Public-schema recovery ledger independently assembled from Boolean runs."""
    anchor = definitions['event_anchor_s']; end = definitions['recording_end_s']
    clock_tolerance = definitions['thresholds']['clock_grid_tolerance_s']
    value_tolerance = definitions['thresholds']['comparison_tolerance']
    t = np.asarray(t, float); good = np.asarray(good, bool)
    keep = (t >= anchor-clock_tolerance) & (t <= end+clock_tolerance)
    times, valid = t[keep], good[keep]
    if not len(times) or abs(times[0]-anchor) > clock_tolerance or abs(times[-1]-end) > clock_tolerance or np.any(abs(np.diff(times)-definitions['control_dt_s']) > clock_tolerance):
        raise ValueError('Complete registered assessment clock required')
    args = dict(anchor_s=anchor, horizon_s=end, exit_s=definitions['thresholds']['qualifying_exit_s'], departure_search_end_s=definitions['departure_search_end_s'])
    first = episodes(times, valid, dwell_s=definitions['thresholds']['primary_dwell_s'], **args)
    second = episodes(times, valid, dwell_s=definitions['thresholds']['secondary_dwell_s'], **args)
    found_event = first['classification'] != 'no_qualifying_departure'
    outside = first['anchor_outside_left_censored']
    def dwell_row(result):
        entry = result['first_sustained_entry_s']; confirmation = result['first_sustained_confirmation_s']
        after = [] if confirmation is None else [r for r in result['sampled_bad_runs'] if r['start_s'] > confirmation+value_tolerance]
        qualified = [r for r in after if r['span_s'] >= result['exit_s']-clock_tolerance]
        censor_reason = None
        if found_event and entry is None:
            censor_reason = 'no_threshold_entry' if result['first_entry_s'] is None else 'insufficient_terminal_tail' if result['right_censored_insufficient_dwell'] else 'no_sustained_good_run'
        return dict(dwell_s=result['dwell_s'], status='no_qualifying_departure' if not found_event else 'right_censored' if entry is None else 'sustained_recovery',
            entry_s=entry, confirmation_s=confirmation, elapsed_entry_from_anchor_s=None if entry is None else entry-anchor,
            elapsed_confirmation_from_anchor_s=None if confirmation is None else confirmation-anchor,
            elapsed_entry_from_observed_departure_s=None if entry is None or outside else entry-first['departure_start_s'],
            onset_left_censored=outside, right_censored=result['right_censored'],
            right_censoring_reason=censor_reason,
            first_later_bad_state_s=after[0]['start_s'] if after else None,
            first_later_qualifying_exit_s=qualified[0]['start_s'] if qualified else None,
            later_qualifying_exit_count=len(qualified), later_short_bad_run_count=len(after)-len(qualified),
            later_bad_runs=after, remaining_good_sample_fraction=result['remaining_good_fraction_after_confirmation'])
    tail = first['sampled_good_runs'][-1] if first['sampled_good_runs'] and first['sampled_good_runs'][-1]['end_index'] == len(times)-1 else None
    return dict(classification='left_censored_onset' if outside else 'observed_qualifying_departure' if found_event else 'no_qualifying_departure',
        outside_at_anchor=outside, departure_start_s=first['departure_start_s'], departure_confirmation_s=first['departure_confirmation_s'],
        first_threshold_entry_s=first['first_entry_s'], first_threshold_entry_elapsed_from_anchor_s=first['first_entry_elapsed_s'],
        first_good_state_from_anchor_s=first['sampled_good_runs'][0]['start_s'] if first['sampled_good_runs'] else None,
        primary=dwell_row(first), secondary=dwell_row(second), final_good_state=bool(valid[-1]),
        last_good_tail=dict(start_s=tail['start_s'] if tail else None, span_s=tail['span_s'] if tail else 0., samples=tail['samples'] if tail else 0,
            sustained_through_end=bool(tail and tail['span_s'] >= definitions['thresholds']['primary_dwell_s']-clock_tolerance)),
        postanchor_good_sample_fraction=float(np.mean(valid)), postanchor_bad_runs=first['sampled_bad_runs'],
        short_bad_runs_preserved=True, duration_convention='t[last_state]-t[first_state]')
