"""Independent recovery arithmetic; no controller, simulator or scoring imports."""
from __future__ import annotations
import numpy as np


def curve(u):
    u = np.asarray(u, dtype=float)
    a = np.deg2rad(113.)
    rot = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    local = np.column_stack((.5*np.sin(2*np.pi*u), .25*np.sin(4*np.pi*u)))
    return (local+np.array([.5, 0.]))@rot.T+np.array([-2.4, 10.])


def project_section(xy):
    """Exact segment projection, original 4097-grid last quarter, first tie."""
    xy = np.asarray(xy, dtype=float)
    if xy.ndim != 2 or xy.shape[1] != 2 or not np.isfinite(xy).all():
        raise ValueError('Finite XY rows required')
    u = np.arange(3072, 4097, dtype=float)/4096.
    nodes = curve(u); start = nodes[:-1]; segment = np.diff(nodes, axis=0)
    denominator = np.einsum('ij,ij->i', segment, segment)
    dist = np.empty(len(xy)); selected_u = np.empty(len(xy)); point = np.empty_like(xy)
    segment_index = np.empty(len(xy), dtype=np.int64)
    fraction = np.empty(len(xy))
    for i in range(0, len(xy), 64):
        delta = xy[i:i+64, None, :]-start[None, :, :]
        f = np.clip(np.einsum('nsi,si->ns', delta, segment)/denominator, 0., 1.)
        residual = delta-f[:, :, None]*segment
        squared = np.einsum('nsi,nsi->ns', residual, residual)
        k = squared.argmin(axis=1)
        j = np.arange(len(k)); selected_f = f[j, k]
        sl = slice(i, i+len(k))
        dist[sl] = np.sqrt(squared[j, k]); segment_index[sl] = k+3072
        fraction[sl] = selected_f; selected_u[sl] = (k+3072+selected_f)/4096.
        point[sl] = start[k]+selected_f[:, None]*segment[k]
    return dict(distance_m=dist, projected_u=selected_u, projected_xy_m=point,
                global_segment_index=segment_index, segment_fraction=fraction,
                lower_endpoint=selected_u <= .75+1e-12, upper_endpoint=selected_u >= 1.-1e-12)


def inverse_progress(u, iterations=64):
    """Invert fixed monotonic quintic progress, without any recorded motion."""
    u = np.asarray(u, dtype=float)
    if not np.isfinite(u).all() or np.any((u < 0.) | (u > 1.)):
        raise ValueError('Progress must be finite in [0, 1]')
    lo = np.zeros_like(u); hi = np.ones_like(u)
    for _ in range(iterations):
        r = (lo+hi)/2.
        value = r*r*r*(10.+r*(-15.+6.*r))
        low = value < u
        lo = np.where(low, r, lo); hi = np.where(low, hi, r)
    return np.where(u == 0., 0., np.where(u == 1., 1., (lo+hi)/2.))


def spatial_reference(u):
    u = np.asarray(u, dtype=float)
    r = inverse_progress(u)
    a = np.deg2rad(113.)
    rot = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    derivative = np.column_stack((np.pi*np.cos(2*np.pi*u), np.pi*np.cos(4*np.pi*u)))@rot.T
    tangent = derivative/np.linalg.norm(derivative, axis=1)[:, None]
    progress_rate = (30.*r*r*(1.-r)*(1.-r))/120.
    return dict(nominal_time_s=3.+120.*r, tangent_xy=tangent,
                velocity_m_s=derivative*progress_rate[:, None])


def attitude(q, reference_quat, body_rate):
    def axes(quat):
        quat = np.asarray(quat, dtype=float)
        norm = np.sqrt(np.sum(quat*quat, axis=1))
        if np.any(norm <= 0.) or not np.isfinite(quat).all():
            raise ValueError('Finite nonzero quaternion rows required')
        w, x, y, z = (quat/norm[:, None]).T
        up = np.column_stack((2.*(x*z+w*y), 2.*(y*z-w*x), 1.-2.*(x*x+y*y)))
        z_in_body = np.column_stack((2.*(x*z-w*y), 2.*(y*z+w*x), 1.-2.*(x*x+y*y)))
        return up, z_in_body
    up, z_in_body = axes(q); reference_up, _ = axes(reference_quat)
    return dict(absolute_tilt_deg=np.rad2deg(np.arccos(np.clip(up[:, 2], -1., 1.))),
                own_up_error_deg=np.rad2deg(np.arccos(np.clip(np.sum(up*reference_up, axis=1), -1., 1.))),
                world_z_rate_rad_s=np.sum(z_in_body*np.asarray(body_rate), axis=1))


def contiguous_runs(mask):
    mask = np.asarray(mask, dtype=bool)
    if mask.ndim != 1: raise ValueError('One-dimensional predicate required')
    changes = np.diff(np.r_[False, mask, False].astype(np.int8))
    return list(zip(np.flatnonzero(changes == 1).tolist(), (np.flatnonzero(changes == -1)-1).tolist()))


def sampled_runs(t, mask):
    """Inclusive sample endpoints; span, not next unobserved-state interval."""
    t = np.asarray(t, dtype=float)
    if t.ndim != 1 or len(t) != len(mask) or np.any(np.diff(t) <= 0.) or not np.isfinite(t).all():
        raise ValueError('Finite strictly increasing matching sample times required')
    return [dict(start_index=a, end_index=b, start_s=float(t[a]), end_s=float(t[b]),
                 span_s=float(t[b]-t[a]), samples=b-a+1) for a, b in contiguous_runs(mask)]


def episodes(t, good, *, anchor_s=100.5, horizon_s=133., dwell_s=2., exit_s=.1):
    """Sampled recovery ledger; no fixed event onset is inferred from the data.

    This helper is tested before outcomes. Final CLI adapts its report keys to
    the separately frozen public definitions without importing canonical code.
    """
    t = np.asarray(t, dtype=float); good = np.asarray(good, dtype=bool)
    selected = (t >= anchor_s-1e-9) & (t <= horizon_s+1e-9)
    times = t[selected]; valid = good[selected]
    if not len(times): raise ValueError('No assessment samples')
    runs = sampled_runs(times, valid); bad = sampled_runs(times, ~valid)
    qualifying_bad = [x for x in bad if x['span_s'] >= exit_s-1e-9]
    good_long = [x for x in runs if x['span_s'] >= dwell_s-1e-9]
    first_entry = float(times[np.flatnonzero(valid)[0]]) if valid.any() else None
    first = good_long[0] if good_long else None
    confirmation = None
    if first:
        eligible = np.flatnonzero((times >= first['start_s']+dwell_s-1e-9) & (times <= first['end_s']+1e-9))
        confirmation = float(times[eligible[0]])
    tail_good = runs[-1] if runs and runs[-1]['end_index'] == len(times)-1 else None
    full_horizon = abs(times[-1]-horizon_s) <= 1e-9
    terminal_sustained = bool(full_horizon and tail_good and tail_good['span_s'] >= dwell_s-1e-9)
    after = [] if first is None else [x for x in qualifying_bad if x['start_s'] > confirmation+1e-9]
    return dict(anchor_s=anchor_s, horizon_s=horizon_s, observed_end_s=float(times[-1]),
        complete_horizon=bool(full_horizon), anchor_good=bool(valid[0]), anchor_outside_left_censored=bool(not valid[0]),
        first_entry_s=first_entry, first_entry_elapsed_s=None if first_entry is None else first_entry-anchor_s,
        dwell_s=dwell_s, exit_s=exit_s, first_sustained_entry_s=None if first is None else first['start_s'],
        first_sustained_confirmation_s=confirmation,
        first_sustained_elapsed_s=None if first is None else first['start_s']-anchor_s,
        qualifying_exit_runs=qualifying_bad, sampled_bad_runs=bad, sampled_good_runs=runs,
        qualifying_reexit_count_after_first_dwell=len(after),
        terminal_persistent_sustained=terminal_sustained,
        terminal_persistent_entry_s=tail_good['start_s'] if terminal_sustained else None,
        right_censored_insufficient_dwell=bool(not first and tail_good and tail_good['span_s'] < dwell_s-1e-9),
        no_sustained_recovery=bool(first is None))
