"""Synthetic held-loop/termination contracts, without a physics engine."""
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_loop as loop
from session import GovernorSession

class ToyMirror:
    def __init__(self):self.data=types.SimpleNamespace(time=-1.)
    def follow(self,physical):self.data.time=float(physical.data.time)

class ToyPlant:
    def __init__(self):
        self.dt=.005;self.config={'simulation':{'initial_shaft_phase_rad':.3}}
        self.data=types.SimpleNamespace(time=0.,qpos=np.r_[np.zeros(3),1.,np.zeros(6)],
            qvel=np.zeros(9),xmat=np.eye(3).reshape(1,9))
        self.fork_id=0;self.last_input=np.zeros(5);self.bounds=np.ones(5)
        self.ground=dict(normal=np.array([0.,0.,1.]),point=np.zeros(3),friction=.7)
        self.steps=0
    def snapshot(self):return dict(tilt_rad=0.,balance_failed=False)
    def step(self,applied,disturbance):
        self.steps+=1;self.last_input=np.array(applied);self.data.time+=self.dt

def measurement(plant):
    return dict(force_N=np.array([0.,0.,1.]),normal_force_N=1.,
        tangential_force_norm_N=0.,utilization=0.,slip_speed_m_s=0.,
        loads_N=dict(shell_A=1.,shell_B=0.,belt_A=0.,belt_B=0.),
        fork_load_N=0.,point_m=np.zeros(3),moment_Nm=np.zeros(3))

class ToyController:
    instances=[]
    def __init__(self,plant,design,params,phase,record_diagnostics=False):
        self.plant=plant;self.observer=None;self.carrier_id=0;self.commands=0;self.after=0
        self.instances.append(self)
    def command(self,xy,v,a):
        self.commands+=1
        return np.zeros(5),dict(requested=np.zeros(5),estimate=dict(normal=np.array([0.,0.,1.]),friction=.7),
            reference_quat=np.array([1.,0.,0.,0.]),effective_phase_rad=.3,drive_fade=1.,support_torque=np.zeros(5))
    def after_step(self):self.after+=1

class ToySession:
    requested_horizon_s=.030
    planned_stop_s=.015
    def __init__(self):self.selects=0;self.confirms=0
    def select(self,c,p,path,now):
        if c.plant.data.time!=now:raise AssertionError('Mirror must follow before reference selection')
        self.selects+=1;return path(now)
    def confirm(self,*args):self.confirms+=1
    def should_stop(self,now):return now>=self.planned_stop_s-1e-12

class LoopContracts(unittest.TestCase):
    def test_dynamic_terminal_row_is_logged_but_never_held(self):
        plant=ToyPlant();mirror=ToyMirror();session=ToySession()
        workspace=types.SimpleNamespace(plant=lambda terrain:plant,mirror=lambda:mirror,design=None)
        path=types.SimpleNamespace(origin=np.zeros(2),start_s=0.,duration_s=.020)
        class Path:
            origin=np.zeros(2);start_s=0.;duration_s=.020
            def __call__(self,t):return np.zeros(2),np.zeros(2),np.zeros(2)
        path=Path();requests=[]
        def summary(log,p,path,params,failure,duration):
            requests.append(duration);return dict(completed=failure is None,completed_duration_s=float(log['time_s'][-1]))
        with patch.object(loop,'ACTIVE_SESSION',session),patch.object(loop,'OffroadController',ToyController),\
             patch.object(loop,'place_on_ground',lambda *args:None),patch.object(loop,'summarize',summary),\
             patch.object(loop.experiments,'measure_contact',measurement):
            log,result=loop.run_offroad(workspace,None,path,types.SimpleNamespace(mode='hardware'),duration_s=.030)
        self.assertEqual(plant.steps,3);self.assertEqual(session.selects,4);self.assertEqual(session.confirms,4)
        self.assertEqual(ToyController.instances[-1].commands,4);self.assertEqual(ToyController.instances[-1].after,3)
        np.testing.assert_array_equal(log['time_s'],np.array([0.,.005,.010,.015]))
        self.assertEqual(requests,[.015]);self.assertTrue(result['completed'])
    def test_progress_and_ten_second_reference_hold_are_separate_from_budget(self):
        s=GovernorSession('G',lambda *args:None)
        s.first_complete_sample_s=40.;s.dense_finished_at_s=39.999
        self.assertEqual(s.planned_stop_s,50.);self.assertFalse(s.should_stop(49.995));self.assertTrue(s.should_stop(50.))
        s.rows=[dict(time_s=50.)]
        out=s.outcome(dict(failure=None,completed=True))
        self.assertTrue(out['diagnostic_completed']);self.assertEqual(out['physical_goal_hold_s'],10.)
        s.first_complete_sample_s=70.;s.rows=[dict(time_s=75.)]
        self.assertEqual(s.planned_stop_s,75.)
        out=s.outcome(dict(failure=None,completed=True))
        self.assertTrue(out['reference_complete']);self.assertFalse(out['full_goal_hold_completed']);self.assertFalse(out['diagnostic_completed'])

if __name__=='__main__':unittest.main()
