"""Freeze the one I78 design and all runtime/input bytes before physics."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
OLD = ROOT/'results/tangent_heading_routes_20261127'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--register',action='store_true')
    args=parser.parse_args()
    if not args.register: raise SystemExit('Explicit --register required; no physics is run here')
    destination=HERE/'protocol.json'
    if destination.exists(): raise FileExistsError('Preserve the registered protocol; use an explicit new stage for corrections')
    draft=json.loads((HERE/'draft_protocol.json').read_text())
    old_path=OLD/'protocol/protocol.json'
    if sha(old_path)!=draft['original_protocol_sha256']: raise ValueError('Original I76 protocol differs')
    old=json.loads(old_path.read_text())
    for field in ('source_sha256','input_sha256'):
        for relative,expected in old[field].items():
            if sha(ROOT/relative)!=expected: raise ValueError('Frozen I76 dependency differs: '+relative)
    required=[BASE/'governor/progress_governor.py',BASE/'runner/native_probe.py',
              BASE/'runner/run_loop.py',BASE/'runner/session.py',BASE/'runner/run_case.py',
              BASE/'evaluation/metrics.py',BASE/'evaluation/evaluate.py']
    if not all(p.is_file() for p in required): raise ValueError('Finish all runtime/evaluation producers before registration')
    sources={ROOT/p for p in old['source_sha256']}
    for folder in ('governor','runner','evaluation'):
        sources.update((BASE/folder).glob('*.py'))
    sources.update([Path(__file__).resolve(),ROOT/'src/spherical_wheel/predictive_seed.py'])
    inputs={ROOT/p for p in old['input_sha256']}
    inputs.update([old_path,OLD/'campaign/outputs_sealed.json',ROOT/old['gain_cache']['path'],
                   BASE/'evaluation/protocol_metrics_fragment.json'])
    for tag in ('m100','p030','p090'):
        inputs.update(OLD/'campaign/runs'/f'straight_{tag}_N'/name for name in ('precision.npz','summary.json','provenance.json'))
    bridge=ROOT/'build/gazebo/libSphericalWheelBridge.so'
    physics=ROOT/'build/gazebo/libAswExactPhysics.so'
    if sha(bridge)!=old['bridge_binary_sha256'] or sha(physics)!=old['exact_physics_binary_sha256']:
        raise ValueError('Simulator plugins differ from original I76')
    inputs.update([bridge,physics])
    protocol=dict(draft)
    protocol.update(status='registered_before_physics',
        registered_before_physics_utc=datetime.now(timezone.utc).isoformat(),
        evaluation=json.loads((BASE/'evaluation/protocol_metrics_fragment.json').read_text()),
        exact_physics_binary_sha256=old['exact_physics_binary_sha256'],
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in sorted(sources)},
        input_sha256={str(p.relative_to(ROOT)):sha(p) for p in sorted(inputs)},
        original_output_seal_sha256=sha(OLD/'campaign/outputs_sealed.json'),
        integration=dict(control_interval_s=.005,physics_interval_s=.001,private_dynamic_steps=0,
            private_nominal_command_probes_per_G_row=1,live_observer_updates_per_row=1),
        acceptance_policy='All three phases and one setting; fixed gates, completion and no-progress checks. No automatic default promotion or outcome-driven parameter, target, phase or window changes.')
    for p in sorted(sources):
        target=HERE/'source'/p.relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,target)
    with destination.open('x') as f: json.dump(protocol,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
    receipt=dict(iteration='I-78',protocol_sha256=sha(destination),sources=len(sources),inputs=len(inputs),
                 no_new_physics=True,source_snapshot_semantics='Exact bytes registered before this campaign; prior contract/failure stages are preserved separately.')
    (HERE/'registration_receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps(receipt),flush=True)

if __name__=='__main__': main()
