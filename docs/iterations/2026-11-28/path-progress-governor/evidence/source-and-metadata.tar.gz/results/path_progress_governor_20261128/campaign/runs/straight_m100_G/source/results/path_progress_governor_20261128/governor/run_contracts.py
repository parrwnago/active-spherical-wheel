"""Snapshot and run the ten I78 pure governor contracts, never physics."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,shutil,subprocess,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    sources=[Path(__file__).resolve(),HERE/'progress_governor.py',HERE/'test_progress_governor.py']
    inputs=[ROOT/'results/tangent_heading_routes_20261127/runtime/route.py']
    for p in sources+inputs:
        dst=out/'source'/p.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    bindings={str(p.relative_to(ROOT)):sha(p)for p in sources+inputs}
    write(out/'registered_before_tests.json',dict(iteration='I-78',utc=datetime.now(timezone.utc).isoformat(),
        sources_inputs=bindings,scope='Pureclock/cascade/referencecontracts; zero physics, savedarray arithmetic, robot/contact/model queries.',
        interpreter=sys.executable,command=[sys.executable,'-m','unittest','-v','test_progress_governor']))
    result=subprocess.run([sys.executable,'-m','unittest','-v','test_progress_governor'],cwd=HERE,text=True,capture_output=True)
    (out/'unittest.log').write_text(result.stdout+result.stderr)
    unchanged=all(sha(ROOT/p)==h for p,h in bindings.items())
    write(out/'receipt.json',dict(iteration='I-78',passed=result.returncode==0 and unchanged,returncode=result.returncode,
        source_inputs_unchanged=unchanged,scoped_test_functions=10,new_physics=False,repo_full_suite=False))
    write(out/'artifact_manifest.json',dict(files={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(out.rglob('*'))if p.is_file()}))
    print((out/'unittest.log').read_text());print((out/'receipt.json').read_text())
    raise SystemExit(result.returncode if unchanged else 1)
if __name__=='__main__':main()
