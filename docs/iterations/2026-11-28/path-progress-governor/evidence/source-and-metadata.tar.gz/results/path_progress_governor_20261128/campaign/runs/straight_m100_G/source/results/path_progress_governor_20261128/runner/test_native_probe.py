"""Scoped synthetic history-isolation contracts; no simulator or integration."""
import copy
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import native_probe as mod


class Plant:
    def __init__(self):
        self.data = types.SimpleNamespace(qpos=np.arange(10,dtype=float),
            qvel=np.arange(9,dtype=float)/10,time=1.)
        self.last_input=np.arange(5,dtype=float)/20
        self.bounds=np.array([1.5,.6,.6,.3,.3])
        self.model=types.SimpleNamespace(nv=9)
    def set_state(self,q,v,t,u):
        self.data.qpos=np.array(q,copy=True);self.data.qvel=np.array(v,copy=True)
        self.data.time=float(t);self.last_input=np.array(u,copy=True)

class Observer:
    def __init__(self):
        self.generalized=np.zeros(9);self.interval_mean=np.zeros(9)
        self._previous=(0.,np.eye(9),np.zeros(9))
    def update(self):
        self.generalized+=1.;self.interval_mean+=2.
        self._previous=(1.,np.eye(9),np.ones(9))
    def wrench(self):return self.generalized[:3],self.generalized[3:6]

class Controller:
    def __init__(self):
        self.plant=Plant();self.params=types.SimpleNamespace(tilt_reference=None,heading_gain=0.)
        self.rolling_allocator=None;self.motion_reference=None
        self.observer=Observer();self.estimator=types.SimpleNamespace(normal=np.array([0.,0.,1.]),load_fraction=1.)
        self.synchronizer=types.SimpleNamespace(_plane=None)
        self.locator=types.SimpleNamespace(records=lambda *args:[])
        self.nominal_joints=np.arange(3,dtype=float);self._vref=np.zeros(9)
        self._held=None;self._sync={'commands':np.zeros(5),'blend_weights':np.zeros(5),'targets':[]}
        self.heading_reference=.1;self._slow_normal=np.array([0.,0.,1.])
        self._fall_end=None;self._yaw_error=None;self._plane=(np.zeros(3),np.array([0.,0.,1.]))

def command(c,xy,v,a):
    c.observer.update()
    ref=np.r_[v,0.,0.,0.,0.,np.zeros(3)]
    err=np.r_[np.zeros(9),c.plant.data.qvel-ref]
    gain=np.arange(90,dtype=float).reshape(5,18)/100
    req=-gain@err;applied=np.clip(req,-c.plant.bounds,c.plant.bounds)
    c._held={'gain':gain.copy(),'vref':ref.copy()};c._vref=ref.copy()
    info=dict(requested=req,reference_qpos=np.r_[xy,np.zeros(8)],reference_qvel=ref,
        feedback_reference_qvel=ref.copy(),feedback_gain=gain,error=err,
        equilibrium_command=np.zeros(5),rolling_feedforward=np.zeros(5),support_command=np.zeros(5),
        lqr_command=req,transition_command_delta=np.zeros(5),heading_command=np.zeros(5),
        fade_command_delta=np.zeros(5),clipping_command_delta=applied-req,sync_weights=np.zeros(5),
        estimated_support_loads_N=np.zeros(4),estimated_contact_point_m=np.zeros(3),
        allocation_drive_reference=np.zeros(5),reference_quat=np.array([1.,0.,0.,0.]),
        reference_acceleration_m_s2=np.array(a),feedback_reference_xy=np.array(xy),
        effective_phase_rad=.2,drive_fade=1.,estimate=copy.deepcopy(vars(c.estimator)))
    return applied,info

class ProbeContracts(unittest.TestCase):
    def make(self):
        live=Controller()
        with patch.object(mod,'clone_native_controller',lambda c:copy.deepcopy(c)):
            probe=mod.NativeCommandProbe(live,command)
        return live,probe
    def test_trials_preserve_live_and_reset_observer_history(self):
        live,probe=self.make();before=mod.history_fingerprint(live)
        one=probe.evaluate([0.,0.],[.02,0.],[0.,0.])
        probe.evaluate([0.,0.],[.5,0.],[.2,0.])
        again=probe.evaluate([0.,0.],[.02,0.],[0.,0.])
        self.assertEqual(mod.history_fingerprint(live),before)
        self.assertEqual(mod.exact_array(one[0]),mod.exact_array(again[0]))
        self.assertEqual(probe.calls,3)
        np.testing.assert_array_equal(probe.shadow.observer.generalized,np.ones(9))
    def test_identical_reference_confirms_complete_state_and_outputs(self):
        live,probe=self.make();reference=([0.,0.],[.02,0.],[0.,0.])
        probe.evaluate(*reference);applied,info=command(live,*reference)
        self.assertTrue(probe.confirm_live(applied,info,reference))
    def test_changed_reference_preserves_sensor_checks_and_detects_corruption(self):
        live,probe=self.make();probe.evaluate([0.,0.],[.02,0.],[0.,0.])
        reference=([0.,0.],[.01,0.],[0.,0.]);applied,info=command(live,*reference)
        self.assertFalse(probe.confirm_live(applied,info,reference))
        live.observer.generalized[0]+=1.
        with self.assertRaisesRegex(AssertionError,'observer history'):
            probe.confirm_live(applied,info,reference)

if __name__=='__main__':unittest.main()
