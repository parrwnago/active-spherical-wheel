"""Synthetic grading contracts, not controller or physical-trajectory trials."""
import copy
import unittest
import numpy as np
import metrics
import evaluate

CONFIG=dict(max_duration_s=75.,goal_hold_s=10.,reference_consistency_atol=1e-10,
    stall=dict(window_s=5.,min_delta_virtual_time_s=.05,geometric_min_delta_u_diagnostic=.005,goal_radius_m=.02),
    settling=dict(sustained_s=2.,goal_radius_m=.02,body_xy_speed_m_s=.02,
                  world_z_angular_speed_rad_s=.05,raw_reference_up_error_deg=2.))


def packet(end=45.):
    t=np.arange(int(round(end/metrics.DT))+1)*metrics.DT
    u,du,ddu,xy,v,a=metrics.native_reference(t)
    n=len(t);q=np.zeros((n,10));q[:,:2]=xy;q[:,3]=1.
    return dict(time_s=t,virtual_time_s=t.copy(),u=u,udot=du,uddot=ddu,qpos=q,qvel=np.zeros((n,9)),
        reference_xy=xy,reference_velocity=v,reference_acceleration=a,
        reference_quat=np.tile([1.,0.,0.,0.],(n,1)),requested=np.zeros((n,5)),
        applied=np.zeros((n,5)),previous_applied=np.zeros((n,5)),
        caps=np.tile([1.5,.6,.6,.3,.3],(n,1)),held=np.arange(n)<n-1,
        observer_update_count=np.ones(n,int),no_truth_read=np.ones(n,bool),
        prior_matches_physical=np.ones(n,bool),heading_command=np.zeros((n,5)))


class MetricContracts(unittest.TestCase):
    def test_finite_line_geometry_keeps_endpoint_and_longitudinal_errors(self):
        normal=np.array([-metrics.DIRECTION[1],metrics.DIRECTION[0]])
        points=np.stack([metrics.ORIGIN-.1*metrics.DIRECTION,
            metrics.ORIGIN+.5*metrics.LENGTH*metrics.DIRECTION+.03*normal,
            metrics.GOAL+.2*metrics.DIRECTION])
        error,along,cross=metrics.straight_distance(points)
        np.testing.assert_allclose(error,[.1,.03,.2],atol=2e-15)
        np.testing.assert_allclose(along,[-1/12,.5,7/6],atol=2e-15)
        np.testing.assert_allclose(cross,[0.,.03,0.],atol=2e-15)

    def test_progress_weight_exposes_pause_omission_and_rejects_partial_success(self):
        # Long pauses may contain large errors; the companion time metric must
        # retain those even though reference-progress quadrature gives no weight.
        t=np.array([0.,1.,2.,12.,13.]);u=np.array([0.,.5,.5,.5,1.])
        error=np.array([0.,0.,.1,.1,0.])
        weighted=metrics.progress_rms(t,u,error,complete=True)
        expected=np.sqrt(.5*.1**2*.5)
        self.assertAlmostEqual(weighted['rms'],expected)
        self.assertGreater(metrics.stats(error)['maximum'],weighted['rms'])
        incomplete=metrics.progress_rms(t[:3],u[:3],error[:3],complete=False)
        self.assertFalse(incomplete['complete']);self.assertIsNone(incomplete['rms'])

    def test_stall_requires_full_duration_far_goal_and_traversal(self):
        t=np.arange(2401)*metrics.DT;u=np.minimum(t/20,.3)
        goal=np.full(len(t),1.)
        result=metrics.no_progress_intervals(t,u,goal,arrival_s=None,window_s=5.,min_delta=.005,goal_radius_m=.02)
        self.assertFalse(result['passed']);self.assertEqual(len(result['episodes']),1)
        self.assertAlmostEqual(result['episodes'][0]['start_s'],5.905)
        near=metrics.no_progress_intervals(t,u,np.full(len(t),.01),arrival_s=None,
            window_s=5.,min_delta=.005,goal_radius_m=.02)
        self.assertTrue(near['passed'])
        ended=metrics.no_progress_intervals(t,u,goal,arrival_s=6.,window_s=5.,min_delta=.005,goal_radius_m=.02)
        self.assertTrue(ended['passed'])

    def test_first_ten_second_hold_is_scored_even_if_an_extra_easy_tail_exists(self):
        p=packet(55.);mask=(p['time_s']>=44.)&(p['time_s']<=45.)
        p['qpos'][mask,:2]+= .03*metrics.DIRECTION
        row,_=metrics.case_metrics(p,dict(completed=True,failure=None),CONFIG,35.)
        self.assertTrue(row['full_ten_second_hold'])
        self.assertEqual(row['primary_episode_end_s'],45.)
        self.assertEqual(row['recorded_extra_tail_s'],10.)
        self.assertFalse(row['settling']['physical_position_passed'])
        self.assertAlmostEqual(row['tracking']['goal_error_at_primary_end_m'],.03)

    def test_simulator_horizon_completion_cannot_substitute_for_path_completion(self):
        p=packet(45.);p['u']*=.9;p['udot']*=.9;p['uddot']*=.9
        p['reference_xy'],p['reference_velocity'],p['reference_acceleration']=metrics.geometric_reference(p['u'],p['udot'],p['uddot'])
        row,_=metrics.case_metrics(p,dict(completed=True,failure=None),CONFIG,None)
        self.assertTrue(row['physical_run_completed'])
        self.assertFalse(row['reference_path_completed'])
        self.assertFalse(row['full_ten_second_hold'])
        self.assertIsNone(row['tracking']['geometric_progress_rms']['rms'])
        # Reaching the reference endpoint at70s is genuine path completion,
        # even though the75s budget leaves only5s of the required10s hold.
        late=packet(75.);t=late['time_s']
        tau=np.where(t<=3.,t,np.minimum(35.,3.+(t-3.)*32./67.))
        u,du,ddu,_,_,_=metrics.native_reference(tau)
        late.update(virtual_time_s=tau,u=u,udot=du*(32./67.),uddot=ddu*(32./67.)**2)
        late['reference_xy'],late['reference_velocity'],late['reference_acceleration']=metrics.geometric_reference(late['u'],late['udot'],late['uddot'])
        row,_=metrics.case_metrics(late,dict(completed=True,failure=None),CONFIG,70.)
        self.assertTrue(row['reference_path_completed'])
        self.assertFalse(row['full_ten_second_hold'])
        self.assertIsNotNone(row['tracking']['geometric_progress_rms']['rms'])

    def test_terminal_unheld_command_is_not_clipping_exposure(self):
        p=packet();p['requested'][-1]=[1000.,-1000.,1000.,-1000.,1000.]
        row,_=metrics.case_metrics(p,dict(completed=True,failure=None),CONFIG,35.)
        self.assertTrue(row['cap_ok']);self.assertTrue(row['clip_identity'])
        self.assertEqual(row['commands']['clipped_any_seconds'],0.)
        self.assertEqual(row['commands']['normalized_clipping_excess']['maximum'],0.)
        self.assertEqual(row['commands']['requested_peak_abs'],[0.]*5)
        # The release adapter uses declared cumulative private-probe counts,
        # while each private observer advances once per G control selection.
        n=len(p['time_s']);t=p['time_s'];complete=t>=35.
        raw={source:p[name]for name,source in evaluate.ALIASES.items()}
        side={source:p[name]for name,source in evaluate.GOVERNOR_ALIASES.items()
              if name not in ('clock_rate','clock_acceleration')}
        side.update(time_s=t.copy(),gov__clock_rate=np.ones(n),gov__clock_acceleration_s_inv=np.zeros(n),
            no_physical_contact_or_terrain_read_during_selection=np.ones(n,bool),
            live_probe_sensor_stages_match=np.ones(n,bool),full_output_identity_when_references_equal=np.ones(n,bool),
            private_dynamic_steps=np.zeros(n,int),private_observer_updates=np.ones(n,int),
            gov__nominal_probe_calls=np.arange(1,n+1),command_held_after_row=p['held'].copy(),
            gov__reference_complete=complete,gov__first_complete_sample_s=np.where(complete,35.,np.nan))
        raw['exact_requested']=np.zeros((n,5))
        canonical=evaluate.canonical(raw,side)
        checks,arrival,stop=evaluate.governor_checks(canonical,side,
            dict(first_complete_sample_s=35.,finished_at_s=35.,actual_end_s=45.,native_failure=None),
            dict(policy='G',maximum_duration_s=75.))
        self.assertTrue(all(c['passed']for c in checks));self.assertEqual((arrival,stop),(35.,45.))
        side['gov__nominal_probe_calls']=np.ones(n,int)
        checks,_,_=evaluate.governor_checks(canonical,side,
            dict(first_complete_sample_s=35.,finished_at_s=35.,actual_end_s=45.,native_failure=None),
            dict(policy='G',maximum_duration_s=75.))
        self.assertFalse(next(c['passed']for c in checks if c['name']=='nominal_probe_count'))

    def test_reference_acceleration_mismatch_is_distinct_from_good_path_error(self):
        p=packet();p['reference_acceleration'][1000,0]+=.01
        row,_=metrics.case_metrics(p,dict(completed=True,failure=None),CONFIG,35.)
        self.assertFalse(row['reference_consistency_ok'])
        self.assertGreater(row['reference_residuals']['reference_acceleration'],.009)
        self.assertAlmostEqual(row['tracking']['geometric_traversal']['maximum'],0.)


if __name__=='__main__':unittest.main()
