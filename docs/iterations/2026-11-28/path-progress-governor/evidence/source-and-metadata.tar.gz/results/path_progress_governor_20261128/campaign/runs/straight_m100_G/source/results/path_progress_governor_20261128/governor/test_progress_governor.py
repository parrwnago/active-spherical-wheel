"""Pure I78 clock/chain-rule contracts; no robot, physics or saved arrays."""
from pathlib import Path
import importlib.util
import math
import unittest
import numpy as np
from progress_governor import (GovernorSettings,ProgressGovernor,bounded_rate,
    cascade_rhs,cascade_step,demand_target,retimed_reference)

ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('_i78_contract_route',
    ROOT/'results/tangent_heading_routes_20261127/runtime/route.py')
routes=importlib.util.module_from_spec(spec);spec.loader.exec_module(routes)

def probe(sigma=.3,joint=.1,request=0.):
    def evaluate(xy,velocity,acceleration):
        info=dict(i78_probe=dict(authority_min_scaled_sigma=sigma),
            allocation_drive_reference=np.array([joint,0.,0.,0.,0.]),
            requested=np.array([request,0.,0.,0.,0.]),
            input_bounds=np.array([1.,.6,.6,.3,.3]))
        return np.clip(info['requested'],-info['input_bounds'],info['input_bounds']),info
    return evaluate

def token(a):
    a=np.asarray(a);return a.dtype.str,a.shape,a.tobytes()

def rk4(x,h,target,settings):
    def f(y):
        z,rate,_=y;dz,dr=cascade_rhs(z,rate,target,settings)
        return np.array([dz,dr,rate])
    k1=f(x);k2=f(x+h*k1/2);k3=f(x+h*k2/2);k4=f(x+h*k3)
    return x+h*(k1+2*k2+2*k3+k4)/6


class GovernorContracts(unittest.TestCase):
    def test_fixed_demand_policy_has_zero_floor_and_full_command_pressure(self):
        settings=GovernorSettings()
        _,info=probe(sigma=.15,joint=10.,request=1.7)(None,None,None)
        gamma,detail=demand_target(info,settings)
        self.assertEqual(gamma,.5)
        self.assertEqual(detail['joint_reference_factor'],.5)
        self.assertEqual(detail['command_factor'],.5)
        _,empty=probe(sigma=0,joint=0,request=0)(None,None,None)
        self.assertEqual(demand_target(empty,settings)[0],0.)
        _,healthy=probe()(None,None,None)
        self.assertEqual(demand_target(healthy,settings)[0],1.)

    def test_native_reference_bytes_until_retiming_and_exact_initial_hold(self):
        route=routes.make_route('straight');gov=ProgressGovernor(route)
        for now in [0.,.005,1.215,2.995,3.,3.005,7.125,20.585,34.995,35.,40.,45.]:
            chosen=gov.select(now,probe())
            self.assertEqual([token(a)for a in chosen['reference']],
                             [token(a)for a in route(now)])
        self.assertEqual(gov.finished_at_s,35.)
        self.assertEqual(gov.probe_calls,12)
        forced=ProgressGovernor(route)
        for now in [0.,1.,2.995,3.]:
            chosen=forced.select(now,probe(sigma=0,joint=100,request=10))
            self.assertEqual(chosen['diagnostics']['new_target_rate'],1.)
            self.assertEqual([token(a)for a in chosen['reference']],[token(a)for a in route(now)])

    def test_new_observation_cannot_change_current_rate_or_acceleration(self):
        route=routes.make_route('straight');gov=ProgressGovernor(route)
        gov.select(0.,probe());gov.select(3.,probe())
        chosen=gov.select(3.005,probe(sigma=.075))
        self.assertEqual(chosen['diagnostics']['new_target_rate'],.5)
        self.assertEqual(chosen['diagnostics']['clock_rate'],1.)
        self.assertEqual(chosen['diagnostics']['clock_acceleration_s_inv'],0.)
        before=[token(a)for a in chosen['reference']]
        after,acceleration=gov._reference()
        self.assertEqual(before,[token(a)for a in after])
        self.assertEqual(acceleration,0.)
        later=gov.select(3.010,probe(sigma=.075))
        self.assertLess(later['diagnostics']['clock_rate'],1.)
        self.assertLess(later['diagnostics']['clock_acceleration_s_inv'],0.)

    def test_heun_invariant_and_monotone_clock_under_abrupt_targets(self):
        settings=GovernorSettings();z=rate=1.;virtual=3.
        rng=np.random.default_rng(137)
        previous=virtual
        for index in range(15000):
            target=float(rng.choice([0.,1.]))if index%101==0 else target
            z,rate,virtual=cascade_step(z,rate,virtual,target,.001,settings)
            self.assertGreaterEqual(z,0.);self.assertLessEqual(z,1.)
            self.assertGreaterEqual(rate,0.);self.assertLessEqual(rate,1.)
            self.assertGreaterEqual(virtual,previous)
            self.assertLessEqual(virtual-previous,.001+1e-13)
            self.assertLessEqual(abs(cascade_rhs(z,rate,target,settings)[1]),4.)
            previous=virtual

    def test_chain_rule_matches_independent_flow_derivatives_on_curved_routes(self):
        settings=GovernorSettings();state=np.array([.6,.75,13.7]);target=.25
        epsilon=1e-4
        minus=rk4(state,-epsilon,target,settings)
        plus=rk4(state,epsilon,target,settings)
        for route_id in ['straight','arc','eight']:
            route=routes.make_route(route_id)
            def reference(s):
                acceleration=cascade_rhs(s[0],s[1],target,settings)[1]
                return retimed_reference(route,s[2],s[1],acceleration)
            p0,v0,a0=reference(state);pm,vm,_=reference(minus);pp,vp,_=reference(plus)
            np.testing.assert_allclose((pp-pm)/(2*epsilon),v0,rtol=2e-6,atol=1e-9)
            np.testing.assert_allclose((vp-vm)/(2*epsilon),a0,rtol=2e-6,atol=1e-8)

    def test_heun_converges_to_independent_fourth_order_flow(self):
        settings=GovernorSettings();initial=np.array([1.,1.,3.]);target=.2;duration=.4
        truth=initial.copy()
        for _ in range(40000):truth=rk4(truth,1e-5,target,settings)
        errors=[]
        for h in [.001,.0005]:
            state=tuple(initial)
            for _ in range(int(round(duration/h))):state=cascade_step(*state,target,h,settings)
            errors.append(float(np.linalg.norm(np.asarray(state)-truth)))
        self.assertLess(errors[0],2e-6)
        self.assertLess(errors[1],errors[0]/3.5)

    def test_accumulated_delay_is_retained_and_goal_is_reached_with_real_hold(self):
        route=routes.make_route('straight');gov=ProgressGovernor(route)
        delays=[];completed=None
        for now in np.arange(0.,60.0001,.005):
            evaluate=probe(sigma=.03)if 3.<now<8. else probe()
            selected=gov.select(float(now),evaluate);d=selected['diagnostics']
            delays.append(d['virtual_delay_s'])
            if d['reference_complete']:
                completed=gov.finished_at_s
                for value in selected['reference'][1:]:np.testing.assert_array_equal(value,np.zeros(2))
                np.testing.assert_array_equal(selected['reference'][0],route(35.)[0])
                self.assertEqual(d['virtual_time_s'],35.)
                self.assertEqual(d['clock_rate'],0.)
        self.assertIsNotNone(completed);self.assertGreater(completed,35.)
        self.assertLess(completed,50.)
        self.assertGreater(delays[int(round(12/.005))],2.)
        self.assertGreaterEqual(float(np.min(np.diff(delays))),-2e-11)

    def test_zero_authority_can_stall_instead_of_inventing_minimum_progress(self):
        route=routes.make_route('straight');gov=ProgressGovernor(route)
        for now in np.arange(0.,20.001,.005):
            d=gov.select(float(now),probe(sigma=0.))['diagnostics']
        self.assertFalse(d['reference_complete'])
        self.assertLess(d['virtual_time_s'],4.)
        self.assertLess(d['clock_rate'],1e-30)

    def test_same_time_is_cached_backwards_time_fails_and_reset_clears_history(self):
        gov=ProgressGovernor(routes.make_route('straight'));first=gov.select(0.,probe())
        def forbidden(*args):raise AssertionError('Repeated time re-probed')
        self.assertIs(gov.select(0.,forbidden),first)
        self.assertEqual(gov.probe_calls,1)
        gov.advance_to(1.)
        self.assertEqual(gov.select(1.,probe())['diagnostics']['time_s'],1.)
        with self.assertRaises(ValueError):gov.select(.5,probe())
        gov.reset();self.assertIsNone(gov.finished_at_s)
        self.assertEqual(gov.select(0.,probe())['diagnostics']['virtual_time_s'],0.)

    def test_invalid_settings_and_nonfinite_probe_values_fail_explicitly(self):
        for kwargs in [dict(time_constant_s=0.),dict(maximum_stage_rate_s_inv=float('nan')),
                       dict(command_margin_fraction=1.1),dict(maximum_substep_s=.2)]:
            with self.assertRaises(ValueError):GovernorSettings(**kwargs)
        _,info=probe()(None,None,None);info['requested'][0]=np.nan
        with self.assertRaises(ValueError):demand_target(info,GovernorSettings())


if __name__=='__main__':unittest.main(verbosity=2)
