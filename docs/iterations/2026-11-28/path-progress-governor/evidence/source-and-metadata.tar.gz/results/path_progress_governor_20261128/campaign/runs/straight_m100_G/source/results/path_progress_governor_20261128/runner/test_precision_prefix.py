"""A shortened terminal mask must not hide changed physical prefix data."""
from pathlib import Path
import sys
import tempfile
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from run_case import verify_precision

class PrecisionPrefixContract(unittest.TestCase):
    def test_shortened_terminal_mask_allowed_but_physical_difference_rejected(self):
        old=dict(time_s=np.arange(5,dtype=float)*.005,exact_reference_xy=np.zeros((5,2)),
            exact_reference_velocity_m_s=np.zeros((5,2)),exact_reference_acceleration_m_s2=np.zeros((5,2)),
            exact_qpos=np.zeros((5,10)),command_held_after_row=np.array([True,True,True,True,False]))
        new={k:v[:3].copy()for k,v in old.items()};new['command_held_after_row'][-1]=False
        with tempfile.TemporaryDirectory()as directory:
            a,b=Path(directory)/'new.npz',Path(directory)/'old.npz'
            np.savez(a,**new);np.savez(b,**old)
            receipt=verify_precision(a,b,'G')
            self.assertTrue(receipt['passed']);self.assertTrue(receipt['terminal_mask_exception'])
            self.assertIsNone(receipt['first_changed_reference_row'])
            new['exact_qpos'][1,0]=.01;np.savez(a,**new)
            with self.assertRaisesRegex(AssertionError,'prefix differs'):
                verify_precision(a,b,'G')

if __name__=='__main__':unittest.main()
