"""Compare closed analytic reductions with independent private-MuJoCo audit."""
from pathlib import Path
import hashlib,json,shutil
import numpy as np
from core import com_state,bridge_qv,clean
from analyze_stage01 import model_properties

ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    out=HERE/'independent_closure_stage01';out.mkdir(exist_ok=False)
    paths=[Path(__file__),HERE/'core.py',HERE/'completed_stage01/interval_rows.json',
           ROOT/'results/slope_response_trace_20261128/verification/intervals_stage01/report.json',
           ROOT/'results/slope_response_trace_20261128/campaign/native102_stage01/substeps.npz',
           ROOT/'results/tangent_heading_routes_20261127/campaign/_workspaces/eight_m100_N/mirror/model.xml']
    bindings={str(p.relative_to(ROOT)):sha(p) for p in paths};shutil.copyfile(Path(__file__),out/'crosscheck_independent.py')
    (out/'registered_before_comparison.json').write_text(json.dumps({'iteration':'I-81','inputs':bindings,'numeric_tolerance':1e-8,'scope':'Numerical agreement of two closed analysis implementations, not a control performance gate.'},indent=2)+'\n')
    mainrows=json.loads(paths[2].read_text());ref=json.loads(paths[3].read_text());refs={x['hold_index']:x for x in ref['rows']}
    with np.load(paths[4],allow_pickle=False) as z:s={k:z[k].copy() for k in z.files}
    props,_=model_properties(paths[5]);errors={}
    for side,key in [('pre','bridge_state_before'),('post','bridge_state')]:
        positions=[];velocities=[]
        for state in s[key]:
            q,v=bridge_qv(state);p,w=com_state(q,v,props);positions.append(p);velocities.append(w)
        errors[side+'_COM_position_m']=float(np.max(np.abs(np.asarray(positions)-ref['COM_substep_'+side+'_position_m'])))
        errors[side+'_COM_velocity_m_s']=float(np.max(np.abs(np.asarray(velocities)-ref['COM_substep_'+side+'_velocity_m_s'])))
    mapping={'COM_velocity_before':'COM_velocity_before','COM_velocity_after':'COM_velocity_after',
        'COM_required_force_N':'COM_momentum_rate_N','physical_interval_wrench':'physical_interval_wrench',
        'physical_filtered_wrench':'physical_filtered_wrench','observer_filtered_wrench':'observer_filtered_wrench',
        'pressure_by_family_N':'pressure_mean_family_N','pressure_last_family_N':'pressure_last_family_N',
        'applied_input':'current_applied','requested_input':'current_requested','prior_applied_input':'prior_held_input'}
    for key,refkey in mapping.items():
        errors[key]=max(float(np.max(np.abs(np.asarray(x[key])-refs[x['hold_index']][refkey]))) for x in mainrows)
    errors['contact_downhill_N']=max(abs(x['sampled_force_projection']['contact_downhill_N']-refs[x['hold_index']]['all_contact_downhill_N']) for x in mainrows)
    errors['sampled_net_downhill_N']=max(abs(x['sampled_force_projection']['sampled_net_downhill_N']-refs[x['hold_index']]['all_plus_gravity_downhill_N']) for x in mainrows)
    family_ok=all(x['inferred_family']==refs[x['hold_index']]['dominant_inferred_family'] and x['current_last_family']==refs[x['hold_index']]['dominant_last_family'] and x['completed_interval_family']==refs[x['hold_index']]['dominant_mean_family'] for x in mainrows)
    passed=family_ok and all(e<=1e-8 for e in errors.values())
    report={'iteration':'I-81','passed':passed,'physical_samples':1300,'intervals':260,'family_labels_agree':family_ok,'maximum_absolute_discrepancies':errors,'no_new_physics':True}
    (out/'report.json').write_text(json.dumps(clean(report),indent=2)+'\n');assert all(sha(ROOT/p)==h for p,h in bindings.items())
    (out/'manifest.json').write_text(json.dumps({'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file()}},indent=2)+'\n')
    print(json.dumps(report));assert passed


if __name__=='__main__':main()
