"""I81 unchanged-native contact/preview/force timing analysis.

Numerical rules live in the prephysics-frozen definitions/core. This new
orchestrator binds its source and closed inputs before reading case arrays.
It does not instantiate a simulator, controller or state mirror.
"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

import numpy as np
from core import (FAMILIES, EPS, clean, unit, angle_deg, dominant,
                  pressure_threshold, contact_reduction, interval_reduction,
                  filter_step, first_at_or_after, quat_matrix, extrapolate,
                  margin, material_velocity, predicted_residual,
                  force_projection, stats, com_state, bridge_qv)
from spherical_wheel.contact_sensing import intrinsic_normal

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
CASE = 'eight_m100_N'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(clean(value), f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def load_arrays(path):
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k].copy() for k in z.files}


def model_properties(path):
    tree = ET.parse(path)
    fork = tree.find("worldbody/body[@name='fork']")
    names = ('fork', 'carrier', 'shell_A', 'shell_B')
    bodies = {x.attrib['name']: x for x in fork.iter('body')}
    if set(bodies) != set(names):
        raise ValueError('COM analytic topology requires exactly the four captured robot bodies')
    properties = {}
    for name in names:
        body = bodies[name]
        if name != 'fork':
            if not np.array_equal(np.fromstring(body.get('pos', '0 0 0'), sep=' '), np.zeros(3)):
                raise ValueError('Nonzero child-body offset is outside declared COM model')
        if 'quat' in body.attrib or 'euler' in body.attrib:
            raise ValueError('Unexpected fixed body orientation')
        inertia = body.find('inertial')
        properties[name] = {'mass': float(inertia.attrib['mass']),
                            'inertial_pos': np.fromstring(inertia.get('pos', '0 0 0'), sep=' ')}
    for name, axis in [('carrier', [0,1,0]), ('shell_A', [1,0,0]), ('shell_B', [1,0,0])]:
        if not np.array_equal(np.fromstring(bodies[name].find('joint').get('axis'), sep=' '), axis):
            raise ValueError('Unexpected joint axis in declared COM topology')
    gravity = np.fromstring(tree.find('option').get('gravity'), sep=' ')
    return properties, gravity


def sample_rows(trace):
    n = len(trace['time_s'])
    if n != 1300 or not np.all(trace['hold_completed']):
        raise AssertionError('Expected 1300 completed 1ms samples')
    rows = []
    for j in range(n):
        contacts = trace['contact_rows'][trace['contact_offsets'][j]:trace['contact_offsets'][j+1]]
        row = contact_reduction(contacts, trace['bridge_state_before'][j,2:5], trace['bridge_state'][j,2:5])
        row.update(time_s=float(trace['time_s'][j]), hold_index=int(trace['hold_index'][j]),
                   substep_index=int(trace['substep_index'][j]), trace_row=j)
        rows.append(row)
    return rows


def family_events(rows, key):
    result = []
    for before, after in zip(rows[:-1], rows[1:]):
        if before[key] != after[key]:
            result.append({'time_s': after['time_s'], 'from': before[key], 'to': after[key]})
    return result


def name(index):
    return FAMILIES[index] if index >= 0 else None


def analyze_intervals(trace, precision, preview, properties, gravity, definitions):
    rows = sample_rows(trace)
    mass = sum(x['mass'] for x in properties.values())
    threshold = pressure_threshold(mass*np.linalg.norm(gravity))
    first = int(round(100.5/.005))
    expected_holds = list(range(first, int(round(101.8/.005))))
    if sorted(set(x['hold_index'] for x in rows)) != expected_holds:
        raise AssertionError('Expected contiguous260 captured holds')
    byhold = {h: [] for h in expected_holds}
    for row in rows:
        byhold[row['hold_index']].append(row)
    physical_filtered = precision['exact_observer_wrench'][first].copy()
    reference_up = np.asarray([quat_matrix(q)[:,2] for q in precision['exact_reference_quat']])
    ref_rate = np.r_[0., np.degrees(np.arccos(np.clip(np.sum(reference_up[1:]*reference_up[:-1],axis=1),-1.,1.)))/.005]
    output = []
    for hold in expected_holds:
        samples = byhold[hold]
        interval = interval_reduction(samples, threshold)
        i = hold+1
        ids = [s['trace_row'] for s in samples]
        if abs(precision['time_s'][i]-interval['time_s']) > 1e-8:
            raise AssertionError('Physical interval endpoint does not match next observer update')
        np.testing.assert_array_equal(trace['held_input'][ids], np.tile(precision['exact_applied'][hold], (5,1)))
        np.testing.assert_array_equal(precision['exact_previous_applied'][i], precision['exact_applied'][hold])
        W = np.r_[interval['all_force'], interval['all_moment']]
        Wpost = np.r_[interval['all_force'], interval['all_moment_post']]
        physical_filtered = filter_step(physical_filtered, W)
        n_pressure = unit(interval['positive_normal_sum'])
        n_radial = unit(interval['positive_radial_sum'])
        n_physical = intrinsic_normal(*np.split(physical_filtered,2), .12)
        n_observer = intrinsic_normal(*np.split(precision['exact_observer_wrench'][i],2), .12)
        n_raw = intrinsic_normal(*np.split(W,2), .12)
        n_post = intrinsic_normal(*np.split(Wpost,2), .12)
        inferred = precision['exact_estimated_support_loads_N'][i]
        di, dl, dm = dominant(inferred), dominant(interval['pressure_last_family_N']), dominant(interval['pressure_by_family_N'])
        qb, vb = bridge_qv(trace['bridge_state_before'][ids[0]])
        qa, va = bridge_qv(trace['bridge_state'][ids[-1]])
        cp_before, cv_before = com_state(qb, vb, properties)
        cp_after, cv_after = com_state(qa, va, properties)
        com_required_force = mass*(cv_after-cv_before)/.005
        disturbance = np.mean(trace['disturbance_world'][ids],axis=0)
        q, v = precision['exact_qpos'][i], precision['exact_qvel'][i]
        total_pressure = float(np.sum(interval['pressure_by_family_N']))
        requested, applied = precision['exact_requested'][i], precision['exact_applied'][i]
        bounds = precision['exact_input_bounds'][i]
        ledger = (precision['exact_equilibrium_command'][i]+precision['exact_rolling_feedforward'][i]+
                  precision['exact_support_command'][i]+precision['exact_lqr_command'][i]+
                  precision['exact_transition_command_delta'][i]+precision['exact_heading_command'][i]+
                  precision['exact_fade_command_delta'][i])
        if not np.allclose(ledger,requested,rtol=1e-12,atol=1e-12):
            raise AssertionError('Requested command ledger does not close')
        if not np.array_equal(np.clip(requested,-bounds,bounds),applied):
            raise AssertionError('Actual clipped command identity fails')
        if not np.array_equal(precision['exact_feedback_reference_qvel'][i,3:6],np.zeros(3)):
            raise AssertionError('Native body angular-rate reference changed')
        gain_step = np.linalg.norm(precision['exact_feedback_gain'][i]-precision['exact_feedback_gain'][i-1],axis=1)
        interval.update(
            inferred_loads_N=inferred.copy(), inferred_family=di, inferred_family_name=name(di),
            current_last_family=dl, current_last_family_name=name(dl),
            completed_interval_family=dm, completed_interval_family_name=name(dm),
            inferred_matches_current_last=bool(di==dl), inferred_matches_completed_interval=bool(di==dm),
            inferred_has_any_completed_pressure=bool(di>=0 and interval['any_pressure_occupancy'][di]>0.),
            inferred_has_substantial_completed_pressure=bool(di>=0 and interval['substantial_pressure_occupancy'][di]>0.),
            completed_pressure_share_on_inferred_family=(float(interval['pressure_by_family_N'][di]/total_pressure) if di>=0 and total_pressure>EPS else None),
            physical_interval_wrench=W, physical_filtered_wrench=physical_filtered.copy(),
            observer_interval_wrench=precision['exact_observer_interval_mean'][i,:6].copy(),
            observer_filtered_wrench=precision['exact_observer_wrench'][i].copy(),
            interval_force_error_N=float(np.linalg.norm(interval['all_force']-precision['exact_observer_interval_mean'][i,:3])),
            interval_moment_error_Nm=float(np.linalg.norm(interval['all_moment']-precision['exact_observer_interval_mean'][i,3:6])),
            observer_vs_filtered_physical_normal_deg=angle_deg(n_observer,n_physical),
            filtered_vs_current_interval_pressure_normal_deg=angle_deg(precision['exact_estimated_normal'][i],n_pressure),
            physical_raw_vs_radial_deg=angle_deg(n_raw,n_radial),
            moment_centre_sensitivity_deg=angle_deg(n_raw,n_post),
            pressure_normal=n_pressure, pressure_radial_normal=n_radial,
            physical_filtered_intrinsic_normal=n_physical, observer_intrinsic_normal=n_observer,
            controller_normal=precision['exact_estimated_normal'][i].copy(),
            root_position=q[:3].copy(), root_velocity=v[:3].copy(),
            COM_position_before=cp_before, COM_position_after=cp_after,
            COM_velocity_before=cv_before, COM_velocity_after=cv_after,
            COM_required_force_N=com_required_force,
            actual_xy_speed_m_s=float(np.linalg.norm(v[:2])),
            desired_xy_speed_m_s=float(np.linalg.norm(precision['exact_reference_velocity_m_s'][i])),
            xy_velocity_error_m_s=v[:2]-precision['exact_reference_velocity_m_s'][i],
            timed_xy_error_m=float(np.linalg.norm(q[:2]-precision['exact_reference_xy'][i])),
            own_target_up_error_deg=angle_deg(quat_matrix(q[3:7])[:,2],reference_up[i]),
            target_up_rate_deg_s=float(ref_rate[i]),
            world_z_rate_rad_s=float((quat_matrix(q[3:7])@v[3:6])[2]),
            gain_row_step_norm=gain_step,
            prior_applied_input=precision['exact_previous_applied'][i].copy(),
            requested_input=requested.copy(), applied_input=applied.copy(), input_bounds=bounds.copy(),
            clipped_channels=(np.abs(requested-applied)>1e-12),
            normalized_request_peak=float(np.max(np.abs(requested)/bounds)),
            normalized_clipping_excess=float(np.linalg.norm((requested-applied)/bounds)),
            support_command=precision['exact_support_command'][i].copy(),
            lqr_command=precision['exact_lqr_command'][i].copy(),
            rolling_feedforward=precision['exact_rolling_feedforward'][i].copy(),
            transition_command_delta=precision['exact_transition_command_delta'][i].copy(),
            sync_weights=precision['exact_sync_weights'][i].copy(),
            angular_rate_reference=precision['exact_feedback_reference_qvel'][i,3:6].copy(),
            command_held_after_row=bool(precision['command_held_after_row'][i]),
            sampled_force_projection=force_projection(interval['all_force'],n_pressure,mass,gravity,disturbance))
        for force_set in ['all','admitted','native']:
            total_force = interval[force_set+'_force']+mass*gravity+disturbance[:3]
            interval[force_set+'_COM_force_residual_N'] = total_force-com_required_force
        output.append(interval)
    return rows, output


def check_extra_rows(preview, precision):
    rows=preview['rows']
    if len(rows)!=261:
        raise AssertionError('Expected261 captured extra-preview rows')
    checks=[]
    for row in rows:
        i=int(row['source_row_index'])
        if abs(float(row['time_s'])-precision['time_s'][i])>1e-9:
            raise AssertionError('Preview source index/time mismatch')
        for key,field in [('qpos','exact_qpos'),('qvel','exact_qvel'),
                          ('previous_applied_input','exact_previous_applied'),
                          ('returned_applied_input','exact_applied'),('requested_input','exact_requested')]:
            np.testing.assert_array_equal(np.asarray(row[key]),precision[field][i])
        np.testing.assert_array_equal(row['sync']['blend_weights'],precision['exact_sync_weights'][i])
        if row.get('native_preview_call_count')!=1 or row.get('capture_state_guard_passed') is not True:
            raise AssertionError('Expected exactly one native preview and pure capture guard')
        if len(row['sync']['targets'])!=4:
            raise AssertionError('Expected four original preview targets')
        checks.append(i)
    if checks!=list(range(20100,20361)):
        raise AssertionError('Preview rows must cover exact declared grid')


def analyze_preview(preview, trace, substeps, precision, properties):
    times=trace['time_s'];pairs=[];residuals=[]
    mass=sum(x['mass'] for x in properties.values());threshold=pressure_threshold(mass*9.81)
    selected=[r for r in preview['rows'] if 100.75-1e-9 <= r['time_s'] <=101.65+1e-9]
    if len(selected)!=181:raise AssertionError('Expected181 focus preview anchors')
    for anchor in selected:
        q,v=np.asarray(anchor['qpos'],float),np.asarray(anchor['qvel'],float)
        plane=anchor['plane']
        if plane is None:raise AssertionError('Native estimated plane unavailable in declared window')
        point,n=np.asarray(plane[0],float),unit(plane[1])
        for target in anchor['sync']['targets']:
            h=float(target['lookahead_s']);name_=target['name'];family=FAMILIES.index(name_)
            if not 0.<h<=.12+1e-12:raise AssertionError('Selected preview horizon outside original120ms')
            predicted=extrapolate(q,v,h)
            current_margin=margin(q,n,name_);pred_margin=margin(predicted,n,name_)
            pred_point=predicted[:3]-.12*n
            pred_gap=float((pred_point-point)@n)
            pred_velocity=predicted_residual(predicted,v,n,target)
            errors=np.r_[current_margin-float(target['current_patch_margin_m']),
                         pred_margin-float(target['predicted_patch_margin_m']),
                         pred_gap-float(target['predicted_support_gap_m']),
                         pred_velocity-np.asarray(target['predicted_matched_tangential_velocity_m_s'])]
            residuals.append(errors)
            if np.max(np.abs(errors))>1e-9:
                raise AssertionError('Independent original preview geometry/residual reconstruction fails')
            target_time=float(anchor['time_s'])+h
            j=first_at_or_after(times,target_time)
            actual_q,actual_v=bridge_qv(trace['bridge_state'][j])
            sub=substeps[j];load=float(sub['pressure_by_family_N'][family]);total=float(sub['pressure_total_N'])
            n_actual=unit(sub['positive_normal_sum'])
            future_margin_frozen=margin(actual_q,n,name_)
            future_margin_pressure=margin(actual_q,n_actual,name_) if np.isfinite(n_actual).all() else None
            actual_point=None;actual_material=None
            if load>EPS:
                actual_point=sub['pressure_point_sums'][family]/load
                local_n=unit(sub['pressure_normal_sums'][family])
                held=trace['held_input'][j]
                speed=held[3+family-2] if family>=2 else 0.
                material=material_velocity(actual_q,actual_v,actual_point,name_,speed)
                actual_material=material-local_n*(local_n@material)
            future_ids=np.flatnonzero((times>float(anchor['time_s'])+1e-9)&(times<=times[j]+1e-9))
            loads=np.asarray([substeps[k]['pressure_by_family_N'][family] for k in future_ids])
            if not len(loads):raise AssertionError('Missing future occupancy interval')
            item=dict(anchor_time_s=float(anchor['time_s']),source_row=int(anchor['source_row_index']),
                name=name_,family=family,lookahead_s=h,query_time_s=target_time,
                physical_sample_time_s=float(times[j]),rounding_lag_s=float(times[j]-target_time),
                original_target=target,blend_weight=float(target['blend_weight']),
                predicted_exposed=bool(target['predicted_exposed']),approaching=bool(target['approaching']),
                predicted_virtual_point=pred_point,
                actual_future_margin_same_anchor_plane_m=future_margin_frozen,
                predicted_minus_actual_same_plane_margin_m=pred_margin-future_margin_frozen,
                actual_future_margin_pressure_normal_m=future_margin_pressure,
                actual_future_family_pressure_N=load,actual_future_pressure_share=(load/total if total>EPS else None),
                actual_future_has_any_pressure=bool(load>EPS),actual_future_substantial=bool(load>threshold),
                actual_future_dominant_family=name(dominant(sub['pressure_by_family_N'])),
                future_window_any_pressure_occupancy=float(np.mean(loads>EPS)),
                future_window_substantial_pressure_occupancy=float(np.mean(loads>threshold)),
                actual_future_pressure_point=actual_point,
                predicted_virtual_point_to_actual_pressure_point_m=(float(np.linalg.norm(pred_point-actual_point)) if actual_point is not None else None),
                actual_future_material_tangent_velocity_m_s=actual_material,
                actual_future_material_tangent_speed_m_s=(float(np.linalg.norm(actual_material)) if actual_material is not None else None),
                predicted_prepared_residual_speed_m_s=float(target['predicted_matched_speed_m_s']),
                force_onset_prediction_accuracy_claim=False)
            pairs.append(item)
    return pairs,np.asarray(residuals)


def make_report(intervals,pairs,residuals,definitions,properties,gravity):
    focus=[x for x in intervals if100.75-1e-9<=x['time_s']<=101.65+1e-9]
    clipped=[x for x in focus if np.any(x['clipped_channels']) and x['command_held_after_row']]
    large=[x for x in focus if x['actual_xy_speed_m_s']>.1]
    snapshots=[]
    for t in definitions['selected_snapshot_times_s']:
        exact=[x for x in intervals if abs(x['time_s']-t)<1e-8]
        snapshots.append(exact[0] if exact else {'requested_time_s':t,'aligned_interval_available':False,
                        'reason':'Prior completed interval lies outside captured physical window'})
    summaries={}
    for key in ['interval_force_error_N','interval_moment_error_Nm',
                'observer_vs_filtered_physical_normal_deg','filtered_vs_current_interval_pressure_normal_deg',
                'physical_raw_vs_radial_deg','moment_centre_sensitivity_deg',
                'actual_xy_speed_m_s','desired_xy_speed_m_s','own_target_up_error_deg',
                'target_up_rate_deg_s','world_z_rate_rad_s','normalized_request_peak','normalized_clipping_excess']:
        summaries[key]=stats([x[key] for x in intervals])
    for kind in ['all','admitted','native']:
        summaries[kind+'_COM_force_residual_norm_N']=stats([np.linalg.norm(x[kind+'_COM_force_residual_N']) for x in intervals])
    projected=[x['sampled_force_projection'] for x in intervals if x['sampled_force_projection']['valid']]
    for key in ['contact_downhill_N','gravity_downhill_N','sampled_net_downhill_N']:
        summaries[key]=stats([x[key] for x in projected])
    routing=dict(rows=len(intervals),focus_rows=len(focus),
        inferred_vs_current_last_disagreement_rows=sum(not x['inferred_matches_current_last'] for x in intervals),
        inferred_vs_completed_interval_disagreement_rows=sum(not x['inferred_matches_completed_interval'] for x in intervals),
        current_last_disagree_but_interval_agrees_rows=sum((not x['inferred_matches_current_last']) and x['inferred_matches_completed_interval'] for x in intervals),
        inferred_family_without_any_completed_pressure_rows=sum(not x['inferred_has_any_completed_pressure'] for x in intervals),
        inferred_family_without_substantial_completed_pressure_rows=sum(not x['inferred_has_substantial_completed_pressure'] for x in intervals),
        changes={'inferred':family_events(intervals,'inferred_family'),
                 'current_last':family_events(intervals,'current_last_family'),
                 'completed_interval':family_events(intervals,'completed_interval_family')},
        observer_error_count_claim=False)
    prepared=[x for x in pairs if x['blend_weight']>0.]
    preview_summary=dict(focus_anchors=181,pairs=len(pairs),nonzero_preparation_pairs=len(prepared),
        independent_original_geometry_max_abs_residual=float(np.max(np.abs(residuals))),
        first_after_rounding_lag_s=stats([x['rounding_lag_s'] for x in pairs]),
        same_plane_margin_motion_difference_m=stats([x['predicted_minus_actual_same_plane_margin_m'] for x in pairs]),
        prepared_same_plane_margin_motion_difference_m=stats([x['predicted_minus_actual_same_plane_margin_m'] for x in prepared]),
        prepared_pairs_with_predicted_exposed=sum(x['predicted_exposed'] for x in prepared),
        prepared_pairs_with_future_any_pressure=sum(x['actual_future_has_any_pressure'] for x in prepared),
        prepared_pairs_with_future_substantial_pressure=sum(x['actual_future_substantial'] for x in prepared),
        prepared_future_material_speed_m_s=stats([x['actual_future_material_tangent_speed_m_s'] for x in prepared]),
        forecast_accuracy_or_causality_claim=False)
    chosen_preview=[x for x in pairs if any(abs(x['anchor_time_s']-t)<1e-8 for t in definitions['selected_snapshot_times_s'])]
    return dict(iteration='I-81',case_id=CASE,no_new_controller_intervention=True,
        diagnostic_completion_separate_from_acceptance=True,full_route_acceptance_claim=False,
        physical_intervals=len(intervals),substeps=1300,statistics=summaries,routing=routing,
        preview=preview_summary,selected_interval_rows=snapshots,selected_preview_pairs=chosen_preview,
        descriptive_markers=dict(first_clipped_focus_row=(clipped[0]['time_s'] if clipped else None),
            first_xy_speed_over_0p1_focus_row=(large[0]['time_s'] if large else None)),
        model=dict(properties=properties,total_mass_kg=sum(x['mass'] for x in properties.values()),gravity_m_s2=gravity),
        qualifications=[definitions['causal_limit'],definitions['preview_semantics'],definitions['force_projection'],
            'A contact-force direction and geometric patch exposure are different observables.',
            'Whole-COM force residual is a diagnostic of sampled exported forces and frame/quadrature assumptions, not a fitted force correction.',
            'Body-root velocity may change from both COM translation and body rotation; do not equate root acceleration to net force/mass.',
            'Force presence at a selected future sample does not make the original kinematic preview a force-onset predictor.',
            'Prepared residual is based on hypothetical drive rate at frozen current velocity; actual future speed includes motor dynamics and later feedback.'])


def plot_outputs(out,intervals,pairs,report):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    t=np.asarray([x['time_s'] for x in intervals])
    fig,ax=plt.subplots(5,1,figsize=(12,13),sharex=True,constrained_layout=True)
    for k,label in enumerate(FAMILIES):
        ax[0].plot(t,[x['pressure_by_family_N'][k] for x in intervals],label=label)
        ax[1].plot(t,[x['inferred_loads_N'][k] for x in intervals],label=label)
    ax[0].set_ylabel('Prior interval\npressure (N)');ax[1].set_ylabel('Inferred load\nnext command (N)');ax[0].legend(ncol=4,fontsize=8)
    ax[2].plot(t,[x['actual_xy_speed_m_s'] for x in intervals],label='Wheel-centre XY speed')
    ax[2].plot(t,[np.linalg.norm(x['COM_velocity_after'][:2]) for x in intervals],label='Whole COM XY speed')
    ax[2].plot(t,[x['desired_xy_speed_m_s'] for x in intervals],label='Desired XY speed',ls='--')
    ax[2].set_ylabel('Speed (m/s)');ax[2].legend(fontsize=8)
    for k,label in [(1,'shell A torque / .6Nm'),(3,'belt A speed / .3m/s')]:
        ax[3].plot(t,[x['requested_input'][k]/x['input_bounds'][k] for x in intervals],label=label+' requested')
        ax[3].plot(t,[x['applied_input'][k]/x['input_bounds'][k] for x in intervals],label=label+' applied',ls='--')
    ax[3].set_ylabel('Normalized\ncurrent command');ax[3].legend(ncol=2,fontsize=7)
    ax[4].plot(t,[x['own_target_up_error_deg'] for x in intervals],label='Own-target up error (deg)')
    twin=ax[4].twinx();twin.plot(t,[x['target_up_rate_deg_s'] for x in intervals],color='tab:orange',alpha=.6,label='Target-up rate')
    ax[4].set_ylabel('Up error (deg)');twin.set_ylabel('Target-up rate (deg/s)');ax[4].set_xlabel('Recorded interval-end / new-command time (s)')
    ax[4].legend(loc='upper left',fontsize=8);twin.legend(loc='upper right',fontsize=8)
    for a in ax:
        for when in [100.835,101.5]:a.axvline(when,c='k',ls=':',lw=.7)
        a.grid(alpha=.25)
    fig.suptitle('I-81 unchanged native: completed physical load, inferred routing and command response\nCurrent commands act after state; pressure means and filtered inference are different quantities')
    fig.savefig(out/'routing_response.png',dpi=150)
    fig2,aa=plt.subplots(4,1,figsize=(12,11),sharex=True,constrained_layout=True)
    for key,label in [('contact_downhill_N','Exported contact'),('gravity_downhill_N','Model gravity'),('sampled_net_downhill_N','Sampled sum')]:
        aa[0].plot(t,[x['sampled_force_projection'].get(key,np.nan) for x in intervals],label=label)
    aa[0].set_ylabel('Downhill tangent\nforce diagnostic (N)');aa[0].legend(ncol=3,fontsize=8)
    for kind in ['all','admitted','native']:
        aa[1].plot(t,[np.linalg.norm(x[kind+'_COM_force_residual_N']) for x in intervals],label=kind)
    aa[1].set_ylabel('Force − mΔVCOM/Δt\nnorm (N)');aa[1].legend(ncol=3,fontsize=8)
    aa[2].plot(t,[x['observer_vs_filtered_physical_normal_deg'] for x in intervals],label='Observer vs same-filter physical wrench')
    aa[2].plot(t,[x['filtered_vs_current_interval_pressure_normal_deg'] for x in intervals],label='Controller normal vs pressure-normal mean')
    aa[2].set_ylabel('Direction gap (deg)');aa[2].legend(fontsize=8)
    for k,label in enumerate(FAMILIES):
        pp=[p for p in pairs if p['family']==k and p['blend_weight']>0.]
        aa[3].scatter([p['anchor_time_s'] for p in pp],[1000*p['predicted_minus_actual_same_plane_margin_m'] for p in pp],s=7,label=label)
    aa[3].set_ylabel('CV − future actual\nfrozen-plane margin (mm)');aa[3].set_xlabel('Recorded time / original preview anchor (s)');aa[3].legend(ncol=4,fontsize=8)
    for a in aa:
        for when in [100.835,101.5]:a.axvline(when,c='k',ls=':',lw=.7)
        a.grid(alpha=.25)
    fig2.suptitle('I-81 force/normal/preview diagnostics — no causal intervention\nExported samples are not exact impulses; geometric exposure is not predicted force onset')
    fig2.savefig(out/'force_preview_diagnostics.png',dpi=150)
    with PdfPages(out/'diagnostic_comparison.pdf') as pdf:pdf.savefig(fig);pdf.savefig(fig2)
    plt.close(fig);plt.close(fig2)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    run=args.run.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    parity=run/'parity_receipt.json'
    if not json.loads(parity.read_text()).get('passed'):
        raise ValueError('Exact native prefix parity required before interpretation')
    definitions=json.loads((HERE/'definitions.json').read_text())
    model=ROOT/definitions['model_input_path']
    inputs=[run/'substeps.npz',run/'preview_rows.json',parity,
            run/'child/campaign/runs'/CASE/'precision.npz',
            run/'child/campaign/runs'/CASE/'rollout.npz',model,
            ROOT/'src/spherical_wheel/contact_sensing.py',HERE/'core.py',HERE/'definitions.json',Path(__file__)]
    bindings={str(p.relative_to(ROOT)):sha(p) for p in inputs}
    for p in [Path(__file__),HERE/'core.py',HERE/'definitions.json']:
        shutil.copyfile(p,out/p.name)
    save(out/'registered_before_arrays.json',dict(iteration='I-81',utc=datetime.now(timezone.utc).isoformat(),
        source_inputs=bindings,definitions=definitions,no_new_physics=True,no_control_changes=True,
        analysis_source_added_after_prephysics_freeze=True,
        qualification='Definitions/core were frozen before physics; this orchestrator is registered before first new-case array read.'))
    properties,gravity=model_properties(model)
    trace=load_arrays(inputs[0]);precision=load_arrays(inputs[3])
    preview=json.loads(inputs[1].read_text())
    check_extra_rows(preview,precision)
    substeps,intervals=analyze_intervals(trace,precision,preview,properties,gravity,definitions)
    pairs,residuals=analyze_preview(preview,trace,substeps,precision,properties)
    report=make_report(intervals,pairs,residuals,definitions,properties,gravity)
    save(out/'interval_rows.json',intervals);save(out/'preview_pairs.json',pairs);save(out/'report.json',report)
    plot_outputs(out,intervals,pairs,report)
    for path,expected in bindings.items():
        if sha(ROOT/path)!=expected:raise AssertionError('Input/source changed during analysis:'+path)
    save(out/'artifact_manifest.json',dict(iteration='I-81',source_inputs_unchanged=True,
        files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(out.iterdir()) if p.is_file()}))
    print(json.dumps(clean(dict(intervals=len(intervals),preview_pairs=len(pairs),routing=report['routing'],
                               statistics=report['statistics'],preview=report['preview'])),sort_keys=True),flush=True)


if __name__=='__main__':main()
