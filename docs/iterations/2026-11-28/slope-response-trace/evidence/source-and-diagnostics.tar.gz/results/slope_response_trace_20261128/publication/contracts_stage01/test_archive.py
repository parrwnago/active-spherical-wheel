"""Three pure packaging contracts on temporary files, no campaign reads."""
from pathlib import Path
import hashlib
import importlib.util
import io
import tarfile
import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i81_archive_contract_source', HERE/'build_archive.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def put(path, text='bytes'):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


def test_selection_is_narrow_and_keeps_registered_prerequisites(tmp_path):
    root = tmp_path/'repo'
    base = root/'results/i81'
    out = base/'publication/full_evidence_stage01'
    keep = put(base/'campaign/case/precision.npz')
    model = put(base/'campaign/_workspaces/case/model.xml')
    omit = put(base/'campaign/_workspaces/case/meshes/terrain.obj')
    exact = put(root/'assets/registered.obj')
    put(root/'unrelated/user_secret.txt')
    put(base/'curation/helper.py')
    put(out/'recursive.tar.gz')
    selected, excluded = m.select_files(root, base, out, {'assets/registered.obj': m.sha(exact)})
    assert set(selected) == {str(x.relative_to(root)) for x in [keep, model, exact]}
    assert str(omit.relative_to(root)) in excluded
    assert not any('unrelated' in x for x in selected)


def test_bound_input_changed_rejected(tmp_path):
    path = put(tmp_path/'src/control.py', 'before')
    protocol = {'source_sha256': {'src/control.py': m.sha(path)}, 'input_sha256': {}}
    assert m.check_registered(tmp_path, protocol)
    path.write_text('after')
    with pytest.raises(AssertionError, match='changed'):
        m.check_registered(tmp_path, protocol)


def test_stream_verification_detects_bad_digest_and_member_set(tmp_path):
    archive = tmp_path/'fixture.tar.gz'
    payload = b'closed evidence'
    with tarfile.open(archive, 'w:gz') as tf:
        info = tarfile.TarInfo('project/evidence.json')
        info.size = len(payload)
        tf.addfile(info, io.BytesIO(payload))
    expected = {'project/evidence.json': {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}}
    assert m.stream_verify(archive, expected) == 1
    bad = {'project/evidence.json': {'bytes': len(payload), 'sha256': '0'*64}}
    with pytest.raises(AssertionError, match='digest'):
        m.stream_verify(archive, bad)
    with pytest.raises(AssertionError, match='Unexpected'):
        m.stream_verify(archive, {})
