"""Bind the closed native I81 recording before downstream array analysis."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    campaign = BASE / 'campaign'
    out = campaign / 'outputs_sealed.json'
    if out.exists():
        raise FileExistsError(out)
    run = campaign / 'native102_stage01'
    protocol_path = BASE / 'protocol/frozen_stage01/protocol.json'
    protocol = json.loads(protocol_path.read_text())
    observed = json.loads((campaign / 'native102_stage01.observed_exit.json').read_text())
    assert observed['actual_observed_exit_code'] == 0
    parity = json.loads((run / 'parity_receipt.json').read_text())
    assert parity['passed'] and parity['prefix_rows'] == 20401 and len(parity['fields']) == 79
    assert all(x['bit_exact'] for x in parity['fields'])
    capture = json.loads((run / 'capture_receipt.json').read_text())
    assert capture['substep_rows'] == 1300
    assert capture['metadata']['completed_holds'] == 260 and capture['metadata']['failed_holds'] == 0
    for key in ['source_sha256', 'input_sha256']:
        for name, expected in protocol[key].items():
            assert sha(ROOT / name) == expected, name
    manifest = json.loads((run / 'artifact_manifest.json').read_text())['files']
    for name, expected in manifest.items():
        p = run / name
        assert p.stat().st_size == expected['bytes'] and sha(p) == expected['sha256'], name
    selected = []
    for p in campaign.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts:
            continue
        if '_workspaces' in p.parts and p.suffix not in {'.xml', '.urdf', '.sdf', '.json', '.yaml', '.yml'}:
            continue
        selected.append(p)
    files = {str(p.relative_to(BASE)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(selected)}
    data = dict(iteration='I-81', utc=datetime.now(timezone.utc).isoformat(),
        relative_base=str(BASE.relative_to(ROOT)), files=files,
        sealer_sha256=sha(Path(__file__)), protocol_sha256=sha(protocol_path),
        observed_process_exit_code=0, original_precision_prefix_parity=True,
        source_inputs_unchanged=True, registered_source_count=len(protocol['source_sha256']),
        registered_input_count=len(protocol['input_sha256']),
        scope='Closed one shortened native102s diagnostic. Complete case manifest verified, including rebuildable assets; output seal omits only pycache and rebuildable workspace assets outside direct model/config metadata. No controller intervention or full-route acceptance.')
    with out.open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'output_seal': str(out.relative_to(ROOT)), 'sha256': sha(out),
                      'files': len(files), 'source_count': len(protocol['source_sha256']),
                      'input_count': len(protocol['input_sha256'])}))


if __name__ == '__main__':
    main()
