"""Compare independent physical/COM reductions with closed canonical analysis."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT/'results/slope_response_trace_20261128'
HERE = Path(__file__).resolve().parent


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False); f.write('\n')


def main():
    out = HERE/'completed'
    out.mkdir(exist_ok=False)
    independent = BASE/'verification/intervals_stage01/report.json'
    canonical = BASE/'analysis/completed_stage01/report.json'
    canonical_rows = BASE/'analysis/completed_stage01/interval_rows.json'
    preview = BASE/'verification/preview_stage01/report.json'
    paths = [Path(__file__).resolve(), independent, canonical, canonical_rows, preview]
    bindings = {str(p.relative_to(ROOT)): sha(p) for p in paths}
    shutil.copyfile(Path(__file__), out/'compare_analysis.py')
    save(out/'registered_before_comparison.json', {'iteration':'I-81', 'utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Posthoc independent numeric closure of existing reductions, no source/data/controller/physics changes.',
        'inputs_and_source':bindings, 'tolerances':{'COM_position_velocity':1e-12,'force_and_momentum':1e-10,'directions_angles':1e-8},
        'residual_sign':'Canonical force balance residual is applied-force minus momentum-rate; independent reference uses the reverse sign. Compare their negative explicitly.'})
    a=json.loads(independent.read_text()); b=json.loads(canonical.read_text()); rows=json.loads(canonical_rows.read_text()); pv=json.loads(preview.read_text())
    assert len(a['rows'])==len(rows)==260 and b['physical_intervals']==260 and b['substeps']==1300
    assert pv['captured_rows']==261 and pv['focus_rows']==181 and pv['focus_target_queries']==724
    assert b['preview']['focus_anchors']==181 and b['preview']['pairs']==724
    maxima={}; leaves=0
    def compare(key,left,right,tol):
        nonlocal leaves
        x,y=np.asarray(left,float),np.asarray(right,float)
        assert x.shape==y.shape,key
        err=float(np.max(np.abs(x-y))) if x.size else 0.
        maxima[key]=max(maxima.get(key,0.),err); leaves+=x.size
        assert err<tol,(key,err,tol)
    compare('model_total_mass',a['total_mass_kg'],b['model']['total_mass_kg'],1e-12)
    compare('model_gravity',a['gravity_m_s2'],b['model']['gravity_m_s2'],1e-12)
    for j,(x,y) in enumerate(zip(a['rows'],rows)):
        assert x['source_row']==y['observer_source_row'] and x['hold_index']==y['hold_index']
        compare('time',x['time_s'],y['time_s'],1e-9)
        for k in ['physical_interval_wrench','physical_filtered_wrench','observer_interval_wrench','observer_filtered_wrench']:
            compare(k,x[k],y[k],1e-10)
        for left,right in [('pressure_mean_family_N','pressure_by_family_N'),('pressure_last_family_N','pressure_last_family_N'),
                           ('inferred_family_N','inferred_loads_N'),('COM_velocity_before','COM_velocity_before'),
                           ('COM_velocity_after','COM_velocity_after'),('COM_momentum_rate_N','COM_required_force_N'),
                           ('prior_held_input','prior_applied_input'),('current_requested','requested_input'),('current_applied','applied_input')]:
            compare(right,x[left],y[right],1e-12 if right.startswith('COM_velocity') else 1e-10)
        for side,subindex in [('before',0),('after',4)]:
            values=a['COM_substep_pre_position_m'] if side=='before' else a['COM_substep_post_position_m']
            compare('COM_position_'+side,values[5*j+subindex],y['COM_position_'+side],1e-12)
        for name in ['all','admitted','native']:
            compare(name+'_force',x['signed_forces_N'][name],y[name+'_force'],1e-10)
            compare(name+'_COM_residual',-np.asarray(x['force_balance_residual_N'][name]),y[name+'_COM_force_residual_N'],1e-10)
        compare('pressure_normal',x['pressure_normal'],y['pressure_normal'],1e-10)
        compare('downhill_unit',x['downhill_unit'],y['sampled_force_projection']['downhill_unit'],1e-10)
        for left,right in [('gravity_downhill_N','gravity_downhill_N'),('all_contact_downhill_N','contact_downhill_N'),('all_plus_gravity_downhill_N','sampled_net_downhill_N')]:
            compare(right,x[left],y['sampled_force_projection'][right],1e-10)
        compare('filtered_intrinsic_angle_deg',x['filtered_intrinsic_angle_deg'],y['observer_vs_filtered_physical_normal_deg'],1e-8)
        compare('force_error_N',x['force_error_N'],y['interval_force_error_N'],1e-10)
        compare('moment_error_Nm',x['moment_error_Nm'],y['interval_moment_error_Nm'],1e-10)
        compare('substantial_occupancy',x['substantial_occupancy'],y['substantial_pressure_occupancy'],1e-12)
        assert x['dominant_mean_family']==y['completed_interval_family']
        assert x['dominant_last_family']==y['current_last_family']
        assert x['dominant_inferred_family']==y['inferred_family']
    zero_any=sum(x['dominant_inferred_family']<0 or x['pressure_mean_family_N'][x['dominant_inferred_family']]<=1e-9 for x in a['rows'])
    zero_substantial=sum(x['dominant_inferred_family']<0 or x['substantial_occupancy'][x['dominant_inferred_family']]==0 for x in a['rows'])
    rescued=sum(x['dominant_last_family']!=x['dominant_inferred_family'] and x['dominant_mean_family']==x['dominant_inferred_family'] for x in a['rows'])
    counts={'inferred_vs_current_last_disagreement_rows':a['all_intervals']['last_vs_inferred_disagreements'],
            'inferred_vs_completed_interval_disagreement_rows':a['all_intervals']['mean_vs_inferred_disagreements'],
            'current_last_disagree_but_interval_agrees_rows':rescued,
            'inferred_family_without_any_completed_pressure_rows':zero_any,
            'inferred_family_without_substantial_completed_pressure_rows':zero_substantial}
    for k,v in counts.items(): assert b['routing'][k]==v,(k,v,b['routing'][k])
    assert all(sha(ROOT/name)==v for name,v in bindings.items())
    save(out/'report.json',{'iteration':'I-81','passed':True,'no_new_physics':True,'numeric_scalar_leaves_compared':int(leaves),
         'intervals':260,'focus_preview_pairs_verified':724,'routing_counters':counts,'maximum_absolute_differences':maxima,
         'independent_COM_reference':'Private MuJoCo kinematics/comPos/comVel/subtreeVel, not copied analytical helper.',
         'interpretation':'Numeric identity/force-accounting closure only, no performance acceptance or causal controller-effect proof.',
         'inputs_unchanged':True})
    save(out/'artifact_manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'passed':True,'numeric_scalar_leaves':int(leaves),'routing':counts,'max_difference':max(maxima.values())}))


if __name__=='__main__':main()
