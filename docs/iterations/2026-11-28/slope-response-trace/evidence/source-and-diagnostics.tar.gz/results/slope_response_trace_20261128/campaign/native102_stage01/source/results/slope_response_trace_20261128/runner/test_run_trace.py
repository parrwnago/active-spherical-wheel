"""Focused instrumentation contracts; no simulator/model/controller execution."""
from pathlib import Path
from types import SimpleNamespace
import importlib.util
import json
import numpy as np
import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i81_runner_contract_source', HERE/'run_trace.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def fake_controller(time=100.5):
    data = SimpleNamespace(qpos=np.arange(10, dtype=float), qvel=np.arange(9, dtype=float), time=time)
    private = SimpleNamespace(qpos=np.arange(10, dtype=float), qvel=np.arange(9, dtype=float),
                              time=0., xpos=np.zeros((2, 3)), xmat=np.zeros((2, 9)))
    sync = SimpleNamespace(_data=private, _plane=(np.arange(3.), np.array([0., 0., 1.])),
                           preview=lambda *args, **kwargs: {'unchanged': True})
    return SimpleNamespace(plant=SimpleNamespace(data=data, last_input=np.arange(5.)),
        nominal_joints=np.arange(3.), _vref=np.arange(9.),
        _held={'gain': np.eye(3)}, _plane=(np.zeros(3), np.array([0., 0., 1.])),
        _sync={'targets': [{'name': 'belt_A', 'lookahead_s': .12,
                           'actual_tangential_velocity_m_s': np.arange(3.)}],
               'commands': np.arange(5.), 'blend_weights': np.zeros(5)},
        _slow_normal=np.array([0., 0., 1.]), _yaw_error=None,
        observer=SimpleNamespace(generalized=np.arange(9.), interval_mean=np.arange(9.)+.5,
                                 _previous=(100.495, np.eye(9), np.arange(9.), np.zeros(9))),
        estimator=SimpleNamespace(normal=np.array([0., 0., 1.]), loaded=True, friction=.7),
        synchronizer=sync)


def fake_outputs():
    return np.arange(5.), {'requested': np.arange(5.)+1., 'optional': np.nan,
                           'estimate': {'normal': np.array([0., 0., 1.])}}


def test_capture_copies_nested_values_without_live_mutation():
    c = fake_controller()
    applied, info = fake_outputs()
    before = m.capture_guard(c, applied, info)
    row = m.export_preview_row(c, np.zeros(2), np.ones(2), np.zeros(2), applied, info)
    assert m.capture_guard(c, applied, info) == before
    row['sync']['targets'][0]['actual_tangential_velocity_m_s'][0] = 999.
    row['qpos'][0] = 888.
    row['observer']['generalized'][0] = 777.
    assert m.capture_guard(c, applied, info) == before
    assert row['info']['optional'] is None
    json.dumps(row, allow_nan=False)


def test_guard_detects_signed_zero_and_history_mutation():
    c = fake_controller()
    applied, info = fake_outputs()
    before = m.capture_guard(c, applied, info)
    c._vref[0] = -0.
    assert m.capture_guard(c, applied, info) != before
    c._vref[0] = 0.
    assert m.capture_guard(c, applied, info) == before
    c.observer._previous[1][0, 0] = 2.
    assert m.capture_guard(c, applied, info) != before


def test_wrapper_evaluates_native_and_preview_once_and_preserves_objects():
    c = fake_controller()
    applied, info = fake_outputs()
    called = []
    def native(controller, xy, velocity, acceleration):
        called.append(controller.plant.data.time)
        controller.synchronizer.preview()
        return applied, info
    rows, counts = [], {}
    wrapped = m.command_capture(native, rows, counts)
    a, i = wrapped(c, np.zeros(2), np.ones(2), np.zeros(2))
    assert a is applied and i is info
    assert called == [100.5] and len(rows) == 1
    c.plant.data.time = 100.
    a, i = wrapped(c, np.zeros(2), np.ones(2), np.zeros(2))
    assert a is applied and i is info and len(rows) == 1
    assert counts == {'native_commands': 2, 'native_previews': 2}


def test_wrapper_rejects_extra_preview_evaluation():
    c = fake_controller()
    applied, info = fake_outputs()
    def twice(controller, *args):
        controller.synchronizer.preview()
        controller.synchronizer.preview()
        return applied, info
    with pytest.raises(AssertionError, match='Exactly one'):
        m.command_capture(twice, [])(c, np.zeros(2), np.ones(2), np.zeros(2))


def test_fixed_capture_bounds_and_future_outcome_coverage():
    assert m.in_capture_window(100.5) and m.in_capture_window(101.8)
    assert not m.in_capture_window(100.495) and not m.in_capture_window(101.805)
    samples = [i*.005 for i in range(20401) if m.in_capture_window(i*.005)]
    assert len(samples) == 261
    assert 101.65+.12 <= m.SETTINGS['capture_window_s'][1]
    assert 100.5+.001 > m.SETTINGS['capture_window_s'][0]


def test_settings_rejects_silent_window_or_horizon_change():
    m.validate_settings({'iteration': 'I-81', 'runner_settings': m.SETTINGS.copy()})
    altered = dict(m.SETTINGS, physical_stop_s=101.65)
    with pytest.raises(ValueError):
        m.validate_settings({'iteration': 'I-81', 'runner_settings': altered})
