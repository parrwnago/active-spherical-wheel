"""Independent private-MuJoCo kinematics check of original preview targets.

No model stepping, dynamics, collision, observer or live controller calls.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import numpy as np
import mujoco

ROOT=Path(__file__).resolve().parents[4]
BASE=ROOT/'results/slope_response_trace_20261128'
HERE=Path(__file__).resolve().parent
RUN=BASE/'campaign/native102_stage01'
MODEL=ROOT/'results/tangent_heading_routes_20261127/campaign/_workspaces/eight_m100_N/mirror/model.xml'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')


def main():
    out=HERE/'completed';out.mkdir(exist_ok=False)
    inputs=[Path(__file__).resolve(),MODEL,RUN/'preview_rows.json',BASE/'analysis/completed_stage01/preview_pairs.json']
    bindings={str(p.relative_to(ROOT)):sha(p) for p in inputs}
    shutil.copyfile(Path(__file__),out/'verify_geometry.py')
    save(out/'registered_before_array_reads.json',{'iteration':'I-81','utc':datetime.now(timezone.utc).isoformat(),
        'inputs_and_source':bindings,'scope':'Independent library kinematics/Jacobians versus recorded native targets and analytic reconstruction; no dynamics or physics.',
        'tolerance_SI':1e-9,'interpretation':'Checks original geometric/preparation calculation identity; predicted exposure is not a force-onset forecast.'})
    captures=json.loads((RUN/'preview_rows.json').read_text())['rows']
    pairs=json.loads((BASE/'analysis/completed_stage01/preview_pairs.json').read_text())
    # Each native pair is independently recomputed from its original anchor,
    # frozen plane and selected horizon, using library kinematics/Jacobians.
    model=mujoco.MjModel.from_xml_path(str(MODEL));data=mujoco.MjData(model)
    maxima={'recorded_margin_m':0.,'recorded_gap_m':0.,'recorded_residual_m_s':0.}
    rows=[]
    for row in captures:
        if not 100.75-1e-9<=row['time_s']<=101.65+1e-9:continue
        q,v=np.asarray(row['qpos'],float),np.asarray(row['qvel'],float)
        plane=np.asarray(row['plane'],float);n=plane[1]/np.linalg.norm(plane[1]);projection=np.eye(3)-np.outer(n,n)
        for target in row['sync']['targets']:
            predicted=q.copy();mujoco.mj_integratePos(model,predicted,v,float(target['lookahead_s']))
            data.qpos[:]=predicted;mujoco.mj_kinematics(model,data);mujoco.mj_comPos(model,data)
            name=target['name'];gid=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,name+'_smooth')
            assert gid>=0
            bid=int(model.geom_bodyid[gid]);sign,lower,upper,_,radius=model.geom_user[gid,:5]
            point=data.xpos[bid]-radius*n;axis=data.xmat[bid].reshape(3,3)[:,0]
            signed=sign*float((-radius*n)@axis);margin=signed-lower
            if name.startswith('shell'):margin=min(margin,upper-signed)
            gap=float((point-plane[0])@n)
            jac=np.zeros((3,model.nv));mujoco.mj_jac(model,data,jac,None,point,bid)
            if name.startswith('shell'):
                jid=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,name+'_joint');dof=int(model.jnt_dofadr[jid])
                used=v.copy();used[dof]=float(target['target_joint_speed_rad_s']);residual=projection@(jac@used)
            else:
                belt_axis=data.geom_xmat[gid].reshape(3,3)[:,1]
                residual=projection@(jac@v+belt_axis*float(target['target_surface_speed_m_s']))
            errors={'recorded_margin_m':abs(margin-float(target['predicted_patch_margin_m'])),
                    'recorded_gap_m':abs(gap-float(target['predicted_support_gap_m'])),
                    'recorded_residual_m_s':float(np.max(np.abs(residual-np.asarray(target['predicted_matched_tangential_velocity_m_s']))))}
            for key,e in errors.items():maxima[key]=max(maxima[key],e);assert e<1e-9,(row['time_s'],name,key,e)
            rows.append({'anchor_time_s':row['time_s'],'family':name,'margin_m':float(margin),
                         'gap_m':gap,'residual_m_s':residual.tolist(),'errors':errors})
    assert len(rows)==724 and len(pairs)==724
    assert all(sha(ROOT/p)==h for p,h in bindings.items())
    save(out/'report.json',{'iteration':'I-81','passed':True,'pairs':724,'maximum_absolute_errors':maxima,
        'no_new_physics':True,'inputs_unchanged':True,'mujoco_version':mujoco.__version__,
        'independent_reference':'Original model metadata, mj_integratePos, mj_kinematics, mj_comPos and mj_jac; no analytic helper imports.',
        'scope':'Original target identity only, not force-onset prediction accuracy or contact-cause proof.','rows':rows})
    save(out/'artifact_manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'passed':True,'pairs':len(rows),'maximum_absolute_errors':maxima}))


if __name__=='__main__':main()
