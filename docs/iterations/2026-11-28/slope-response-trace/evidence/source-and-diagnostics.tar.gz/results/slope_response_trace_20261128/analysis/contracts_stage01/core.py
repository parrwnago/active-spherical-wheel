"""Pure I81 reduction/geometry helpers; no simulator or controller execution."""
from __future__ import annotations

import math
import numpy as np

FAMILIES = ('shell_A', 'shell_B', 'belt_A', 'belt_B')
TAG_TO_FAMILY = np.asarray([0, 1, 2, 3, 0, 1, -1])
EPS = 1e-9


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [clean(v) for v in value]
    if isinstance(value, np.ndarray):
        return clean(value.tolist())
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def unit(vector):
    v = np.asarray(vector, float)
    norm = float(np.linalg.norm(v))
    return v/norm if np.isfinite(norm) and norm > 1e-12 else np.full(v.shape, np.nan)


def angle_deg(a, b):
    if a is None or b is None:
        return None
    aa, bb = unit(a), unit(b)
    if not np.isfinite(np.r_[aa, bb]).all():
        return None
    return float(np.degrees(np.arccos(np.clip(aa@bb, -1., 1.))))


def dominant(loads):
    values = np.asarray(loads, float)
    return int(np.argmax(values)) if np.sum(np.maximum(values, 0.)) > EPS else -1


def pressure_threshold(weight):
    return max(.05, .05*float(weight))


def contact_reduction(contact_rows, pre_center, post_center):
    c = np.asarray(contact_rows, float).reshape(-1, 16)
    pre, post = np.asarray(pre_center, float), np.asarray(post_center, float)
    tag = c[:, 0].astype(np.int64)
    if len(c) and (not np.array_equal(c[:, 0], tag) or np.any((tag < 0) | (tag > 6))):
        raise ValueError('Unknown contact tag')
    p, n, force = c[:, 1:4], c[:, 4:7], c[:, 7:10]
    fn = np.einsum('ij,ij->i', n, force)
    admitted = c[:, 12] >= .5
    native = admitted & ((c[:, 10] > 0.) | (fn > 0.))
    positive = admitted & (fn > EPS)
    family = TAG_TO_FAMILY[tag]
    result = {}
    for name, mask in [('all', np.ones(len(c), bool)), ('admitted', admitted), ('native', native)]:
        result[name+'_force'] = force[mask].sum(axis=0)
        result[name+'_moment'] = np.cross(p[mask]-pre, force[mask]).sum(axis=0)
    result['all_moment_post'] = np.cross(p-post, force).sum(axis=0)
    result['pressure_by_tag_N'] = np.asarray([fn[positive & (tag == k)].sum() for k in range(7)])
    result['pressure_by_family_N'] = np.asarray([fn[positive & (family == k)].sum() for k in range(4)])
    result['pressure_total_N'] = float(fn[positive].sum())
    result['positive_normal_sum'] = (fn[positive, None]*n[positive]).sum(axis=0)
    result['positive_radial_sum'] = (fn[positive, None]*(pre-p[positive])).sum(axis=0)
    result['pressure_point_sums'] = np.asarray([(fn[positive & (family == k), None]*p[positive & (family == k)]).sum(axis=0) for k in range(4)])
    result['pressure_normal_sums'] = np.asarray([(fn[positive & (family == k), None]*n[positive & (family == k)]).sum(axis=0) for k in range(4)])
    result['low_normal_force'] = force[admitted & (fn <= EPS)].sum(axis=0)
    result['rejected_force'] = force[~admitted].sum(axis=0)
    result['normal_force_signed'] = fn
    return result


def interval_reduction(samples, substantial_N):
    if len(samples) != 5 or [x['substep_index'] for x in samples] != [1, 2, 3, 4, 5]:
        raise ValueError('Exactly five ordered 1ms samples required')
    hold = samples[0]['hold_index']
    if any(x['hold_index'] != hold for x in samples):
        raise ValueError('Mixed hold indices')
    result = {name: np.mean([s[name] for s in samples], axis=0) for name in [
        'all_force', 'all_moment', 'all_moment_post', 'admitted_force', 'admitted_moment',
        'native_force', 'native_moment', 'pressure_by_tag_N', 'pressure_by_family_N',
        'positive_normal_sum', 'positive_radial_sum', 'low_normal_force', 'rejected_force']}
    pressure = np.asarray([s['pressure_by_family_N'] for s in samples])
    result.update(hold_index=hold, observer_source_row=hold+1,
                  time_s=float(samples[-1]['time_s']),
                  pressure_last_family_N=pressure[-1].copy(),
                  any_pressure_occupancy=(pressure > EPS).mean(axis=0),
                  substantial_pressure_occupancy=(pressure > substantial_N).mean(axis=0),
                  any_pressure_total_occupancy=float(np.mean(np.sum(pressure, axis=1) > EPS)),
                  substantial_threshold_N=float(substantial_N))
    return result


def filter_step(filtered, measured, cutoff=100., dt=.005):
    return np.asarray(filtered, float)+(1.-np.exp(-cutoff*dt))*(np.asarray(measured, float)-filtered)


def first_at_or_after(times, target, max_lag=.001):
    t = np.asarray(times, float)
    index = int(np.searchsorted(t, float(target)-1e-9))
    if index >= len(t) or t[index] < target-1e-9 or t[index]-target > max_lag+1e-9:
        raise ValueError('Future query outside supported first-at-or-after1ms grid')
    return index


def quat_matrix(quat):
    w, x, y, z = np.asarray(quat, float)/np.linalg.norm(quat)
    return np.asarray([[1-2*(y*y+z*z), 2*(x*y-w*z), 2*(x*z+w*y)],
                       [2*(x*y+w*z), 1-2*(x*x+z*z), 2*(y*z-w*x)],
                       [2*(x*z-w*y), 2*(y*z+w*x), 1-2*(x*x+y*y)]])


def quat_multiply(a, b):
    w, x, y, z = a
    v, i, j, k = b
    return np.asarray([w*v-x*i-y*j-z*k, w*i+x*v+y*k-z*j,
                       w*j-x*k+y*v+z*i, w*k+x*j-y*i+z*v])


def extrapolate(qpos, qvel, horizon):
    q, v = np.asarray(qpos, float).copy(), np.asarray(qvel, float)
    h = float(horizon)
    q[:3] += h*v[:3]
    magnitude = float(np.linalg.norm(v[3:6]))
    half = .5*h*magnitude
    rotation = np.r_[math.cos(half), np.zeros(3) if magnitude == 0. else math.sin(half)*v[3:6]/magnitude]
    q[3:7] = quat_multiply(q[3:7], rotation)
    q[3:7] /= np.linalg.norm(q[3:7])
    q[7:10] += h*v[6:9]
    return q


def patch_axis(qpos):
    q = np.asarray(qpos)
    return quat_matrix(q[3:7])@np.asarray([np.cos(q[7]), 0., -np.sin(q[7])])


def margin(qpos, normal, name, radius=.12, gap=.01, polar_angle_deg=15.46600995):
    n = unit(normal)
    sign = 1. if name.endswith('A') else -1.
    signed = sign*float((-radius*n)@patch_axis(qpos))
    polar = radius*np.cos(np.deg2rad(polar_angle_deg))
    return min(signed-gap, polar-signed) if name.startswith('shell') else signed-polar


def material_velocity(qpos, qvel, point, name, belt_speed=0.):
    q, v, p = np.asarray(qpos, float), np.asarray(qvel, float), np.asarray(point, float)
    rotation = quat_matrix(q[3:7])
    shaft_axis = rotation[:, 1]
    angular = rotation@v[3:6]+v[6]*shaft_axis
    if name.startswith('shell'):
        angular += v[7 if name.endswith('A') else 8]*patch_axis(q)
    velocity = v[:3]+np.cross(angular, p-q[:3])
    if name.startswith('belt'):
        velocity += float(belt_speed)*shaft_axis
    return velocity


def predicted_residual(qpos, qvel, normal, target, radius=.12):
    q, v, n = np.asarray(qpos, float), np.asarray(qvel, float).copy(), unit(normal)
    name = target['name']
    belt = 0.
    if name.startswith('shell'):
        v[7 if name.endswith('A') else 8] = target['target_joint_speed_rad_s']
    else:
        belt = target['target_surface_speed_m_s']
    velocity = material_velocity(q, v, q[:3]-radius*n, name, belt)
    return velocity-n*(n@velocity)


def force_projection(force, normal, mass, gravity, disturbance=None):
    n, g = unit(normal), np.asarray(gravity, float)
    tangent_g = g-n*(n@g)
    down = unit(tangent_g)
    if not np.isfinite(down).all():
        return dict(valid=False, downhill_unit=np.full(3, np.nan))
    F = np.asarray(force, float)
    external = np.zeros(3) if disturbance is None else np.asarray(disturbance, float)[:3]
    return dict(valid=True, downhill_unit=down,
                contact_downhill_N=float(F@down),
                gravity_downhill_N=float((float(mass)*g)@down),
                disturbance_downhill_N=float(external@down),
                sampled_net_downhill_N=float((F+float(mass)*g+external)@down),
                contact_normal_N=float(F@n))


def stats(values):
    v = np.asarray([x for x in values if x is not None], float)
    v = v[np.isfinite(v)]
    if not len(v):
        return dict(count=0)
    return dict(count=int(len(v)), minimum=float(v.min()), maximum=float(v.max()),
                mean=float(v.mean()), rms=float(np.sqrt(np.mean(v*v))),
                median=float(np.median(v)))
