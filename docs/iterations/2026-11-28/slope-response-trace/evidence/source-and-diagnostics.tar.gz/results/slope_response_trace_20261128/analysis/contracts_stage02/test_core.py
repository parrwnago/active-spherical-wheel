"""Focused synthetic contracts for interval timing and independent geometry."""
import numpy as np
from core import (contact_reduction, interval_reduction, first_at_or_after,
                  filter_step, margin, extrapolate, material_velocity,
                  predicted_residual, force_projection, dominant, com_state,
                  bridge_qv)


def test_signed_force_keeps_nonpositive_and_rejected_rows():
    c = np.zeros((3,16)); c[:,0]=[0,2,4]; c[:,4:7]=[0,0,1]
    c[:,7:10]=[[1,0,2],[3,0,-1],[5,0,4]];c[:,12]=[1,1,0]
    r=contact_reduction(c,[0,0,0],[.1,0,0])
    np.testing.assert_array_equal(r['all_force'],[9,0,5])
    np.testing.assert_array_equal(r['admitted_force'],[4,0,1])
    np.testing.assert_array_equal(r['native_force'],[1,0,2])
    np.testing.assert_array_equal(r['pressure_by_family_N'],[2,0,0,0])
    np.testing.assert_array_equal(r['rejected_force'],[5,0,4])


def test_rim_pressure_folds_without_losing_raw_tag():
    c=np.zeros((2,16));c[:,0]=[0,4];c[:,4:7]=[0,0,1];c[:,9]=[2,3];c[:,12]=1
    r=contact_reduction(c,[0,0,0],[0,0,0])
    assert r['pressure_by_family_N'][0]==5
    assert r['pressure_by_tag_N'][0]==2 and r['pressure_by_tag_N'][4]==3


def test_interval_is_next_observer_and_retains_occupancy():
    samples=[]
    for j in range(5):
        c=np.zeros((1,16));c[0,0]=0 if j<4 else 2;c[0,6]=1;c[0,9]=2;c[0,12]=1
        r=contact_reduction(c,[0,0,0],[0,0,0]);r.update(substep_index=j+1,hold_index=10,time_s=.05+.001*(j+1));samples.append(r)
    r=interval_reduction(samples,1.)
    assert r['observer_source_row']==11
    np.testing.assert_allclose(r['pressure_by_family_N'],[1.6,0,.4,0])
    np.testing.assert_array_equal(r['pressure_last_family_N'],[0,0,2,0])
    np.testing.assert_allclose(r['substantial_pressure_occupancy'],[.8,0,.2,0])
    assert dominant(r['pressure_by_family_N'])==0 and dominant(r['pressure_last_family_N'])==2


def test_future_query_uses_first_after_not_nearest():
    times=np.asarray([1.001,1.002,1.003])
    assert first_at_or_after(times,1.0011)==1
    assert first_at_or_after(times,1.00200000000001)==1
    try:first_at_or_after(times,1.004)
    except ValueError:pass
    else:raise AssertionError('Expected missing future query rejection')


def test_filter_applies_completed_interval_once():
    r=filter_step(np.zeros(6),np.ones(6))
    np.testing.assert_allclose(r,np.full(6,1.-np.exp(-.5)),atol=0,rtol=0)


def test_geometry_and_material_velocity_axes():
    q=np.r_[0.,0.,0.,1.,0.,0.,0.,.3,0.,0.];v=np.zeros(9)
    np.testing.assert_allclose(margin(q,[0,0,1],'shell_A'),.12*np.sin(.3)-.01)
    v[7]=2.
    got=material_velocity(q,v,[0,0,-.12],'shell_A')
    np.testing.assert_allclose(got,[0.,.24*np.cos(.3),0.],atol=1e-15)
    np.testing.assert_allclose(material_velocity(q,np.zeros(9),[0,0,-.12],'belt_A',.2),[0,.2,0])


def test_extrapolation_body_rotation_and_residual_target():
    q=np.r_[0.,0.,0.,1.,0.,0.,0.,0.,0.,0.];v=np.zeros(9);v[3]=np.pi
    p=extrapolate(q,v,.5)
    np.testing.assert_allclose(p[3:7],[np.sqrt(.5),np.sqrt(.5),0,0],atol=1e-15)
    v[:]=0;v[0]=.2
    target={'name':'belt_A','target_surface_speed_m_s':-.3}
    np.testing.assert_allclose(predicted_residual(q,v,[0,0,1],target),[.2,-.3,0])


def test_force_projection_separates_gravity_contact():
    n=np.asarray([.6,0,.8]);g=np.asarray([0,0,-10.]);r=force_projection([-3.,0,4.],n,2.,g)
    np.testing.assert_allclose(r['downhill_unit'],[.8,0,-.6])
    np.testing.assert_allclose(r['contact_downhill_N'],-4.8)
    np.testing.assert_allclose(r['gravity_downhill_N'],12.)
    np.testing.assert_allclose(r['sampled_net_downhill_N'],7.2)


def test_com_velocity_includes_body_rotation_not_only_root():
    q=np.r_[1.,2.,3.,1.,0.,0.,0.,0.,0.,0.];v=np.zeros(9);v[4]=2.
    props={x:{'mass':1.,'inertial_pos':[0,0,0]} for x in ['fork','carrier','shell_A','shell_B']}
    props['fork']['inertial_pos']=[0,0,1]
    pos,vel=com_state(q,v,props)
    np.testing.assert_allclose(pos,[1,2,3.25]);np.testing.assert_allclose(vel,[.5,0,0])
    state=np.zeros(24);state[2:5]=q[:3];state[5]=1;state[12:15]=[0,2,0]
    gotq,gotv=bridge_qv(state)
    np.testing.assert_allclose(gotq,q);np.testing.assert_allclose(gotv,v)


if __name__=='__main__':
    tests=[(k,v) for k,v in sorted(globals().items()) if k.startswith('test_')]
    for name,test in tests:test()
    print(str(len(tests))+' focused synthetic contracts passed')
