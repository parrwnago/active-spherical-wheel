"""Independent I81 saved-array verification; no simulation/controller calls."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASELINE = ROOT / 'results/tangent_heading_routes_20261127/campaign/runs/eight_m100_N/precision.npz'
OLD_PROTOCOL = ROOT / 'results/tangent_heading_routes_20261127/protocol/protocol.json'
OLD_BASE = OLD_PROTOCOL.parent.parent
OLD_SEAL = OLD_BASE / 'campaign/outputs_sealed.json'
HELPER = ROOT / 'results/causal_replay_20261126/substep_trace.py'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def arrays(path):
    with np.load(path, allow_pickle=False) as source:
        return {key: source[key].copy() for key in source.files}


def matrix(quat):
    w, x, y, z = quat
    return np.array([[1-2*(y*y+z*z), 2*(x*y-w*z), 2*(x*z+w*y)],
                     [2*(x*y+w*z), 1-2*(x*x+z*z), 2*(y*z-w*x)],
                     [2*(x*z-w*y), 2*(y*z+w*x), 1-2*(x*x+y*y)]])


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    run, out = args.run.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    precision = run / 'child/campaign/runs/eight_m100_N/precision.npz'
    substeps = run / 'substeps.npz'
    metadata_path = run / 'diagnostic_metadata.json'
    paths = [Path(__file__).resolve(), BASELINE, OLD_PROTOCOL, OLD_SEAL, HELPER, precision, substeps, metadata_path]
    bound = {str(path.relative_to(ROOT)): sha(path) for path in paths}
    shutil.copyfile(Path(__file__), out / 'verify_core.py')
    save(out / 'registered_before_array_reads.json', {
        'iteration': 'I-81', 'utc': datetime.now(timezone.utc).isoformat(),
        'inputs_and_source': bound, 'no_new_physics': True,
        'checks': 'All79 precision fields/native guards, shortened terminal mask, trace clocks/held commands/state endpoints/contacts and full command ledgers.',
        'scope': 'Independent saved-array audit, not a new software suite or physical trial.'})
    assert sha(OLD_PROTOCOL) == '53106cdb758d76436e04b747c9483c4081abcc7ec1f2a163ace90b58b82085c2'
    protocol = json.loads(OLD_PROTOCOL.read_text())
    sealed = json.loads(OLD_SEAL.read_text())['files'][str(BASELINE.relative_to(OLD_BASE))]
    assert sha(BASELINE) == sealed['sha256'] and BASELINE.stat().st_size == sealed['bytes']
    for key in ['source_sha256', 'input_sha256']:
        for relative, expected in protocol[key].items():
            assert sha(ROOT / relative) == expected, relative
    old, p, s = arrays(BASELINE), arrays(precision), arrays(substeps)
    diagnostic = json.loads(metadata_path.read_text())
    assert diagnostic['native_run_returned'] is True
    assert diagnostic['command_preview_counts'] == {'native_commands': 20401, 'native_previews': 20401}
    assert diagnostic['controller_intervention'] is False
    assert set(p) == set(old) and len(p) == 79
    n = len(p['time_s'])
    assert n == 20401 and abs(p['time_s'][-1] - 102.) < 1e-8
    fields = []
    for key in old:
        expected = old[key][:n].copy()
        if key == 'command_held_after_row':
            expected[-1] = False
        okay = p[key].dtype == expected.dtype and p[key].shape == expected.shape and p[key].tobytes() == expected.tobytes()
        fields.append({'field': key, 'bit_exact': okay,
                       'shortened_final_held_mask': key == 'command_held_after_row'})
    assert all(row['bit_exact'] for row in fields)
    for key in ['native_feedback_boundary_verified', 'mirror_previous_applied_matches_physical', 'no_truth_or_terrain_read_during_command']:
        assert p[key].all(), key
    assert (p['native_observer_update_count'] == 1).all()
    assert np.array_equal(p['exact_previous_applied'][1:], p['exact_applied'][:-1])
    assert np.array_equal(p['exact_applied'], np.clip(p['exact_requested'], -p['exact_input_bounds'], p['exact_input_bounds']))
    lqr = -np.einsum('nij,nj->ni', p['exact_feedback_gain'], p['exact_error'])
    lqr_error = float(np.max(np.abs(lqr - p['exact_lqr_command'])))
    assert lqr_error < 1e-11
    requested = sum(p[key] for key in ['exact_equilibrium_command', 'exact_rolling_feedforward', 'exact_support_command', 'exact_lqr_command', 'exact_transition_command_delta', 'exact_heading_command', 'exact_fade_command_delta'])
    request_error = float(np.max(np.abs(requested - p['exact_requested'])))
    assert request_error < 1e-11
    assert not np.any(p['exact_heading_command'])
    assert not np.any(p['exact_feedback_reference_qvel'][:, 3:6])
    holds = np.arange(20100, 20360)
    assert len(s['time_s']) == 1300 and s['hold_completed'].all()
    assert np.array_equal(s['hold_index'], np.repeat(holds, 5))
    assert np.array_equal(s['substep_index'], np.tile(np.arange(1, 6), len(holds)))
    assert np.array_equal(s['held_input'], p['exact_applied'][s['hold_index']])
    assert not np.any(s['disturbance_world'])
    assert np.max(np.abs(s['time_s'] - (p['time_s'][s['hold_index']] + s['substep_index']*.001))) < 1e-10
    metadata = json.loads(str(s['metadata_json']))
    assert metadata['completed_holds'] == 260 and metadata['failed_holds'] == 0
    assert metadata['helper_sha256'] == sha(HELPER)
    assert metadata['window_start_s'] == 100.5 and metadata['window_end_s'] == 101.8
    assert metadata['physics_dt_s'] == .001 and metadata['control_dt_s'] == .005
    assert np.array_equal(s['contact_offsets'], np.r_[0, np.cumsum(np.diff(s['contact_offsets']))])
    assert len(s['contact_offsets']) == 1301 and s['contact_offsets'][-1] == len(s['contact_rows'])
    assert (np.diff(s['contact_offsets']) >= 0).all()
    assert s['contact_rows'].shape[1] == 16 and np.isfinite(s['contact_rows']).all()
    assert np.equal(s['contact_rows'][:, 0], np.round(s['contact_rows'][:, 0])).all()
    assert np.array_equal(s['contact_tags'], s['contact_rows'][:, 0].astype(np.int64))
    assert np.array_equal(s['contact_admitted'], s['contact_rows'][:, 12] >= .5)
    assert ((s['contact_tags'] >= 0) & (s['contact_tags'] <= 6)).all()
    assert np.array_equal(s['bridge_state_before'][1:], s['bridge_state'][:-1])
    assert np.max(np.abs(s['bridge_state'][:, 0] - s['bridge_state_before'][:, 0] - .001)) < 1e-8
    assert (s['bridge_state'][:, 1] - s['bridge_state_before'][:, 1] == 1).all()
    assert np.array_equal(s['bridge_state'][:, 22], s['bridge_state_before'][:, 22])
    assert not np.any(s['bridge_state'][:, 23])
    q_errors, v_errors = [], []
    for j in np.arange(4, 1300, 5):
        state = s['bridge_state'][j]
        quat = state[5:9] / np.linalg.norm(state[5:9])
        q = np.r_[state[2:5], quat, state[15:18]]
        v = np.r_[state[9:12], matrix(quat).T @ state[12:15], state[18:21]]
        row = int(s['hold_index'][j]) + 1
        q_errors.append(float(np.max(np.abs(q - p['exact_qpos'][row]))))
        v_errors.append(float(np.max(np.abs(v - p['exact_qvel'][row]))))
    assert max(q_errors) < 1e-12 and max(v_errors) < 1e-12
    assert all(sha(ROOT / name) == expected for name, expected in bound.items())
    save(out / 'report.json', {'iteration': 'I-81', 'passed': True,
        'precision_rows': n, 'precision_fields': fields, 'trace_substeps': 1300,
        'completed_holds': 260, 'trace_first_s': float(s['time_s'][0]),
        'trace_last_s': float(s['time_s'][-1]), 'bridge_qpos_endpoint_max_error': max(q_errors),
        'bridge_qvel_endpoint_max_error': max(v_errors), 'lqr_ledger_max_error': lqr_error,
        'requested_ledger_max_error': request_error, 'inputs_unchanged': True,
        'no_new_physics': True, 'full_route_completion_claim': False,
        'scope': 'One shortened native replay; exported force samples do not constitute exact solver impulse or causality proof.'})
    save(out / 'artifact_manifest.json', {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
         for p in sorted(out.iterdir()) if p.is_file()}})
    print(json.dumps({'passed': True, 'precision_rows': n, 'precision_fields': len(fields),
                      'substeps': 1300, 'completed_holds': 260}))


if __name__ == '__main__':
    main()
