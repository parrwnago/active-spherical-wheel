"""Freeze one unchanged-native diagnostic before any I81 physics."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
OLD = ROOT / 'results/tangent_heading_routes_20261127'
SETTINGS = dict(case_id='eight_m100_N', physical_stop_s=102.,
                nominal_route_stop_s=133., capture_window_s=[100.5, 101.8],
                focus_anchor_window_s=[100.75, 101.65], physics_dt_s=.001,
                control_dt_s=.005, expected_substeps=1300,
                expected_holds=260, expected_preview_rows=261,
                expected_precision_rows=20401, preview_horizon_s=.12)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    out = args.output.resolve()
    if out.exists():
        raise FileExistsError(out)
    old_path = OLD / 'protocol/protocol.json'
    assert sha(old_path) == '53106cdb758d76436e04b747c9483c4081abcc7ec1f2a163ace90b58b82085c2'
    old = json.loads(old_path.read_text())
    sources = {name: expected for name, expected in old['source_sha256'].items()}
    inputs = dict(old['input_sha256'])
    for group in [sources, inputs]:
        for name, expected in group.items():
            assert sha(ROOT / name) == expected, name
    own = [Path(__file__).resolve(), ROOT / 'results/causal_replay_20261126/substep_trace.py']
    for folder in ['runner', 'analysis', 'verification']:
        files = sorted((BASE / folder).glob('*.py'))
        assert files, 'Missing component sources: ' + folder
        own.extend(files)
        for path in sorted((BASE / folder).glob('*.json')):
            inputs[str(path.relative_to(ROOT))] = sha(path)
    for path in own:
        sources[str(path.relative_to(ROOT))] = sha(path)
    for path in [old_path, OLD / 'campaign/outputs_sealed.json',
                 OLD / 'campaign/runs/eight_m100_N/precision.npz',
                 OLD / 'campaign/runs/eight_m100_N/rollout.npz',
                 OLD / 'campaign/_workspaces/eight_m100_N/mirror/model.xml']:
        inputs[str(path.relative_to(ROOT))] = sha(path)
    seal = json.loads((OLD / 'campaign/outputs_sealed.json').read_text())
    for name in ['precision.npz', 'rollout.npz']:
        relative = 'campaign/runs/eight_m100_N/' + name
        assert seal['files'][relative]['sha256'] == sha(OLD / relative)
    runner_settings = BASE / 'runner/settings.json'
    if runner_settings.exists():
        assert json.loads(runner_settings.read_text()) == SETTINGS
    protocol = dict(iteration='I-81', registered_before_physics_utc=datetime.now(timezone.utc).isoformat(),
        source_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        question='Which physical contact/interval wrench, inferred support, incoming preparation, balance reference and limited corrective commands precede the native downhill acceleration?',
        runner_settings=SETTINGS, source_sha256=sources, input_sha256=inputs,
        original_protocol_path=str(old_path.relative_to(ROOT)), original_protocol_sha256=sha(old_path),
        original_output_seal_sha256=sha(OLD / 'campaign/outputs_sealed.json'),
        gain_cache=old['gain_cache'], bridge_binary_sha256=old['bridge_binary_sha256'],
        exact_physics_binary_sha256=old['exact_physics_binary_sha256'],
        parameters=old['parameters'], input_bounds=[1.5, .6, .6, .3, .3],
        controller_intervention=False, default_changed=False, nominal_full_route_s=133.,
        fixture='Original I76 eight rough stress outside original moderate-terrain screen; preserve classification.',
        measurement_boundary='Live control uses exact simulated q/v, previous actual input, momentum observer and known geometry only. Physical contacts/terrain are evaluation-only.',
        parity_gate='All79 precision fields byteexact20401rows through102s; only final command_held_after_row isfalse because diagnostic stops. No inferencebeforeparity.',
        simulation_scope='One new shortened originalnative prefix fromreset, not restorestate or fullroute/completion/acceptance test.',
        interpretation_limits=[
            'Predicted geometric exposure is not a force-onset prediction.',
            'Preview actual tangential velocity fields are model/inferred-point quantities, not independent physical surface-velocity measurements.',
            'Prior interval pressure, instantaneous current pressure, inferred filtered wrench and later normalfilter are different observables.',
            'Current emitted command acts after recorded state; saturation may react to existing motion.',
            'A clipped dynamic correction doesnot establish static slope capacity or gravity-only cause.',
            'One unchanged trace can identify timing and algebraic sources but cannot alone establish a causal controller improvement.'
        ], no_outcome_tuning=True, no_automatic_adoption=True)
    out.mkdir(parents=True)
    for name in sources:
        dest = out / 'source' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
        assert sha(dest) == sources[name]
    with (out / 'protocol.json').open('x') as f:
        json.dump(protocol, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')
    print(json.dumps({'protocol': str((out / 'protocol.json').relative_to(ROOT)),
                      'sha256': sha(out / 'protocol.json'),
                      'source_count': len(sources), 'input_count': len(inputs),
                      'physics_started': False}))


if __name__ == '__main__':
    main()
