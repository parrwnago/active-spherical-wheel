"""Independent physical interval, routing and whole-robot COM diagnostics.

MuJoCo is used only for private kinematics/subtree velocity on recorded poses;
no mj_step/mj_forward, contacts, controller or observer is run.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import numpy as np
import mujoco

ROOT = Path(__file__).resolve().parents[4]
MODEL = ROOT/'results/tangent_heading_routes_20261127/campaign/_workspaces/eight_m100_N/mirror/model.xml'
FAMILIES = ['shell_A', 'shell_B', 'belt_A', 'belt_B']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean(value):
    if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)): return [clean(v) for v in value]
    if isinstance(value, np.ndarray): return clean(value.tolist())
    if isinstance(value, np.generic): return clean(value.item())
    if isinstance(value, float) and not np.isfinite(value): return None
    return value


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(clean(value), f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def unit(v):
    v = np.asarray(v)
    norm = np.linalg.norm(v)
    return v/norm if norm > 1e-12 else np.full(v.shape, np.nan)


def intrinsic(wrench):
    f, m = wrench[:3], wrench[3:]
    ff = float(f@f)
    if ff < 1e-12: return np.full(3, np.nan)
    a = -np.cross(f, m)/(.12*ff)
    aa = float(a@a)
    return unit(a if aa >= 1 else a + np.sqrt(1-aa)*unit(f))


def angle(a, b):
    return np.degrees(np.arccos(np.clip(unit(a)@unit(b), -1., 1.)))


def rotation(q):
    w, x, y, z = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-w*z), 2*(x*z+w*y)],
                     [2*(x*y+w*z), 1-2*(x*x+z*z), 2*(y*z-w*x)],
                     [2*(x*z-w*y), 2*(y*z+w*x), 1-2*(x*x+y*y)]])


def qv(state):
    q = np.r_[state[2:9], state[15:18]]
    q[3:7] /= np.linalg.norm(q[3:7])
    v = np.r_[state[9:12], rotation(q[3:7]).T@state[12:15], state[18:21]]
    return q, v


def com(model, data, state):
    q, v = qv(state)
    data.qpos[:], data.qvel[:] = q, v
    mujoco.mj_kinematics(model, data)
    mujoco.mj_comPos(model, data)
    mujoco.mj_comVel(model, data)
    mujoco.mj_subtreeVel(model, data)
    return data.subtree_com[0].copy(), data.subtree_linvel[0].copy()


def stats(values):
    a = np.asarray(values, float)
    return {'count': len(a), 'max_abs': float(np.max(np.abs(a))),
            'rms': float(np.sqrt(np.mean(a*a))), 'mean': float(np.mean(a))}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    run, out = args.run.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    pp = run/'child/campaign/runs/eight_m100_N/precision.npz'
    sp = run/'substeps.npz'
    paths = [Path(__file__).resolve(), MODEL, pp, sp]
    bound = {str(p.relative_to(ROOT)): sha(p) for p in paths}
    shutil.copyfile(Path(__file__), out/'verify_intervals.py')
    save(out/'registered_before_array_reads.json', {
        'iteration': 'I-81', 'utc': datetime.now(timezone.utc).isoformat(), 'inputs_and_source': bound,
        'scope': 'New separately bound post-run verification source; no arrays read before registration. No simulation.',
        'interval': 'Five completed1ms samples, all signed forces and pre-solve-centre moments, compare next5ms observer row.',
        'COM_reference': 'Independent private MuJoCo kinematics/comVel/subtreeVel on raw bridge state; no dynamics or model stepping.',
        'filter': '100rad/s exponential filter seeded once from native at100.5s; no fitted constants/delay.',
        'selected_times_s': [100.75, 100.8, 100.835, 100.9, 101., 101.495, 101.5, 101.505, 101.51, 101.515, 101.55, 101.65],
        'limitation': 'Force samples are not exact impulses; force balance does not independently attribute actuator work or physical causality.'})
    with np.load(pp, allow_pickle=False) as z: p = {k: z[k].copy() for k in z.files}
    with np.load(sp, allow_pickle=False) as z: s = {k: z[k].copy() for k in z.files}
    assert len(s['time_s']) == 1300
    model = mujoco.MjModel.from_xml_path(str(MODEL)); data = mujoco.MjData(model)
    total_mass = float(np.sum(model.body_mass)); gravity = model.opt.gravity.copy()
    names = [mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, i) for i in range(model.nbody)]
    assert names == ['world', 'fork', 'carrier', 'shell_A', 'shell_B']
    assert np.array_equal(model.body_parentid, [0, 0, 1, 2, 2])
    assert not np.any(model.body_pos[2:])
    assert np.array_equal(model.body_quat[1:], np.tile([1., 0., 0., 0.], (4, 1)))
    assert np.array_equal(model.jnt_axis[1:], [[0., 1., 0.], [1., 0., 0.], [1., 0., 0.]])
    assert not np.any(model.dof_damping[:6]) and not np.any(model.dof_frictionloss[:6])
    assert not np.any(model.body_gravcomp)
    assert model.opt.viscosity == 0 and model.opt.density == 0
    passive_scope = {'free_joint_damping': model.dof_damping[:6].copy(),
                     'free_joint_frictionloss': model.dof_frictionloss[:6].copy(),
                     'body_gravity_compensation': model.body_gravcomp.copy(),
                     'fluid_viscosity': float(model.opt.viscosity), 'fluid_density': float(model.opt.density),
                     'qualification': 'Checked free-joint damping/friction, gravity compensation and fluid terms are zero. Internal joint damping does not provide net external COM force.'}
    filtered = p['exact_observer_wrench'][20100].copy()
    intervals = []
    sub_com_pre, sub_com_post = [], []
    for j in range(1300):
        sub_com_pre.append(com(model, data, s['bridge_state_before'][j]))
        sub_com_post.append(com(model, data, s['bridge_state'][j]))
    for hold in range(20100, 20360):
        ids = np.flatnonzero(s['hold_index'] == hold)
        assert len(ids) == 5 and np.array_equal(s['substep_index'][ids], np.arange(1, 6))
        forces = {'all': [], 'admitted': [], 'native': []}; moments = {k: [] for k in forces}
        pressures, normal_sums = [], []
        for j in ids:
            c = s['contact_rows'][s['contact_offsets'][j]:s['contact_offsets'][j+1]]
            fn = np.sum(c[:, 4:7]*c[:, 7:10], axis=1)
            tags = c[:, 0].astype(int)
            admitted = c[:, 12] >= .5
            native = admitted & ((c[:, 10] > 0) | (fn > 0))
            positive = admitted & (fn > 1e-9)
            masks = {'all': np.ones(len(c), dtype=bool), 'admitted': admitted, 'native': native}
            for name, mask in masks.items():
                forces[name].append(np.sum(c[mask, 7:10], axis=0))
                moments[name].append(np.sum(np.cross(c[mask, 1:4]-s['bridge_state_before'][j, 2:5], c[mask, 7:10]), axis=0))
            family_tags = [{0, 4}, {1, 5}, {2}, {3}]
            pressures.append(np.array([np.sum(fn[positive & np.isin(tags, list(ks))]) for ks in family_tags]))
            normal_sums.append(np.sum(fn[positive, None]*c[positive, 4:7], axis=0))
        f = {k: np.mean(v, axis=0) for k, v in forces.items()}
        m = {k: np.mean(v, axis=0) for k, v in moments.items()}
        W = np.r_[f['all'], m['all']]
        filtered += (1-np.exp(-.5))*(W-filtered)
        i = hold+1; pressure = np.asarray(pressures)
        mean = pressure.mean(axis=0); last = pressure[-1]
        inferred = p['exact_estimated_support_loads_N'][i]
        dominant = lambda v: int(np.argmax(v)) if np.sum(v) > 1e-9 else -1
        com_v0 = sub_com_pre[ids[0]][1]; com_v1 = sub_com_post[ids[-1]][1]
        momentum_rate = total_mass*(com_v1-com_v0)/.005
        external = s['disturbance_world'][ids].mean(axis=0)[:3]
        normal = unit(np.sum(normal_sums, axis=0))
        down = unit(gravity-normal*(normal@gravity))
        intervals.append({'time_s': float(p['time_s'][i]), 'source_row': i, 'hold_index': hold,
            'physical_interval_wrench': W, 'observer_interval_wrench': p['exact_observer_interval_mean'][i, :6],
            'physical_filtered_wrench': filtered.copy(), 'observer_filtered_wrench': p['exact_observer_wrench'][i],
            'force_error_N': float(np.linalg.norm(W[:3]-p['exact_observer_interval_mean'][i, :3])),
            'moment_error_Nm': float(np.linalg.norm(W[3:]-p['exact_observer_interval_mean'][i, 3:6])),
            'filtered_intrinsic_angle_deg': float(angle(intrinsic(filtered), intrinsic(p['exact_observer_wrench'][i]))),
            'pressure_mean_family_N': mean, 'pressure_last_family_N': last,
            'inferred_family_N': inferred, 'dominant_mean_family': dominant(mean),
            'dominant_last_family': dominant(last), 'dominant_inferred_family': dominant(inferred),
            'substantial_occupancy': np.mean(pressure > max(.05, .05*total_mass*np.linalg.norm(gravity)), axis=0),
            'COM_velocity_before': com_v0, 'COM_velocity_after': com_v1,
            'COM_momentum_rate_N': momentum_rate,
            'force_balance_residual_N': {k: momentum_rate-(v+total_mass*gravity+external) for k,v in f.items()},
            'signed_forces_N': f, 'pressure_normal': normal, 'downhill_unit': down,
            'gravity_downhill_N': float((total_mass*gravity)@down),
            'all_contact_downhill_N': float(f['all']@down),
            'all_plus_gravity_downhill_N': float((f['all']+total_mass*gravity+external)@down),
            'prior_held_input': p['exact_previous_applied'][i],
            'current_requested': p['exact_requested'][i], 'current_applied': p['exact_applied'][i]})
    focused = [x for x in intervals if 100.75-1e-9 <= x['time_s'] <= 101.65+1e-9]
    assert len(intervals) == 260 and len(focused) == 181
    summarize = lambda rows: {
        'rows': len(rows), 'interval_force_error_N': stats([x['force_error_N'] for x in rows]),
        'interval_moment_error_Nm': stats([x['moment_error_Nm'] for x in rows]),
        'filtered_intrinsic_angle_deg': stats([x['filtered_intrinsic_angle_deg'] for x in rows]),
        'last_vs_inferred_disagreements': sum(x['dominant_last_family'] != x['dominant_inferred_family'] for x in rows),
        'mean_vs_inferred_disagreements': sum(x['dominant_mean_family'] != x['dominant_inferred_family'] for x in rows),
        'COM_force_balance_residual_norm_N': {k: stats([np.linalg.norm(x['force_balance_residual_N'][k]) for x in rows]) for k in forces}}
    selected = [min(intervals, key=lambda x: abs(x['time_s']-t)) for t in
                [100.75, 100.8, 100.835, 100.9, 101., 101.495, 101.5, 101.505, 101.51, 101.515, 101.55, 101.65]]
    assert all(sha(ROOT/name) == h for name,h in bound.items())
    save(out/'report.json', {'iteration': 'I-81', 'no_new_physics': True, 'total_mass_kg': total_mass,
        'gravity_m_s2': gravity, 'mujoco_version': mujoco.__version__, 'all_intervals': summarize(intervals),
        'model_topology': {'bodies': names, 'body_parentid': model.body_parentid,
                           'body_pos': model.body_pos, 'body_quat': model.body_quat,
                           'joint_axes': model.jnt_axis}, 'passive_force_scope': passive_scope,
        'focus_intervals': summarize(focused), 'selected_rows': selected, 'rows': intervals,
        'COM_substep_pre_position_m': np.asarray([x[0] for x in sub_com_pre]),
        'COM_substep_pre_velocity_m_s': np.asarray([x[1] for x in sub_com_pre]),
        'COM_substep_post_position_m': np.asarray([x[0] for x in sub_com_post]),
        'COM_substep_post_velocity_m_s': np.asarray([x[1] for x in sub_com_post]),
        'inputs_unchanged': True,
        'qualification': 'Independent saved-data kinematic and sampled-force audit. Signed contact forces include all exported rows; no motor/gravity work or causal treatment.'})
    save(out/'artifact_manifest.json', {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(out.iterdir()) if p.is_file()}})
    print(json.dumps(clean({'intervals': len(intervals), 'focus': len(focused), 'summary': summarize(focused)})))


if __name__ == '__main__':
    main()
