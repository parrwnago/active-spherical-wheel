"""Private random-state kinematic crosscheck only; no case arrays or physics."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import shutil
import numpy as np
import mujoco
from core import com_state, extrapolate, margin, predicted_residual, unit
from analyze_stage01 import model_properties
from spherical_wheel.synchronization import ContactSynchronizer

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    out=HERE/'kinematic_validation_stage01';out.mkdir(exist_ok=False)
    modelpath=ROOT/'results/tangent_heading_routes_20261127/campaign/_workspaces/eight_m100_N/mirror/model.xml'
    paths=[Path(__file__),HERE/'core.py',HERE/'analyze_stage01.py',modelpath,
           ROOT/'src/spherical_wheel/synchronization.py']
    bindings={str(p.relative_to(ROOT)):sha(p) for p in paths}
    for p in paths[:3]:shutil.copyfile(p,out/p.name)
    (out/'registered_before_kinematics.json').write_text(json.dumps({'iteration':'I-81','inputs':bindings,'case_arrays_read':False,'physics_run':False,'seed':381,'states':16},indent=2)+'\n')
    props,_=model_properties(modelpath);model=mujoco.MjModel.from_xml_path(str(modelpath));data=mujoco.MjData(model)
    plant=SimpleNamespace(model=model,data=data,bounds=np.array([1.5,.6,.6,.3,.3]),last_input=np.zeros(5))
    sync=ContactSynchronizer(plant);rng=np.random.default_rng(381)
    errors={'com_position':[],'com_velocity':[],'current_margin':[],'future_margin':[],'prepared_velocity':[]}
    for _ in range(16):
        q=np.r_[rng.normal(size=3),unit(rng.normal(size=4)),rng.normal(size=3)]
        v=rng.normal(size=9);data.qpos[:]=q;data.qvel[:]=v
        mujoco.mj_kinematics(model,data);mujoco.mj_comPos(model,data);mujoco.mj_comVel(model,data);mujoco.mj_subtreeVel(model,data)
        cp,cv=com_state(q,v,props)
        errors['com_position'].append(float(np.max(np.abs(cp-data.subtree_com[0]))))
        errors['com_velocity'].append(float(np.max(np.abs(cv-data.subtree_linvel[0]))))
        n=unit(np.r_[rng.normal(scale=.1,size=2),1.]);point=q[:3]-.12*n
        preview=sync.preview(np.zeros(5),records=[],ground=(point,n))
        for target in preview['targets']:
            p=extrapolate(q,v,target['lookahead_s'])
            errors['current_margin'].append(abs(margin(q,n,target['name'])-target['current_patch_margin_m']))
            errors['future_margin'].append(abs(margin(p,n,target['name'])-target['predicted_patch_margin_m']))
            errors['prepared_velocity'].append(float(np.max(np.abs(predicted_residual(p,v,n,target)-target['predicted_matched_tangential_velocity_m_s']))))
    maximum={k:max(v) for k,v in errors.items()}
    passed=all(v<=1e-9 for v in maximum.values())
    report={'iteration':'I-81','passed':passed,'random_kinematic_states':16,'case_arrays_read':False,
            'physics_steps':0,'maximum_absolute_residual':maximum,
            'scope':'Analytic whole-COM and original virtual-preview geometry against private MuJoCo kinematics only; not case metrics or simulation.'}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    assert all(sha(ROOT/p)==h for p,h in bindings.items())
    (out/'manifest.json').write_text(json.dumps({'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file()}},indent=2)+'\n')
    print(json.dumps(report));assert passed


if __name__=='__main__':main()
