"""Explicit posthoc I81 pulse/held-command supplement; no new physics.

This adds parent-requested diagnostics after the canonical analysis closed.
It does not modify prephysics definitions, original metrics or controller.
"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import numpy as np
from core import clean, EPS, stats

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
BLOCKS={'XY_position':(0,2),'height':(2,3),'roll_pitch':(3,5),'yaw_position':(5,6),
        'shaft_position':(6,7),'shell_position':(7,9),'body_linear_velocity':(9,12),
        'body_angular_velocity':(12,15),'shaft_velocity':(15,16),'shell_velocity':(16,18)}


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p,x):
    with Path(p).open('x') as f:json.dump(clean(x),f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')


def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}


def command_row(p,i):
    K,e=p['exact_feedback_gain'][i],p['exact_error'][i]
    blocks={name:-K[:,lo:hi]@e[lo:hi] for name,(lo,hi) in BLOCKS.items()}
    summed=np.sum(list(blocks.values()),axis=0)
    if not np.allclose(summed,p['exact_lqr_command'][i],atol=1e-12,rtol=1e-12):raise AssertionError('LQR block sum does not close')
    return dict(time_s=float(p['time_s'][i]),source_row=i,
        qpos=p['exact_qpos'][i],qvel=p['exact_qvel'][i],
        estimated_normal=p['exact_estimated_normal'][i],
        inferred_loads_N=p['exact_estimated_support_loads_N'][i],
        requested_input=p['exact_requested'][i],applied_input=p['exact_applied'][i],
        sync_weights=p['exact_sync_weights'][i],
        equilibrium_command=p['exact_equilibrium_command'][i],
        rolling_feedforward=p['exact_rolling_feedforward'][i],support_command=p['exact_support_command'][i],
        lqr_command=p['exact_lqr_command'][i],transition_command_delta=p['exact_transition_command_delta'][i],
        heading_command=p['exact_heading_command'][i],fade_command_delta=p['exact_fade_command_delta'][i],
        lqr_blocks=blocks,feedback_reference_joint_rate=p['exact_feedback_reference_qvel'][i,6:9])


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--run',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    run=args.run.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    inputs=[run/'substeps.npz',run/'child/campaign/runs/eight_m100_N/precision.npz',
            HERE/'completed_stage01/interval_rows.json',HERE/'completed_stage01/report.json',HERE/'definitions.json',HERE/'core.py',Path(__file__)]
    bindings={str(p.relative_to(ROOT)):sha(p) for p in inputs}
    shutil.copyfile(Path(__file__),out/'pulse_ledger.py')
    save(out/'registered_before_new_reductions.json',dict(iteration='I-81',utc=datetime.now(timezone.utc).isoformat(),
        scope='Explicit new posthoc diagnostic, requested after main results. No revised prephysics gates/definitions or controller.',
        inputs=bindings,focus_held_command_anchor_window_s=[100.75,101.65],
        selected_times_s=json.loads((HERE/'definitions.json').read_text())['selected_snapshot_times_s'],
        requested_diagnostics=['Past held-command and completed physical load occupancy; current request separately.',
            'LQR18-state algebraic block decomposition at fixed selected rows.',
            'Integral of contact projection onto changing downhill tangent is descriptive, not fixed-world momentum.',
            'World-vector force impulse compared with whole-COM momentum change.'],
        belt_occupancy_rule='For actual held command interval, classify positive belt pressure in0/1..4/5 captured solves. Also record native-contact presence and raw force to avoid equating zero pressure to no contact.',
        shell_reaction_caveat='An unloaded shell torque can still affect the platform by reaction; do not call it ineffective.',
        no_new_physics=True,no_causal_intervention=True))
    s,p=load(inputs[0]),load(inputs[1]);intervals=json.loads(inputs[2].read_text());canonical=json.loads(inputs[3].read_text())
    byhold={x['hold_index']:x for x in intervals};selected=[]
    for t in json.loads((HERE/'definitions.json').read_text())['selected_snapshot_times_s']:
        i=int(round(t/.005));h=i-1
        if h not in byhold:
            selected.append(dict(requested_time_s=t,aligned_interval_available=False));continue
        row=byhold[h]
        selected.append(dict(interval_end_time_s=row['time_s'],held_command=command_row(p,h),
            newly_emitted_command=command_row(p,i),
            pressure_mean_N=row['pressure_by_family_N'],pressure_last_N=row['pressure_last_family_N'],
            pressure_occupancy=row['any_pressure_occupancy'],substantial_occupancy=row['substantial_pressure_occupancy'],
            projection=row['sampled_force_projection'],COM_required_force_N=row['COM_required_force_N'],
            COM_velocity_before=row['COM_velocity_before'],COM_velocity_after=row['COM_velocity_after'],
            target_up_rate_deg_s=row['target_up_rate_deg_s'],own_target_up_error_deg=row['own_target_up_error_deg'],
            inferred_vs_current_last=row['inferred_matches_current_last'],inferred_vs_completed_interval=row['inferred_matches_completed_interval']))
    occupancy=[]
    for hold,row in sorted(byhold.items()):
        start=float(p['time_s'][hold])
        if not 100.75-1e-9<=start<=101.65+1e-9:continue
        ids=np.flatnonzero(s['hold_index']==hold)
        if len(ids)!=5:raise AssertionError('Expected five captured physical samples per held command')
        for side,family,channel in [('A',2,3),('B',3,4)]:
            pressure=[];native_presence=[];force=[]
            for j in ids:
                c=s['contact_rows'][s['contact_offsets'][j]:s['contact_offsets'][j+1]]
                tag=c[:,0].astype(int);fn=np.einsum('ij,ij->i',c[:,4:7],c[:,7:10]);mask=(tag==family)&(c[:,12]>=.5)
                pressure.append(float(fn[mask&(fn>EPS)].sum()))
                native_presence.append(bool(np.any(mask&((c[:,10]>0.)|(fn>0.)))))
                force.append(c[mask,7:10].sum(axis=0))
            positive=int(np.sum(np.asarray(pressure)>EPS));category='none' if positive==0 else 'all_five' if positive==5 else 'partial'
            applied=float(p['exact_applied'][hold,channel]);requested=float(p['exact_requested'][hold,channel]);active=abs(applied)>1e-12
            occupancy.append(dict(hold_index=hold,command_time_s=start,interval_end_time_s=row['time_s'],side=side,
                actual_held_belt_speed_m_s=applied,requested_belt_speed_m_s=requested,nonzero_applied=active,
                command_clipped=abs(requested-applied)>1e-12,positive_pressure_samples=positive,
                positive_pressure_occupancy_category=category,native_contact_samples=sum(native_presence),
                raw_admitted_belt_force_mean_N=np.mean(force,axis=0),pressure_mean_N=float(np.mean(pressure)),
                sampled_contact_downhill_N=row['sampled_force_projection']['contact_downhill_N'],
                sampled_net_downhill_N=row['sampled_force_projection']['sampled_net_downhill_N']))
    counts={}
    for side in ['A','B']:
        arm=[x for x in occupancy if x['side']==side]
        counts[side]={'held_intervals':len(arm)}
        for condition in ['nonzero_applied','command_clipped']:
            selected_arm=[x for x in arm if x[condition]]
            counts[side][condition]={category:sum(x['positive_pressure_occupancy_category']==category for x in selected_arm) for category in ['none','partial','all_five']}
            counts[side][condition]['total']=len(selected_arm)
        zero=[x for x in arm if x['nonzero_applied'] and x['positive_pressure_samples']==0]
        counts[side]['nonzero_no_pressure_native_contact_samples']=sum(x['native_contact_samples'] for x in zero)
        counts[side]['nonzero_no_pressure_max_mean_force_norm_N']=max([float(np.linalg.norm(x['raw_admitted_belt_force_mean_N'])) for x in zero],default=0.)
    mass=canonical['model']['total_mass_kg'];gravity=np.asarray(canonical['model']['gravity_m_s2'])
    def impulse(rows):
        contact=np.sum([np.asarray(x['all_force'])*.005 for x in rows],axis=0)
        gravity_impulse=mass*gravity*(.005*len(rows))
        actual_momentum=mass*(np.asarray(rows[-1]['COM_velocity_after'])-rows[0]['COM_velocity_before'])
        varying_down_contact=sum(x['sampled_force_projection']['contact_downhill_N']*.005 for x in rows)
        varying_down_gravity=sum(x['sampled_force_projection']['gravity_downhill_N']*.005 for x in rows)
        return dict(intervals=len(rows),first_hold_start_s=float(rows[0]['time_s']-.005),last_hold_end_s=rows[-1]['time_s'],
            contact_impulse_world_N_s=contact,gravity_impulse_world_N_s=gravity_impulse,
            sampled_total_impulse_world_N_s=contact+gravity_impulse,COM_momentum_change_world_N_s=actual_momentum,
            vector_closure_residual_N_s=contact+gravity_impulse-actual_momentum,
            integral_contact_along_changing_downhill_N_s=varying_down_contact,
            integral_gravity_along_changing_downhill_N_s=varying_down_gravity,
            changing_direction_integrals_are_not_fixed_world_momentum=True)
    focusheld=[x for x in intervals if100.75-1e-9<=x['time_s']-.005<=101.65+1e-9]
    focusend=[x for x in intervals if100.75-1e-9<=x['time_s']<=101.65+1e-9]
    if len(focusheld)!=181 or len(focusend)!=181:raise AssertionError('Focus denominator differs from declared181')
    report=dict(iteration='I-81',scope='Explicit posthoc pulse/held-command supplement; no original definition/gate changes or new physics.',
        selected_rows=selected,held_belt_occupancy=counts,
        whole_capture_impulse=impulse(intervals),focus_held_anchor_impulse=impulse(focusheld),
        focus_interval_end_impulse=impulse(focusend),
        focus_interval_end_statistics={key:stats([x[key] for x in focusend]) for key in ['interval_force_error_N','interval_moment_error_Nm','observer_vs_filtered_physical_normal_deg']},
        current_command_after_state=True,gravity_vs_motor_causal_partition_claim=False,
        qualification='Contact projection can reinforce downhill gravity, but this does not partition motor action, passive rolling or impacts. Belt pressure occupancy is measured during the prior held command, not at the later observer sample.')
    save(out/'report.json',report);save(out/'held_belt_rows.json',occupancy)
    for path,h in bindings.items():assert sha(ROOT/path)==h
    save(out/'manifest.json',dict(source_inputs_unchanged=True,files={q.name:dict(bytes=q.stat().st_size,sha256=sha(q)) for q in out.iterdir() if q.is_file()}))
    print(json.dumps(clean(dict(held_belt_occupancy=counts,whole_capture_impulse=report['whole_capture_impulse'],focus_interval_end_statistics=report['focus_interval_end_statistics']))),flush=True)


if __name__=='__main__':main()
