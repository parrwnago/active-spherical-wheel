"""Package CLOSED I81 evidence; never runs physics or changes trial artifacts."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import io
import json
import tarfile
import traceback

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
ASSET_EXTENSIONS = {'.obj', '.stl', '.mtl', '.png', '.jpg', '.jpeg', '.tif', '.tiff', '.mjb'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()


def write_new(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encode(value))


def relative_file(root, path):
    path = Path(path)
    if path.is_symlink():
        raise ValueError('Archive inputs must be regular captured files, not symlinks: '+str(path))
    relative = path.resolve().relative_to(Path(root).resolve())
    if not path.is_file():
        raise ValueError('Archive input missing: '+str(path))
    if any('credential' in part.lower() for part in relative.parts):
        raise ValueError('Credential paths are outside archive scope')
    return relative


def excluded_reason(path, base, output):
    path = Path(path)
    relative = path.relative_to(base)
    if path == output or output in path.parents:
        return 'Current archive construction/output; exclude recursion and mutable receipt files.'
    if 'curation' in relative.parts:
        return 'Repository compact-evidence packaging helper/output, separate from closed scientific trial.'
    if any(part in {'__pycache__', '.pytest_cache'} for part in relative.parts) or path.suffix == '.pyc':
        return 'Rebuildable interpreter/test cache.'
    if path.name.endswith(('.tar.gz', '.tgz', '.zip', '.tar')):
        return 'Existing generated archive; avoid archive recursion, captured contents are independently included.'
    if any(part in {'_replay_scenes', 'render_cache', 'scene_cache'} for part in relative.parts):
        return 'Rebuildable render scene/cache; this publication adds no video or rendered physics.'
    if '_workspaces' in relative.parts and path.suffix.lower() in ASSET_EXTENSIONS:
        return 'Repeated generated workspace terrain/mesh/visual/compiled-model asset; original registered assets and model/config sources are included.'
    return None


def select_files(root, base, output, prerequisites):
    """Walk only I81 and exact registered paths, never the rest of the workspace."""
    selected, excluded = {}, {}
    for path in sorted(Path(base).rglob('*')):
        if not path.is_file() and not path.is_symlink():
            continue
        relative = relative_file(root, path)
        reason = excluded_reason(path, Path(base), Path(output))
        if reason is None:
            selected[str(relative)] = path
        elif 'Current archive construction/output' not in reason:
            excluded[str(relative)] = (path, reason)
    # Exact registered sources/inputs always win over generated-asset filtering.
    for name in prerequisites:
        path = Path(root)/name
        relative = relative_file(root, path)
        selected[str(relative)] = path
        excluded.pop(str(relative), None)
    return selected, excluded


def bindings(protocol):
    result = {}
    for key in ('source_sha256', 'input_sha256'):
        for name, value in protocol[key].items():
            if name in result and result[name] != value:
                raise ValueError('Conflicting source/input hash: '+name)
            result[name] = value
    return result


def check_registered(root, protocol):
    expected = bindings(protocol)
    for name, value in expected.items():
        path = Path(root)/name
        relative_file(root, path)
        if sha(path) != value:
            raise AssertionError('Registered source/input changed: '+name)
    return expected


def check_seal(seal_path, seal_base):
    seal = json.loads(Path(seal_path).read_text())
    if seal.get('iteration') != 'I-81' or not isinstance(seal.get('files'), dict):
        raise ValueError('I81 closed-output files mapping required')
    for name, expected in seal['files'].items():
        path = Path(seal_base)/name
        if sha(path) != expected['sha256'] or path.stat().st_size != expected['bytes']:
            raise AssertionError('Sealed output changed: '+name)
    return seal


def fixed_info(info):
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    info.mtime = 0
    return info


def stream_verify(archive, expected):
    """Read every regular member in one decompression pass and check exact set."""
    seen = set()
    with tarfile.open(archive, 'r|gz') as tf:
        for member in tf:
            if not member.isfile() or member.name in seen or member.name not in expected:
                raise AssertionError('Unexpected/duplicate/nonregular archive member: '+member.name)
            seen.add(member.name)
            h = hashlib.sha256()
            stream = tf.extractfile(member)
            for block in iter(lambda: stream.read(1024*1024), b''):
                h.update(block)
            record = expected[member.name]
            if member.size != record['bytes'] or h.hexdigest() != record['sha256']:
                raise AssertionError('Member digest mismatch: '+member.name)
    if seen != set(expected):
        raise AssertionError('Archive member set incomplete')
    return len(seen)


REPRODUCE = '''# I-81 full closed evidence archive

This captures one unchanged native Gazebo/DART figure-eight prefix through
102 seconds, its registered sources/inputs, original I76 prerequisite records,
1 ms substeps, full saved native preview data, analysis and independent proofs.
It is not a new controller or full 133-second route acceptance. No new physics
or video is generated by packaging this archive.

`project/` holds original repository-relative paths. `_archive/` holds the
pre-archive registration, external prerequisite inventory, explicit omissions,
this guide and the member inventory. Absolute historical provenance paths are
preserved; locate their captured bytes under project/<repository-relative path>.
Do not rewrite historical records to make a different host look original.

All exact sources and inputs from the frozen I81 protocol are included, including
the original I76 eight -1 N precision recording and native plugin/gain/terrain
inputs. The original I76 whole-campaign seal may also mention other episodes;
those unrelated episodes are not claimed to be copied. No virtual environment,
credential helper, unrelated firmware or unrelated user file is included.

Repeated generated workspace meshes/terrain/render caches and interpreter caches
are omitted with path/size/hash/reason inventory. Direct model XML/SDF/config
files remain included. Rebuild generated assets from captured original terrain
and source; new physics on another environment is not promised bit-identical.

Extract into a fresh directory. Start with:

- project/results/slope_response_trace_20261128/protocol/frozen_stage01/protocol.json
- .../campaign/native102_stage01/parity_receipt.json
- .../campaign/native102_stage01/substeps.npz and preview_rows.json
- .../campaign/native102_stage01/child/campaign/runs/eight_m100_N/precision.npz
- .../analysis/ and .../verification/ completed reports and source/input bindings

The output metadata distinguishes inherited I76 job/horizon labels from actual
I81 prefix/capture settings. Each command acts after the row's state; completed
1 ms force samples are not exact solver-impulse measurements. Geometric preview
exposure is not automatically force-onset prediction. Review numerical evidence
and qualifications before making causal claims.

Verify archive members against _archive/archive_inventory.json. The inventory
does not contain its own digest; its hash is separately recorded in the adjacent
archive_verification.json. That receipt records a complete streaming member-hash
check and a final unchanged-source/input/seal/selection check.

Read-only re-analysis uses captured scripts at their original relative paths and
new empty output stages. Consult each registered_before_*.json for exact flags.
The runner requires explicit --run for new physics; no new physics is needed to
inspect the saved data. Keep closed outputs immutable.
'''


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--protocol', type=Path, required=True)
    ap.add_argument('--seal', type=Path, required=True)
    ap.add_argument('--seal-base', type=Path, default=BASE)
    ap.add_argument('--observed-exit', type=Path, required=True)
    ap.add_argument('--case', type=Path, default=BASE/'campaign/native102_stage01')
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--build', action='store_true')
    args = ap.parse_args()
    if not args.build:
        raise SystemExit('Explicit --build only after root declares science proofs CLOSED')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    try:
        protocol = json.loads(args.protocol.read_text())
        if protocol.get('iteration') != 'I-81':
            raise ValueError('I81 frozen protocol required')
        expected_prerequisites = check_registered(ROOT, protocol)
        seal = check_seal(args.seal, args.seal_base)
        observed = json.loads(args.observed_exit.read_text())
        if observed.get('actual_observed_exit_code') != 0:
            raise AssertionError('Actual observed zero process exit required')
        parity = json.loads((args.case/'parity_receipt.json').read_text())
        if not parity.get('passed') or parity.get('prefix_rows') != 20401:
            raise AssertionError('Successful original-prefix parity required')
        selected, excluded = select_files(ROOT, BASE, output, expected_prerequisites)
        project = [{'source': name, 'archive_path': 'project/'+name,
                    'bytes': path.stat().st_size, 'sha256': sha(path)}
                   for name, path in sorted(selected.items())]
        omissions = [{'source': name, 'bytes': path.stat().st_size,
                      'sha256': sha(path), 'reason': reason}
                     for name, (path, reason) in sorted(excluded.items())]
        external = [{'source': name, 'sha256': value,
                     'archive_path': 'project/'+name, 'inside_I81': BASE in (ROOT/name).parents}
                    for name, value in sorted(expected_prerequisites.items())]
        registration = dict(iteration='I-81', utc=datetime.now(timezone.utc).isoformat(),
            scope='Root declared all scientific proof stages closed; packaging only.',
            source=str(Path(__file__).relative_to(ROOT)), source_sha256=sha(Path(__file__)),
            protocol=str(args.protocol.resolve().relative_to(ROOT)), protocol_sha256=sha(args.protocol),
            seal=str(args.seal.resolve().relative_to(ROOT)), seal_sha256=sha(args.seal),
            actual_exit=str(args.observed_exit.resolve().relative_to(ROOT)), actual_exit_sha256=sha(args.observed_exit),
            registered_sources=len(protocol['source_sha256']), registered_inputs=len(protocol['input_sha256']),
            sealed_outputs=len(seal['files']), files=project,
            no_new_physics=True, no_new_video=True, no_parameter_changes=True)
        metadata = {
            '_archive/registered_before_archive.json': encode(registration),
            '_archive/excluded_files.json': encode({'iteration': 'I-81', 'files': omissions}),
            '_archive/external_prerequisites.json': encode({'iteration': 'I-81', 'files': external}),
            '_archive/REPRODUCE.md': REPRODUCE.encode(),
        }
        inventory = dict(iteration='I-81', project_files=project,
            metadata_files=[{'archive_path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                            for name, data in sorted(metadata.items())],
            inventory_self_digest='Excluded from this list; adjacent final verification binds inventory bytes.')
        metadata['_archive/archive_inventory.json'] = encode(inventory)
        for name, data in metadata.items():
            with (output/Path(name).name).open('xb') as stream:
                stream.write(data)
        expected_members = {x['archive_path']: {'bytes': x['bytes'], 'sha256': x['sha256']} for x in project}
        expected_members.update({name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                                 for name, data in metadata.items()})
        archive = output/'i81_full_evidence.tar.gz'
        with tarfile.open(archive, 'w:gz') as tf:
            for record in project:
                tf.add(ROOT/record['source'], arcname=record['archive_path'], recursive=False, filter=fixed_info)
            for name, data in sorted(metadata.items()):
                info = fixed_info(tarfile.TarInfo(name))
                info.size = len(data)
                tf.addfile(info, io.BytesIO(data))
        members = stream_verify(archive, expected_members)
        check_registered(ROOT, protocol)
        check_seal(args.seal, args.seal_base)
        current, current_excluded = select_files(ROOT, BASE, output, expected_prerequisites)
        if set(current) != set(selected) or set(current_excluded) != set(excluded):
            raise AssertionError('Evidence inclusion/exclusion set changed during archive')
        for record in project:
            path = ROOT/record['source']
            if sha(path) != record['sha256'] or path.stat().st_size != record['bytes']:
                raise AssertionError('Included evidence changed during archive: '+record['source'])
        for record in omissions:
            path = ROOT/record['source']
            if sha(path) != record['sha256'] or path.stat().st_size != record['bytes']:
                raise AssertionError('Excluded-file inventory changed during archive: '+record['source'])
        receipt = dict(iteration='I-81', archive=str(archive.relative_to(ROOT)),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive),
            inventory_sha256=hashlib.sha256(metadata['_archive/archive_inventory.json']).hexdigest(),
            project_file_count=len(project), regular_file_members_verified=members,
            omitted_file_count=len(omissions), registered_source_count=len(protocol['source_sha256']),
            registered_input_count=len(protocol['input_sha256']), sealed_output_count=len(seal['files']),
            every_member_stream_decoded_and_sha256_verified=True,
            sources_inputs_outputs_and_evidence_unchanged=True,
            actual_process_exit_zero=True, native_prefix_parity_passed=True,
            no_new_physics=True, no_new_video=True)
        write_new(output/'archive_verification.json', receipt)
        print(json.dumps(receipt), flush=True)
    except BaseException:
        write_new(output/'archive_failure.json', dict(iteration='I-81',
            traceback=traceback.format_exc(), failed_archive_preserved=True, no_new_physics=True))
        raise


if __name__ == '__main__':
    main()
