"""Observe one I81 native diagnostic exit; exact log and before-run metadata."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    campaign = BASE / 'campaign'
    campaign.mkdir(exist_ok=False)
    script = BASE / 'runner/run_trace.py'
    protocol = BASE / 'protocol/frozen_stage01/protocol.json'
    out = campaign / 'native102_stage01'
    cmd = [str(ROOT / 'build/tools/bin/micromamba'), 'run', '-p',
           str(ROOT / 'build/gazebo-env'), 'python', str(script),
           '--protocol', str(protocol), '--output', str(out), '--run']
    env = os.environ.copy()
    for key in ['PYTHONPATH', 'LD_LIBRARY_PATH', 'LD_PRELOAD']:
        env.pop(key, None)
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    save(campaign / 'registered_launch.json', {
        'iteration': 'I-81', 'utc': datetime.now(timezone.utc).isoformat(),
        'command': cmd, 'cwd': str(ROOT), 'case_output': str(out.relative_to(ROOT)),
        'protocol_sha256': hashlib.sha256(protocol.read_bytes()).hexdigest(),
        'launcher_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'environment_overrides': {'unset': ['PYTHONPATH', 'LD_LIBRARY_PATH', 'LD_PRELOAD'],
                                  'set': {'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1'}},
        'scope': 'Exactly one new shortened unchanged-native prefix; no intervention or full-route acceptance.'})
    print('Launching one unchanged native102s diagnostic', flush=True)
    with (campaign / 'native102_stage01.stdout.log').open('xb') as log:
        observed = subprocess.run(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    save(campaign / 'native102_stage01.observed_exit.json', {
        'iteration': 'I-81', 'utc': datetime.now(timezone.utc).isoformat(),
        'actual_observed_exit_code': observed.returncode,
        'command': cmd, 'source': 'subprocess.run returncode, not inferred from artifacts'})
    print(json.dumps({'observed_exit': observed.returncode, 'case': str(out.relative_to(ROOT))}), flush=True)
    raise SystemExit(observed.returncode)


if __name__ == '__main__':
    main()
