"""Independently check captured native preview data and future-query timing.

No controller/model calls. Exposure is not equated with future physical load.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import math
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
FAMILIES = ['shell_A', 'shell_B', 'belt_A', 'belt_B']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def exact(left, right):
    expected = np.asarray(right)
    actual = np.asarray(left, dtype=expected.dtype)
    return actual.shape == expected.shape and actual.tobytes() == expected.tobytes()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    run, out = args.run.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    paths = [Path(__file__).resolve(), run/'preview_rows.json', run/'substeps.npz',
             run/'child/campaign/runs/eight_m100_N/precision.npz']
    bound = {str(path.relative_to(ROOT)): sha(path) for path in paths}
    shutil.copyfile(Path(__file__), out/'verify_preview.py')
    save(out/'registered_before_array_reads.json', {
        'iteration': 'I-81', 'utc': datetime.now(timezone.utc).isoformat(), 'inputs_and_source': bound,
        'scope': 'Saved snapshot identity, preparation algebra and future-query coverage; no model/observer/controller/physics replay.',
        'timing_rule': 'First captured physical1ms endpoint at or after anchor+selectedhorizon, tolerance1e-10s; reportoffset<=1ms.',
        'interpretation': 'Predicted exposure is patch-band geometry, not a claim of force onset. Captured actual_tangential_velocity fields use inferred/virtual points.'})
    doc = json.loads((run/'preview_rows.json').read_text())
    rows = doc['rows']
    with np.load(paths[-1], allow_pickle=False) as z:
        p = {key: z[key].copy() for key in z.files}
    with np.load(run/'substeps.npz', allow_pickle=False) as z:
        s = {key: z[key].copy() for key in z.files}
    assert len(rows) == 261 and doc['schema_version'] == 1
    assert [row['source_row_index'] for row in rows] == list(range(20100, 20361))
    fields = {'qpos': 'exact_qpos', 'qvel': 'exact_qvel',
              'previous_applied_input': 'exact_previous_applied',
              'returned_applied_input': 'exact_applied', 'requested_input': 'exact_requested',
              'estimator_normal': 'exact_estimated_normal'}
    info_fields = ['feedback_gain', 'error', 'reference_qpos', 'reference_qvel',
                   'feedback_reference_qvel', 'equilibrium_command', 'rolling_feedforward',
                   'support_command', 'lqr_command', 'transition_command_delta',
                   'heading_command', 'fade_command_delta', 'clipping_command_delta',
                   'sync_weights', 'input_bounds', 'estimated_support_loads_N',
                   'estimated_contact_point_m', 'allocation_drive_reference',
                   'reference_quat', 'reference_acceleration_m_s2', 'feedback_reference_xy']
    maximum_plane_error = maximum_transition_error = maximum_grid_error = 0.
    focus_rows, queries = [], []
    for row in rows:
        i = row['source_row_index']
        assert row['time_s'] == float(p['time_s'][i])
        assert row['capture_state_guard_passed'] is True
        assert row['native_preview_call_count'] == 1
        for key, field in fields.items():
            assert exact(row[key], p[field][i]), (i, key)
        for key in info_fields:
            assert exact(row['info'][key], p['exact_'+key][i]), (i, 'info', key)
        for key, field in [('xy', 'exact_reference_xy'), ('velocity', 'exact_reference_velocity_m_s'),
                           ('acceleration', 'exact_reference_acceleration_m_s2')]:
            assert exact(row['reference'][key], p[field][i])
        for key, field in [('wrench', 'exact_observer_wrench'),
                           ('generalized', 'exact_observer_generalized'),
                           ('interval_mean', 'exact_observer_interval_mean')]:
            assert exact(row['observer'][key], p[field][i]), (i, 'observer', key)
        normal = p['exact_estimated_normal'][i]
        expected_point = p['exact_qpos'][i, :3] - .12*normal
        plane = np.asarray(row['plane'], dtype=float)
        synch_plane = np.asarray(row['synchronizer_plane'], dtype=float)
        assert plane.shape == synch_plane.shape == (2, 3)
        e = max(float(np.max(np.abs(plane[0]-expected_point))),
                float(np.max(np.abs(plane[1]-normal))),
                float(np.max(np.abs(synch_plane[0]-plane[0]))),
                float(np.max(np.abs(synch_plane[1]-normal/np.linalg.norm(normal)))))
        maximum_plane_error = max(maximum_plane_error, e)
        assert e < 1e-12
        sync = row['sync']
        assert sync['lookahead_s'] == .12
        weights, commands = np.asarray(sync['blend_weights']), np.asarray(sync['commands'])
        assert exact(weights, p['exact_sync_weights'][i])
        assert (np.abs(commands) <= p['exact_input_bounds'][i] + 1e-12).all()
        assert (weights >= 0).all() and (weights <= 1).all() and weights[0] == 0
        pre_sync = sum(p[key][i] for key in ['exact_equilibrium_command', 'exact_rolling_feedforward',
                                            'exact_support_command', 'exact_lqr_command'])
        transition = weights*(commands-pre_sync)
        e = float(np.max(np.abs(transition-p['exact_transition_command_delta'][i])))
        maximum_transition_error = max(maximum_transition_error, e)
        assert e < 1e-11
        assert [x['name'] for x in sync['targets']] == FAMILIES
        angular_scale = max(1., float(np.max(np.abs(p['exact_qvel'][i, 3:]))))
        count = min(16, max(4, int(math.ceil(angular_scale*.12/.15))))
        loads = p['exact_estimated_support_loads_N'][i]
        for family, item in enumerate(sync['targets']):
            channel = family+1
            assert item['command_index'] == channel
            assert item['blend_weight'] == weights[channel]
            assert item['normal_load_N'] == loads[family]
            fraction = loads[family]/max(float(np.sum(loads)), 1e-12)
            assert abs(item['normal_load_fraction']-fraction) < 1e-14
            if fraction >= .05:
                assert weights[channel] == 0
            if not item['approaching'] or item['predicted_support_gap_m'] > .02:
                assert weights[channel] == 0
            if family < 2:
                assert weights[channel] <= .35
            assert item['currently_exposed'] == (item['current_patch_margin_m'] >= -1e-12)
            assert item['predicted_exposed'] == (item['predicted_patch_margin_m'] >= -1e-12)
            horizon = float(item['lookahead_s'])
            assert horizon > 0 and horizon <= .12
            grid = np.arange(1, count+1)*(.12/count)
            e = float(np.min(np.abs(grid-horizon)))
            maximum_grid_error = max(maximum_grid_error, e)
            assert e < 1e-14
            if 100.75-1e-9 <= row['time_s'] <= 101.65+1e-9:
                target = row['time_s']+horizon
                j = int(np.searchsorted(s['time_s'], target-1e-10, side='left'))
                assert j < len(s['time_s'])
                offset = float(s['time_s'][j]-target)
                assert offset >= -1e-10 and offset <= .001+1e-10
                queries.append({'anchor_time_s': row['time_s'], 'family': item['name'],
                                'selected_horizon_s': horizon, 'actual_endpoint_s': float(s['time_s'][j]),
                                'endpoint_offset_s': offset})
        if 100.75-1e-9 <= row['time_s'] <= 101.65+1e-9:
            focus_rows.append(i)
    assert len(focus_rows) == 181 and len(queries) == 724
    assert all(sha(ROOT/name) == expected for name, expected in bound.items())
    save(out/'report.json', {'iteration': 'I-81', 'passed': True, 'captured_rows': len(rows),
        'focus_rows': len(focus_rows), 'focus_target_queries': len(queries),
        'maximum_plane_identity_error_m': maximum_plane_error,
        'maximum_preparation_ledger_error': maximum_transition_error,
        'maximum_selected_horizon_grid_error_s': maximum_grid_error,
        'maximum_future_endpoint_offset_s': max(x['endpoint_offset_s'] for x in queries),
        'queries': queries, 'inputs_unchanged': True, 'no_new_physics': True,
        'scope': 'Identity/coverage checks only; no claim preview exposure predicts force or independent physical contact velocity.'})
    save(out/'artifact_manifest.json', {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
         for p in sorted(out.iterdir()) if p.is_file()}})
    print(json.dumps({'passed': True, 'snapshot_rows': len(rows), 'focus_rows': len(focus_rows),
                      'future_queries': len(queries)}))


if __name__ == '__main__':
    main()
