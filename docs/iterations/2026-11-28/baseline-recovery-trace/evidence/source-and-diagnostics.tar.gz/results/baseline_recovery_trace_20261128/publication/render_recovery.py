"""I86 recorded native recovery event,0.2x; MuJoCo display only."""
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import sys

os.environ.setdefault('MUJOCO_GL', 'egl')
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
OLD = ROOT/'results/tangent_heading_routes_20261127'
TRUSTED = OLD/'publication/video_tools/render.py'
GEOMETRY = ROOT/'results/path_progress_governor_20261128/publication/render.py'
CORE = ROOT/'results/recovery_assessment_20261128/evaluation/core.py'
DEFINITIONS = ROOT/'results/recovery_assessment_20261128/protocol/definitions.json'
WIDTH, HEIGHT = 1200, 960
RENDER_HEIGHT = 560
FPS, SPEED = 40, .2
WINDOW = [104.9, 106.4]
FAMILIES = ('shell A', 'shell B', 'belt A', 'belt B')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safe(v):
    if isinstance(v, dict): return {str(k): safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [safe(x) for x in v]
    if isinstance(v, np.ndarray): return safe(v.tolist())
    if isinstance(v, np.generic): return safe(v.item())
    if isinstance(v, Path): return str(v)
    if isinstance(v, float) and not np.isfinite(v): return None
    return v


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(safe(value), f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def moments():
    # Exactly every5ms recorded control pose at40fps gives0.2x playback.
    return np.arange(round(WINDOW[0]*200), round(WINDOW[1]*200)+1)/200.


def source_index(times, moment):
    t = np.asarray(times, float)
    i = int(np.searchsorted(t, float(moment)+1e-9, side='right'))-1
    if i < 0 or i >= len(t) or abs(float(t[i])-moment) > 1e-8:
        raise ValueError('Display moment must be an exact available5ms pose')
    return i


def contact_summary(trace, moment):
    times = trace['time_s']
    i = int(np.searchsorted(times, moment+1e-9, side='right'))-1
    if i < 0 or i >= len(times) or abs(float(times[i])-moment) > 1e-8:
        return None
    c = trace['contact_rows'][trace['contact_offsets'][i]:trace['contact_offsets'][i+1]]
    fn = np.einsum('ij,ij->i', c[:, 4:7], c[:, 7:10])
    valid = (c[:, 12] >= .5) & (fn > 1e-9)
    pressure = float(fn[valid].sum())
    return dict(time_s=float(times[i]), pressure_N=pressure,
        force_world_N=c[:, 7:10].sum(axis=0), resolved_loaded_rows=int(valid.sum()),
        held_input=trace['held_input'][i],
        label='Last completed1ms solve, not average5ms pressure or a separate exact impulse measurement.')


def register(run, seal, stage):
    seal_doc = json.loads(seal.read_text())
    if seal_doc.get('iteration') != 'I-86':
        raise ValueError('I86 closed output seal required')
    # Verify every sealed file before exposing any new physical array.
    for name, bound in seal_doc['files'].items():
        p = BASE/name
        if p.stat().st_size != bound['bytes'] or sha(p) != bound['sha256']:
            raise ValueError('Closed physical output changed: '+name)
    inner = run/'child/campaign/runs/eight_m100_N'
    provenance = json.loads((inner/'provenance.json').read_text())
    model = Path(provenance['models']['mirror_xml']).resolve()
    if not model.is_relative_to(run):
        raise ValueError('Recorded mirror model escapes run')
    deps = [Path(__file__).resolve(), TRUSTED, GEOMETRY, CORE, DEFINITIONS,
        OLD/'runtime/route.py', seal, run/'parity_receipt.json', run/'outcome.json',
        run/'substeps.npz', inner/'precision.npz', inner/'rollout.npz',
        inner/'provenance.json', inner/'source_snapshot/config/model.yaml', model,
        *[ROOT/'src/spherical_wheel'/f for f in ('offroad_view.py', 'offroad.py', 'model.py', 'sim.py', 'terrain.py')],
        ROOT/'src/spherical_wheel/gazebo/mars.py', ROOT/'src/spherical_wheel/gazebo/mars_compare.py']
    yard = ROOT/'assets/gazebo/third_party/leo_simulator-ros2/leo_gz_worlds/models/marsyard2021_terrain'
    deps += [yard/'dem/marsyard_terrain_hm.tif', *[yard/'meshes'/f'{n}.obj' for n in ('lava', 'rocks_big', 'rocks_medium')]]
    bindings = {str(p.relative_to(ROOT)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(set(deps))}
    stage.mkdir(parents=True, exist_ok=False)
    for p in deps:
        if p.suffix == '.py':
            dest = stage/'source'/p.relative_to(ROOT)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, dest)
    save(stage/'registered_before_new_arrays.json', dict(iteration='I-86',
        utc=datetime.now(timezone.utc).isoformat(), bindings=bindings,
        physical_window_s=WINDOW, fps=FPS, playback_speed=SPEED,
        source='Recorded Gazebo/DART physical poses; MuJoCo only displays identical robot geometry.',
        camera='One fixed close-event camera, no heading/body stabilization; full route is outside this event view.',
        contact_timing='Last completed1ms sampled solve; heldcommand shown belongs to interval ending at currentstate.',
        no_controller_observer_or_physics_execution=True))
    return inner, model, bindings


def load(inner, trace_path):
    names = dict(time_s='time_s', qpos='exact_qpos', qvel='exact_qvel',
        reference_xy='exact_reference_xy', reference_quat='exact_reference_quat',
        inferred_load='exact_estimated_support_loads_N', held_input='exact_previous_applied',
        new_applied='exact_applied', bounds='exact_input_bounds')
    with np.load(inner/'precision.npz', allow_pickle=False) as z:
        log = {key: z[value].copy() for key, value in names.items()}
        raw = {key: z[key].copy() for key in ('time_s', 'exact_qpos', 'exact_qvel',
            'exact_reference_quat', 'exact_reference_xy', 'exact_reference_velocity_m_s')}
    with np.load(inner/'rollout.npz', allow_pickle=False) as z:
        log['ground_height_m'] = z['ground_height_m'].astype(float)
        for key in ('time_s', 'qpos', 'qvel', 'reference_xy'):
            if not np.array_equal(z[key], log[key].astype(z[key].dtype)):
                raise ValueError('Display log differs from exact record: '+key)
    with np.load(trace_path, allow_pickle=False) as z:
        trace = {key: z[key].copy() for key in ('time_s', 'contact_rows', 'contact_offsets', 'held_input')}
    # Limit expensive path projection to the displayed event; retain exact row mapping.
    keep = (raw['time_s'] >= WINDOW[0]-1e-9) & (raw['time_s'] <= WINDOW[1]+1e-9)
    core = module(CORE, '_i86_render_recovery_metric')
    signals = core.signals({key: value[keep] for key, value in raw.items()}, json.loads(DEFINITIONS.read_text()))
    log['spatial_velocity_error_m_s'] = np.full(len(log['time_s']), np.nan)
    log['intended_distance_m'] = np.full(len(log['time_s']), np.nan)
    log['spatial_velocity_error_m_s'][keep] = signals['spatial_velocity_error_m_s']
    log['intended_distance_m'][keep] = signals['intended_distance_m']
    return log, trace


def frame_at(moment, log, trace, plant, renderer, camera, option, viewer, trusted, orientation):
    from PIL import Image, ImageDraw
    i = source_index(log['time_s'], moment)
    contact = contact_summary(trace, moment)
    frame = Image.new('RGB', (WIDTH, HEIGHT), (13, 21, 31))
    draw = ImageDraw.Draw(frame)
    draw.text((20, 12), f'I-86 | Native baseline | physical t = {moment:07.3f} s | 0.2x slow motion', font=trusted.font(25), fill='white')
    draw.text((20, 49), 'Recorded Gazebo / DART poses. LQR + momentum observer + inferred-contact feedforward; belt cap 0.60 m/s.', font=trusted.font(17), fill=(190, 205, 220))
    pixels = viewer._draw(plant, renderer, log, i, camera, option, True)
    frame.paste(Image.fromarray(pixels), (0, 80))
    draw = ImageDraw.Draw(frame)
    velocity_error = 1000*log['spatial_velocity_error_m_s'][i]
    path_error = 1000*log['intended_distance_m'][i]
    color = (255, 170, 100) if velocity_error > 20 else (130, 235, 170)
    draw.text((20, 651), f'Velocity residual: {velocity_error:6.1f} mm/s   |   Recovery band: 20 mm/s   |   Path distance: {path_error:5.1f} mm', font=trusted.font(22), fill=color)
    draw.text((20, 686), f'World XY velocity: {log["qvel"][i,0]:+.3f}, {log["qvel"][i,1]:+.3f} m/s  |  Tilt / own-up error: {orientation["tilt_deg"][i]:.2f} / {orientation["reference_up_error_deg"][i]:.2f} deg', font=trusted.font(19), fill=(230, 235, 241))
    held = log['held_input'][i]
    draw.text((20, 719), f'PRECEDING held motor torques: [{held[0]:+.3f}, {held[1]:+.3f}, {held[2]:+.3f}] N m  |  Belts: [{held[3]:+.3f}, {held[4]:+.3f}] m/s', font=trusted.font(19), fill=(230, 235, 241))
    if contact is None:
        line = '1 ms force capture is available only over 105.0–106.3 s.'
    else:
        force = contact['force_world_N']
        line = f'Last 1 ms pressure: {contact["pressure_N"]:6.2f} N  |  Ground force XYZ: [{force[0]:+.2f}, {force[1]:+.2f}, {force[2]:+.2f}] N'
    draw.text((20, 752), line, font=trusted.font(20), fill=(230, 235, 241))
    draw.text((20, 785), '1 ms solver sample is distinct from filtered observer load; one zero sample does not prove a 5 ms airborne event.', font=trusted.font(17), fill=(220, 190, 130))
    # Descriptive full-event velocity history, not a new recovery criterion.
    selected = (log['time_s'] >= WINDOW[0]-1e-9) & (log['time_s'] <= WINDOW[1]+1e-9)
    ts, ys = log['time_s'][selected], 1000*log['spatial_velocity_error_m_s'][selected]
    x0, x1, y0, y1, ymax = 55, 1150, 832, 909, 120.
    xx = x0+(ts-WINDOW[0])/(WINDOW[1]-WINDOW[0])*(x1-x0)
    yy = y1-np.clip(ys/ymax, 0, 1)*(y1-y0)
    draw.line(list(zip(xx, yy)), fill=(100, 215, 240), width=2)
    band = y1-20/ymax*(y1-y0)
    draw.line((x0, band, x1, band), fill=(160, 160, 160), width=1)
    cursor = x0+(moment-WINDOW[0])/(WINDOW[1]-WINDOW[0])*(x1-x0)
    draw.line((cursor, y0, cursor, y1), fill=(250, 210, 100), width=2)
    draw.text((10, 831), '120', font=trusted.font(12), fill='white')
    draw.text((20, 895), '0', font=trusted.font(12), fill='white')
    draw.text((x0, 914), '104.9 s', font=trusted.font(13), fill='white')
    draw.text((x1-60, 914), '106.4 s', font=trusted.font(13), fill='white')
    draw.text((330, 935), 'Orange: reference. Cyan: recorded trail. Fixed event view; display does not simulate physics.', font=trusted.font(14), fill=(185, 200, 215))
    return np.asarray(frame), dict(physical_time_s=moment, recorded_pose_time_s=float(log['time_s'][i]),
        source_row=i, spatial_velocity_error_mm_s=velocity_error, path_distance_mm=path_error,
        preceding_held_input=held, last_1ms_contact=contact)


def decode(video, stage, expected):
    import imageio_ffmpeg
    from PIL import Image
    reader = imageio_ffmpeg.read_frames(str(video), input_params=['-threads', '1'], output_params=['-threads', '1'])
    info = next(reader)
    assert info['size'] == (WIDTH, HEIGHT) and info['fps'] == FPS
    count = 0
    for i, data in enumerate(reader):
        count += 1
        if i in (0, expected//2, expected-1):
            Image.frombytes('RGB', info['size'], data).save(stage/f'decoded_{i:04d}.jpg', quality=95)
    assert count == expected
    return dict(bytes=video.stat().st_size, sha256=sha(video), frames=count, fps=FPS,
                duration_s=info['duration'], all_frames_decoded=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', type=Path, required=True)
    ap.add_argument('--input-seal', type=Path, required=True)
    ap.add_argument('--stage', type=Path, required=True)
    ap.add_argument('--preview', action='store_true')
    args = ap.parse_args()
    run, stage = args.run.resolve(), args.stage.resolve()
    inner, model, bindings = register(run, args.input_seal.resolve(), stage)
    log, trace = load(inner, run/'substeps.npz')
    trusted = module(TRUSTED, '_i86_render_trusted')
    geometry = module(GEOMETRY, '_i86_render_geometry')
    route = module(OLD/'runtime/route.py', '_i86_render_route')
    log['planned_xy'] = route.samples('eight')['xy_m'][::4]
    orientation = trusted.orientation_signals(log['qpos'], log['qvel'], log['reference_quat'])
    from spherical_wheel.gazebo.mars import MarsYard
    from spherical_wheel.gazebo.mars_compare import replay_plant
    from spherical_wheel import offroad_view as viewer
    import mujoco, yaml, imageio.v2 as imageio
    yard = MarsYard()
    selected = (log['time_s'] >= WINDOW[0]-1e-9) & (log['time_s'] <= WINDOW[1]+1e-9)
    xy = log['qpos'][selected, :2]
    middle = .5*(xy.min(axis=0)+xy.max(axis=0))
    bounds = (float(middle[0]-.75), float(middle[0]+.75), float(middle[1]-.75), float(middle[1]+.75))
    lookat = [float(middle[0]), float(middle[1]), float(yard.height(*middle)+.14)]
    camera = viewer._camera(lookat, 23., -26., 1.15)
    config = yaml.safe_load((inner/'source_snapshot/config/model.yaml').read_text())
    def no_step(*a, **kw): raise AssertionError('Display attempted physics integration')
    schedule, writer = [], None
    video = stage/'baseline_recovery_104p9_106p4_slow.mp4'
    clocks = moments() if not args.preview else np.array([104.9, 105.525, 105.530, 105.725, 106.4])
    with patch.object(mujoco, 'mj_step', no_step), patch.object(mujoco, 'mj_step1', no_step), patch.object(mujoco, 'mj_step2', no_step):
        plant = replay_plant(config, yard, bounds, stage/'scene')
        checks = geometry.robot_geometry_checks(dict(native=dict(mirror_xml=str(model))), plant.model, mujoco)
        option = mujoco.MjvOption()
        option.geomgroup[3:] = 0
        try:
            with mujoco.Renderer(plant.model, height=RENDER_HEIGHT, width=WIDTH) as renderer:
                if not args.preview:
                    writer = imageio.get_writer(video, fps=FPS, codec='libx264', macro_block_size=2,
                        quality=None, ffmpeg_log_level='error', ffmpeg_params=['-crf', '21', '-preset', 'fast', '-threads', '2'])
                for number, moment in enumerate(clocks):
                    frame, row = frame_at(float(moment), log, trace, plant, renderer, camera, option, viewer, trusted, orientation)
                    schedule.append(row)
                    if writer is not None: writer.append_data(frame)
                    if args.preview or number in (0, len(clocks)//2, len(clocks)-1):
                        imageio.imwrite(stage/f'pose_{moment:07.3f}s.jpg', frame, quality=95)
        finally:
            if writer is not None: writer.close()
    metadata = dict(iteration='I-86', preview=args.preview, physical_window_s=WINDOW,
        frames=len(clocks), fps=FPS, playback_speed=SPEED, dimensions=[WIDTH, HEIGHT],
        geometry_checks=checks, camera=dict(lookat_m=lookat, azimuth_deg=23., elevation_deg=-26., distance_m=1.15),
        no_controller_observer_or_physics_execution=True,
        diagnostic_scope='Native B060 interrupted-recovery event only, no improvement comparison or full-route completion claim.')
    if not args.preview: metadata['video'] = decode(video, stage, len(clocks))
    save(stage/'display_schedule.json', schedule)
    save(stage/'metadata.json', metadata)
    for relative, binding in bindings.items():
        if sha(ROOT/relative) != binding['sha256']:
            raise AssertionError('Render source/input changed: '+relative)
    save(stage/'artifact_manifest.json', dict(files={str(p.relative_to(stage)):
        dict(bytes=p.stat().st_size, sha256=sha(p)) for p in stage.rglob('*')
        if p.is_file() and 'scene' not in p.relative_to(stage).parts}))
    print(json.dumps(safe(metadata)), flush=True)


if __name__ == '__main__':
    main()
