"""I81 unchanged-native slope-response trace: no controller intervention.

Original I76 full-prefix execution, truncated at 102 s. Only the registered
physical holds split run(5) into five run(1); preview/history capture is read-only.
"""
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
import argparse
import hashlib
import importlib.util
import json
import math
import shutil
import struct
import sys
import traceback

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'results/tangent_heading_routes_20261127'
HELPER = ROOT / 'results/causal_replay_20261126/substep_trace.py'
ORIGINAL_PROTOCOL_SHA = '53106cdb758d76436e04b747c9483c4081abcc7ec1f2a163ace90b58b82085c2'
SETTINGS = dict(case_id='eight_m100_N', physical_stop_s=102., nominal_route_stop_s=133.,
    capture_window_s=[100.5, 101.8], focus_anchor_window_s=[100.75, 101.65],
    physics_dt_s=.001, control_dt_s=.005, expected_substeps=1300,
    expected_holds=260, expected_preview_rows=261, expected_precision_rows=20401,
    preview_horizon_s=.12)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safe(value):
    """Independent JSON values; nonfinite diagnostics explicitly become null."""
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return safe(value.tolist())
    if isinstance(value, np.generic):
        return safe(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return str(value)
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise TypeError('Unexpected capture value: ' + type(value).__name__)


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(safe(value), stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def in_capture_window(time_s):
    return SETTINGS['capture_window_s'][0]-1e-9 <= time_s <= SETTINGS['capture_window_s'][1]+1e-9


def _digest_value(h, value):
    """Read-only exact-array guard, preserving signed zero and NaN payload bytes."""
    if isinstance(value, np.ndarray):
        h.update(str((value.dtype.str, value.shape)).encode())
        h.update(value.tobytes())
    elif isinstance(value, dict):
        h.update(b'{')
        for key in sorted(value):
            h.update(str(key).encode())
            _digest_value(h, value[key])
        h.update(b'}')
    elif isinstance(value, (tuple, list)):
        h.update(str(type(value)).encode())
        for item in value:
            _digest_value(h, item)
    elif isinstance(value, (float, np.floating)):
        h.update(b'float' + struct.pack('!d', float(value)))
    elif value is None or isinstance(value, (str, bool, int, np.integer, np.bool_)):
        h.update(repr(value).encode())
    else:
        raise TypeError('Unexpected guard value: ' + type(value).__name__)


def capture_guard(controller, applied, info):
    data = controller.plant.data
    private = controller.synchronizer._data
    values = dict(qpos=data.qpos, qvel=data.qvel, time=float(data.time),
        last_input=controller.plant.last_input, nominal_joints=controller.nominal_joints,
        vref=controller._vref, held=controller._held, plane=controller._plane,
        sync=controller._sync, slow_normal=controller._slow_normal,
        yaw_error=controller._yaw_error, observer_generalized=controller.observer.generalized,
        observer_interval_mean=controller.observer.interval_mean,
        observer_previous=controller.observer._previous,
        estimator=vars(controller.estimator),
        sync_private_qpos=private.qpos, sync_private_qvel=private.qvel,
        sync_private_time=float(private.time), sync_private_xpos=private.xpos,
        sync_private_xmat=private.xmat, synchronizer_plane=controller.synchronizer._plane,
        applied=applied, info=info)
    h = hashlib.sha256()
    _digest_value(h, values)
    return h.hexdigest()


def export_preview_row(controller, xy, velocity, acceleration, applied, info):
    """Only copy existing values; never evaluate a second command/preview/locator."""
    data = controller.plant.data
    return safe(dict(time_s=float(data.time), source_row_index=int(round(float(data.time)/.005)),
        qpos=data.qpos, qvel=data.qvel,
        previous_applied_input=controller.plant.last_input,
        returned_applied_input=applied, requested_input=info['requested'],
        reference=dict(xy=xy, velocity=velocity, acceleration=acceleration),
        sync=controller._sync, plane=controller._plane,
        synchronizer_plane=controller.synchronizer._plane,
        observer=dict(wrench=controller.observer.generalized[:6],
            generalized=controller.observer.generalized,
            interval_mean=controller.observer.interval_mean),
        estimator_normal=controller.estimator.normal,
        info=info, capture_state_guard_passed=True))


def command_capture(native_command, rows, counts=None):
    def command(controller, xy, velocity, acceleration):
        preview = controller.synchronizer.preview
        preview_calls = 0
        def counted_preview(*args, **kwargs):
            nonlocal preview_calls
            preview_calls += 1
            return preview(*args, **kwargs)
        with patch.object(controller.synchronizer, 'preview', counted_preview):
            applied, info = native_command(controller, xy, velocity, acceleration)
        if preview_calls != 1:
            raise AssertionError('Exactly one native kinematic preview per command required')
        if counts is not None:
            counts['native_commands'] = counts.get('native_commands', 0)+1
            counts['native_previews'] = counts.get('native_previews', 0)+preview_calls
        if in_capture_window(float(controller.plant.data.time)):
            before = capture_guard(controller, applied, info)
            row = export_preview_row(controller, xy, velocity, acceleration, applied, info)
            after = capture_guard(controller, applied, info)
            if before != after:
                raise AssertionError('Read-only preview capture mutated native state/history/output')
            row['native_preview_call_count'] = preview_calls
            rows.append(row)
        return applied, info
    return command


def validate_settings(protocol):
    if protocol.get('iteration') != 'I-81' or protocol.get('runner_settings') != SETTINGS:
        raise ValueError('I81 runner settings must match the fixed registered diagnostic')


def preflight(protocol_path):
    protocol = json.loads(Path(protocol_path).read_text())
    validate_settings(protocol)
    for key in ('source_sha256', 'input_sha256'):
        for name, expected in protocol[key].items():
            if sha(ROOT / name) != expected:
                raise ValueError('I81 registered binding changed: ' + name)
    original_path = OLD / 'protocol/protocol.json'
    if sha(original_path) != ORIGINAL_PROTOCOL_SHA:
        raise ValueError('Original I76 protocol changed')
    original = json.loads(original_path.read_text())
    for key in ('source_sha256', 'input_sha256'):
        for name, expected in original[key].items():
            if sha(ROOT / name) != expected:
                raise ValueError('Original native source/input changed: ' + name)
    for p in [Path(__file__).resolve(), HELPER, OLD/'campaign_tools/run_case.py']:
        name = str(p.relative_to(ROOT))
        if protocol['source_sha256'].get(name) != sha(p):
            raise ValueError('Canonical trace source missing from I81 source bindings: '+name)
    baseline = OLD/'campaign/runs'/SETTINGS['case_id']/'precision.npz'
    seal_path = OLD/'campaign/outputs_sealed.json'
    seal = json.loads(seal_path.read_text())
    bound = seal['files'][str(baseline.relative_to(OLD))]
    if sha(baseline) != bound['sha256'] or baseline.stat().st_size != bound['bytes']:
        raise ValueError('Saved native precision differs from original I76 seal')
    return protocol, original, baseline, seal_path


def verify_prefix(old_path, new_path):
    checks = []
    with np.load(old_path, allow_pickle=False) as old, np.load(new_path, allow_pickle=False) as new:
        if set(old.files) != set(new.files):
            raise AssertionError('Precision field set differs')
        n = len(new['time_s'])
        if n != SETTINGS['expected_precision_rows'] or abs(float(new['time_s'][-1])-102.) > 1e-8:
            raise AssertionError('Wrong diagnostic prefix length')
        for key in old.files:
            expected = old[key][:n].copy()
            if key == 'command_held_after_row':
                expected[-1] = False
            actual = new[key]
            checks.append(dict(field=key, bit_exact=(actual.dtype == expected.dtype
                and actual.shape == expected.shape and actual.tobytes() == expected.tobytes()),
                shortened_terminal_mask_exception=(key == 'command_held_after_row')))
    return dict(iteration='I-81', passed=all(x['bit_exact'] for x in checks),
        prefix_rows=n, actual_end_s=102., fields=checks,
        scope='All original precision fields, including exact controls/state through102s; final unheld mask explicitly shortened. No full133s replay claim.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--protocol', type=Path, required=True)
    ap.add_argument('--output', type=Path)
    ap.add_argument('--preflight-only', action='store_true')
    ap.add_argument('--run', action='store_true')
    args = ap.parse_args()
    protocol, original, baseline, seal = preflight(args.protocol.resolve())
    if args.preflight_only:
        print(json.dumps(dict(passed=True, physics_run=False, settings=SETTINGS)), flush=True)
        return
    if not args.run or args.output is None:
        raise SystemExit('New physics requires explicit --run and new --output')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    for name in protocol['source_sha256']:
        src = ROOT / name
        dst = out/'source'/name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    shutil.copy2(args.protocol, out/'protocol.json')
    write(out/'registered_before_physics.json', dict(iteration='I-81',
        utc=datetime.now(timezone.utc).isoformat(), settings=SETTINGS,
        protocol_sha256=sha(args.protocol), sources=protocol['source_sha256'], inputs=protocol['input_sha256'],
        intervention='None: one unchanged command/observer/preview per5ms interval; split run5 into five run1 only in registered100.5–101.8s capture.',
        capture='Read-only copies after native command, inside original I76 no-truth guards; new command acts after captured state. Preview exposure is not physical force-onset prediction.',
        nonfinite_json='Optional nonfinite diagnostics become null; original precision NPZ bytes remain unchanged.',
        required_parity='All79 original precision fields through102s; final shortened unheld-command mask only exception.',
        no_full_route_acceptance=True, no_controller_change=True))
    child = out/'child'
    for folder, names in dict(adapter=['tangent_heading_adapter.py'],
                              runtime=['route.py', 'heading_reference.py'],
                              protocol=['protocol.json']).items():
        (child/folder).mkdir(parents=True)
        for name in names:
            shutil.copy2(OLD/folder/name, child/folder/name)
    parent = module(OLD/'campaign_tools/run_case.py', '_i81_original_native_parent')
    recorder = module(HELPER, '_i81_registered_substep_helper')
    from spherical_wheel.offroad_control import OffroadController
    import spherical_wheel.gazebo.experiments as gx
    true_plant, true_run = gx.GazeboWorkspace.plant, gx.run_gazebo
    true_command = OffroadController.command
    traces, previews = [], []
    counts = {}
    success = False
    receipt = None
    with ExitStack() as stack:
        def plant(workspace, terrain):
            physical = true_plant(workspace, terrain)
            if not traces:
                trace = recorder.SubstepTrace(physical, start_s=100.5, end_s=101.8)
                stack.enter_context(trace.instrument())
                traces.append(trace)
            elif traces[0].plant is not physical:
                raise AssertionError('Unexpected additional physical plant')
            return physical
        def run(workspace, terrain, path, params=None, **kwargs):
            kwargs['duration_s'] = SETTINGS['physical_stop_s']
            return true_run(workspace, terrain, path, params, **kwargs)
        try:
            with patch.object(gx.GazeboWorkspace, 'plant', plant), patch.object(gx, 'run_gazebo', run), \
                    patch.object(OffroadController, 'command', command_capture(true_command, previews, counts)):
                parent.run_case(child, SETTINGS['case_id'])
            success = True
        except BaseException:
            write(out/'failure.json', dict(traceback=traceback.format_exc()))
            raise
        finally:
            if traces:
                receipt = traces[0].save(out/'substeps.npz')
                write(out/'capture_receipt.json', receipt)
            write(out/'preview_rows.json', dict(schema_version=1, iteration='I-81',
                timing='Current-state after native command evaluation; returned command acts next. No preview recomputation. Target exposure is geometry, not guaranteed future force.',
                nonfinite_values='null', rows=previews))
            write(out/'diagnostic_metadata.json', dict(iteration='I-81', native_run_returned=success,
                settings=SETTINGS, full_route_completion_claim=False, controller_intervention=False,
                command_preview_counts=counts, parity_validation_pending=True,
                inherited_metadata_override='Child I76 horizon/job labels are inherited metadata. I81 settings define actual102s prefix and capture scope.'))
    if receipt is None or receipt['substep_rows'] != 1300 or receipt['metadata']['completed_holds'] != 260 or receipt['metadata']['failed_holds'] != 0:
        raise AssertionError('Wrong physical substep/hold capture')
    if len(previews) != 261 or not all(row['capture_state_guard_passed'] for row in previews):
        raise AssertionError('Wrong read-only preview capture count')
    if counts != dict(native_commands=20401, native_previews=20401):
        raise AssertionError('Wrong original command/preview count')
    times = np.array([row['time_s'] for row in previews])
    np.testing.assert_allclose(times, np.arange(20100, 20361)*.005, atol=1e-8, rtol=0)
    parity = verify_prefix(baseline, child/'campaign/runs'/SETTINGS['case_id']/'precision.npz')
    write(out/'parity_receipt.json', parity)
    if not parity['passed']:
        raise AssertionError('Instrumentation changed native evolution')
    preflight(args.protocol.resolve())
    write(out/'artifact_manifest.json', dict(files={str(p.relative_to(out)):
        dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(out.rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts}))
    print(json.dumps(dict(passed=True, prefix_rows=20401, fields=len(parity['fields']),
        substeps=1300, preview_rows=261, no_controller_intervention=True)), flush=True)


if __name__ == '__main__':
    main()
