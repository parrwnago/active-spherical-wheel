"""Recorded-clock/contact-label contracts; no render or physical arrays."""
from pathlib import Path
import importlib.util
import numpy as np
import pytest

spec = importlib.util.spec_from_file_location('i86_video_contract_source', Path(__file__).with_name('render_recovery.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def test_clock_retains_every_5ms_pose_at_point_two_speed():
    t = m.moments()
    assert len(t) == 301 and t[0] == 104.9 and t[-1] == 106.4
    np.testing.assert_allclose(np.diff(t), .005, atol=1e-12, rtol=0)
    assert m.FPS*.005 == m.SPEED
    assert np.any(t == 105.525) and np.any(t == 105.530)


def test_source_index_rejects_missing_pose_and_preserves_exact_row():
    t = np.arange(20980, 21281)/200.
    assert m.source_index(t, 105.525) == 125
    with pytest.raises(ValueError): m.source_index(t, 105.526)


def test_contact_label_uses_last_completed_solve_and_held_input():
    c = np.zeros((2, 16)); c[:, 6] = 1.; c[:, 9] = [7., 99.]; c[:, 12] = [1., 0.]
    trace = dict(time_s=np.array([105.525, 105.526]), contact_rows=c,
        contact_offsets=np.array([0, 1, 2]), held_input=np.array([[1., 2., 3., 0., 0.], [4., 5., 6., 0., 0.]]))
    s = m.contact_summary(trace, 105.525)
    assert s['pressure_N'] == 7. and s['resolved_loaded_rows'] == 1
    np.testing.assert_array_equal(s['held_input'], trace['held_input'][0])
    assert m.contact_summary(trace, 105.526)['pressure_N'] == 0.
    assert m.contact_summary(trace, 105.524) is None
    assert m.contact_summary(trace, 105.527) is None
