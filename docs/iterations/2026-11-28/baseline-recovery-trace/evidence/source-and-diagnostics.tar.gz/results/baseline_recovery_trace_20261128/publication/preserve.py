"""Preserve I86 compact evidence and a separately verified local raw archive."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import tarfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
DEST = ROOT/'docs/iterations/2026-11-28/baseline-recovery-trace/evidence'


def bind(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return dict(bytes=path.stat().st_size, sha256=h.hexdigest())


def dump(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def eligible(path):
    return path.is_file() and '__pycache__' not in path.parts and '.pytest_cache' not in path.parts


def verify_tar(path, inventory):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            if not member.isfile():
                continue
            if member.name not in inventory:
                raise AssertionError('Unexpected archive member '+member.name)
            expected = inventory[member.name]
            h = hashlib.sha256()
            with archive.extractfile(member) as stream:
                for block in iter(lambda: stream.read(1024*1024), b''):
                    h.update(block)
            assert member.size == expected['bytes'] and h.hexdigest() == expected['sha256'], member.name
            seen.add(member.name)
    assert seen == set(inventory)
    return len(seen)


def raw_archive():
    out = BASE/'publication/raw_evidence_stage01'
    out.mkdir(exist_ok=False)
    selected = {p.resolve() for p in BASE.rglob('*') if eligible(p)
                and out not in p.parents}
    protocol = json.loads((BASE/'protocol/frozen_stage01/protocol.json').read_text())
    dependencies = {ROOT/name for key in ('source_sha256', 'input_sha256')
                    for name in protocol[key]}
    dependencies.update(ROOT/name for name in [
        'results/slope_response_trace_20261128/analysis/core.py',
        'results/recovery_assessment_20261128/evaluation/core.py',
        'results/recovery_assessment_20261128/protocol/definitions.json'])
    mirror = ROOT/'results/current_belt_capacity_20261128/campaign/runs/B060/child/campaign/_workspaces/eight_m100_N/mirror'
    dependencies.update(p for p in mirror.rglob('*') if eligible(p))
    # Include additional explicitly registered original-path files when present.
    def inspect(obj):
        if isinstance(obj, dict):
            for name, value in obj.items():
                if isinstance(name, str) and name.startswith(('results/', 'src/', 'config/', 'scripts/', 'build/')):
                    candidate = ROOT/name
                    if candidate.is_file() and (isinstance(value, str) or isinstance(value, dict)):
                        dependencies.add(candidate)
                inspect(value)
        elif isinstance(obj, list):
            for value in obj:
                inspect(value)
    for path in BASE.rglob('*.json'):
        if out in path.parents or not eligible(path):
            continue
        if any(word in path.name for word in ('registered', 'registration', 'frozen')):
            inspect(json.loads(path.read_text()))
    selected.update(p.resolve() for p in dependencies)
    inventory = {str(p.relative_to(ROOT)): bind(p) for p in sorted(selected)}
    dump(out/'inventory.json', dict(iteration='I-86', files=inventory))
    dump(out/'external_prerequisites.json', dict(files={str(p.relative_to(ROOT)): bind(p)
        for p in sorted(dependencies) if BASE not in p.parents},
        scope='Original-path source/data/model prerequisites; installed simulator environment not included.'))
    path = out/'i86_full_evidence.tar.gz'
    with tarfile.open(path, 'w:gz', compresslevel=5) as archive:
        for name in inventory:
            archive.add(ROOT/name, arcname=name, recursive=False)
    count = verify_tar(path, inventory)
    dump(out/'verification.json', dict(iteration='I-86', utc=datetime.now(timezone.utc).isoformat(),
        archive=bind(path), regular_members=count, every_member_sha256_verified=True,
        scope='Raw physical records, exact sources and model/data prerequisites; not an installed simulator image.'))
    print(json.dumps(dict(raw_archive=str(path.relative_to(ROOT)), members=count, **bind(path))))


def compact():
    DEST.mkdir(parents=True, exist_ok=False)
    selections = []
    for folder in ('runner', 'analysis', 'verification', 'protocol'):
        for p in (BASE/folder).rglob('*'):
            if not eligible(p) or 'source' in p.relative_to(BASE).parts:
                continue
            if p.suffix in {'.json', '.py', '.md', '.png', '.pdf', '.log'}:
                selections.append(p)
    run = BASE/'campaign/native106p5_stage01'
    for name in ('parity_receipt.json', 'capture_receipt.json', 'outcome.json',
                 'registered_before_physics.json', 'capacity_before_controller.json',
                 'diagnostic_metadata.json'):
        selections.append(run/name)
    selections.extend(BASE/'campaign'/name for name in
        ('registered_launch.json', 'native106p5_stage01.observed_exit.json', 'outputs_sealed.json'))
    for folder in ('publication/raw_evidence_stage01', 'publication/video_stage01'):
        if (BASE/folder).exists():
            selections.extend(p for p in (BASE/folder).rglob('*')
                              if eligible(p) and p.suffix in {'.json', '.md'})
    files = {}
    for p in sorted(set(selections)):
        rel = p.relative_to(BASE)
        target = DEST/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(p.read_bytes())
        files[str(rel)] = dict(original=str(p.relative_to(ROOT)), **bind(p))
        assert bind(target) == bind(p)
    source_paths = [p for p in (BASE/'protocol/frozen_stage01/source').rglob('*') if eligible(p)]
    source_paths += [p for folder in ('runner', 'analysis', 'verification', 'publication', 'protocol')
                     for p in (BASE/folder).glob('*.py') if eligible(p)]
    inventory = {str(p.relative_to(ROOT)): bind(p) for p in sorted(set(source_paths))}
    archive_path = DEST/'source-and-diagnostics.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name in inventory:
            archive.add(ROOT/name, arcname=name, recursive=False)
    count = verify_tar(archive_path, inventory)
    files[archive_path.name] = dict(original='Created from captured frozen/current diagnostic sources, never relabeled as older trial source.', **bind(archive_path))
    dump(DEST/'manifest.json', dict(iteration='I-86', files=files,
        source_archive_members=count, source_archive_member_bindings=inventory,
        scope='Compact reports, plots, definitions and exact I86 sources; large raw rollouts/MP4 remain in named local archive.'))
    print(json.dumps(dict(compact=str(DEST.relative_to(ROOT)), files=len(files), source_members=count,
                          manifest=bind(DEST/'manifest.json'))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('raw', 'compact'))
    args = parser.parse_args()
    (raw_archive if args.mode == 'raw' else compact)()
