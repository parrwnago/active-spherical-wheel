"""Focused I82 capacity-interface and branch-parity contracts; no physics."""
from pathlib import Path
from types import SimpleNamespace
import copy
import importlib.util
import numpy as np
import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i82_runner_contract_source', HERE/'run_case.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def fixtures():
    config = {'actuation': {'belt_speed_limit_m_s': .3, 'torque_limits_Nm': [1.5, .6, .6]}}
    def plant():
        return SimpleNamespace(bounds=m.BASE_BOUNDS.copy(), config=copy.deepcopy(config))
    designer, physical, mirror = plant(), plant(), plant()
    workspace = SimpleNamespace(config=copy.deepcopy(config),
        design=SimpleNamespace(designer=designer, gain=np.arange(90.).reshape(5, 18)))
    return workspace, physical, mirror


def arrays(n=5):
    result = {name: np.zeros((n, 3)) for name in [
        'exact_qpos', 'exact_qvel', 'exact_previous_applied',
        'exact_observer_wrench', 'exact_observer_generalized',
        'exact_observer_interval_mean', 'truth_patch_loads_N',
        'truth_patch_points_m', 'truth_patch_contact_counts', 'truth_equivalent_point_m']}
    result.update(time_s=np.arange(n)*.005, truth_time_s=np.arange(n)*.005,
        exact_applied=np.zeros((n, 5)), exact_requested=np.zeros((n, 5)),
        exact_input_bounds=np.tile(m.BASE_BOUNDS, (n, 1)),
        command_held_after_row=np.arange(n) < n-1)
    while len(result) < 79:
        result['unchanged_'+str(len(result))] = np.zeros(n)
    return result


def save(path, values):
    with path.open('xb') as stream:
        np.savez(stream, **values)


def test_operating_cap_changes_only_independent_physical_and_mirror_bounds():
    w, physical, mirror = fixtures()
    original_config, original_gain = m.fingerprint(w.config), w.design.gain.copy()
    identity = m.apply_operating_cap(w, physical, mirror, .6)
    assert identity == original_config == m.fingerprint(w.config)
    assert np.array_equal(w.design.gain, original_gain)
    assert np.array_equal(w.design.designer.bounds, m.BASE_BOUNDS)
    assert np.array_equal(physical.bounds, [1.5, .6, .6, .6, .6])
    assert np.array_equal(mirror.bounds, physical.bounds)
    assert all(x.config['actuation']['belt_speed_limit_m_s'] == .3
               for x in (w.design.designer, physical, mirror))


def test_capacity_application_rejects_alias_and_unknown_cap():
    w, physical, mirror = fixtures()
    mirror.bounds = physical.bounds
    with pytest.raises(AssertionError, match='alias'):
        m.apply_operating_cap(w, physical, mirror, .6)
    with pytest.raises(ValueError):
        m.operating_bounds(.9)


def test_verifier_detects_one_sided_cap_or_model_configuration_change():
    w, physical, mirror = fixtures()
    physical.bounds[3:] = .6
    with pytest.raises(AssertionError):
        m.verify_operating_cap(w, physical, mirror, .6)
    mirror.bounds[3:] = .6
    physical.config['actuation']['belt_speed_limit_m_s'] = .6
    with pytest.raises(AssertionError, match='configuration'):
        m.verify_operating_cap(w, physical, mirror, .6)


def test_measured_state_transfer_keeps_newly_applied_belt_input_with_raised_mirror():
    from spherical_wheel.mirror import StateMirror
    _, physical, mirror = fixtures()
    physical.data = SimpleNamespace(qpos=np.arange(10.), qvel=np.arange(9.), time=.005)
    physical.last_input = np.array([.2, .1, -.1, .55, -.52])
    def transfer(qpos, qvel, time, applied):
        mirror.last_input = np.clip(applied, -mirror.bounds, mirror.bounds)
    mirror.set_state = transfer
    StateMirror.follow(mirror, physical)
    assert not np.array_equal(mirror.last_input, physical.last_input)
    mirror.bounds[3:] = .6
    StateMirror.follow(mirror, physical)
    assert np.array_equal(mirror.last_input, physical.last_input)


def test_counted_wrapper_calls_one_native_preview_and_returns_original_values():
    w, physical, mirror = fixtures()
    digest = m.apply_operating_cap(w, physical, mirror, .6)
    state = dict(workspace=w, physical=physical, mirror=mirror,
                 configured=True, cap=.6, config_sha=digest)
    controller = SimpleNamespace(synchronizer=SimpleNamespace(preview=lambda: {}))
    output, info, calls, counts = np.zeros(5), {'unchanged': True}, [], {}
    def native(c, *args):
        calls.append(1)
        c.synchronizer.preview()
        return output, info
    a, b = m.counted_command(native, state, counts)(controller, None, None, None)
    assert a is output and b is info and calls == [1]
    assert counts == {'commands': 1, 'previews': 1}
    def twice(c, *args):
        c.synchronizer.preview(); c.synchronizer.preview()
        return output, info
    with pytest.raises(AssertionError, match='Exactly one'):
        m.counted_command(twice, state, {})(controller, None, None, None)


def test_raised_comparison_separates_diagnostic_change_from_applied_change(tmp_path):
    old = arrays()
    new = {k: v.copy() for k, v in old.items()}
    new['exact_input_bounds'][:, 3:] = .6
    new['exact_requested'][1:, 3] = .8  # capacity-dependent request before actuation differs
    new['exact_applied'][2:, 3] = .6
    new['exact_qpos'][3:, 0] = .01  # state diverges one interval after new applied input
    a, b = tmp_path/'old.npz', tmp_path/'new.npz'
    save(a, old); save(b, new)
    result = m.compare_native(a, b, 'B060')
    assert result['first_nonbounds_diagnostic_change_row'] == 1
    assert result['first_changed_applied_row'] == 2
    assert result['physical_observer_prefix_inclusive_rows'] == 3
    assert all(result['physical_observer_prefix_checks'].values())


def test_raised_comparison_rejects_physical_change_before_new_input(tmp_path):
    old = arrays()
    new = {k: v.copy() for k, v in old.items()}
    new['exact_input_bounds'][:, 3:] = .6
    new['exact_applied'][3:, 3] = .6
    new['exact_qvel'][2, 0] = .01
    a, b = tmp_path/'old.npz', tmp_path/'new.npz'
    save(a, old); save(b, new)
    with pytest.raises(AssertionError, match='before its first'):
        m.compare_native(a, b, 'B060')


def test_early_candidate_is_preserved_and_baseline_requires_full_native_horizon(tmp_path):
    old = arrays(8)
    new = {k: v[:4].copy() for k, v in old.items()}
    new['command_held_after_row'][-1] = False
    new['exact_input_bounds'][:, 3:] = .6
    a, b, baseline = tmp_path/'old.npz', tmp_path/'new.npz', tmp_path/'baseline.npz'
    save(a, old); save(b, new)
    result = m.compare_native(a, b, 'B060')
    assert result['recorded_rows'] == 4 and result['first_changed_applied_row'] is None
    save(baseline, old)
    assert not m.compare_native(a, baseline, 'B030')['baseline_parity_passed']
    m.validate_settings({'iteration': 'I-82', 'runner_settings': m.SETTINGS}, 'B030')
    with pytest.raises(ValueError):
        m.validate_settings({'iteration': 'I-82', 'runner_settings': dict(m.SETTINGS, duration_s=102.)}, 'B030')
