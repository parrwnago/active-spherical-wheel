"""Independent I82 saved-recording verification; no controller or physics calls."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
OLD = ROOT/'results/tangent_heading_routes_20261127'
ORIGINAL = OLD/'campaign/runs/eight_m100_N'
CAPS = {'B030': .3, 'B060': .6}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def load(path):
    with np.load(path, allow_pickle=False) as z:
        return {key: z[key].copy() for key in z.files}


def differences(a, b):
    a, b = np.asarray(a), np.asarray(b)
    assert a.shape == b.shape and a.dtype == b.dtype
    return np.any(np.ascontiguousarray(a).view(np.uint8).reshape(len(a), -1) !=
                  np.ascontiguousarray(b).view(np.uint8).reshape(len(b), -1), axis=1)


def first(mask):
    ids=np.flatnonzero(mask)
    return int(ids[0]) if len(ids) else None


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--case030', type=Path, required=True)
    ap.add_argument('--case060', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args=ap.parse_args(); out=args.output.resolve(); out.mkdir(parents=True,exist_ok=False)
    cases={'B030':args.case030.resolve(),'B060':args.case060.resolve()}
    paths=[Path(__file__).resolve(),ORIGINAL/'precision.npz',ORIGINAL/'provenance.json',
           ORIGINAL/'source_snapshot/config/model.yaml',OLD/'protocol/protocol.json']
    for case in cases.values():
        inner=case/'child/campaign/runs/eight_m100_N'
        paths += [case/'outcome.json',case/'capacity_receipt.json',
                  inner/'precision.npz',inner/'provenance.json',inner/'source_snapshot/config/model.yaml']
        if (case/'substeps.npz').exists(): paths.append(case/'substeps.npz')
        if (case/'capture_receipt.json').exists(): paths.append(case/'capture_receipt.json')
    bindings={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in paths}
    shutil.copyfile(Path(__file__),out/'verify_pair.py')
    save(out/'registered_before_arrays.json',dict(iteration='I-82',utc=datetime.now(timezone.utc).isoformat(),
        files=bindings,scope='Independent recording/input/gain/prefix audit only; no physics, controller calls or acceptance verdict.',
        capacity_exception='exact_input_bounds differs from the first row. Other diagnostics may change before actual input; physical/observer history must match through first changed applied command.'))
    old=load(ORIGINAL/'precision.npz'); old_provenance=json.loads((ORIGINAL/'provenance.json').read_text())
    records={}; arrays={}; identities={}
    for arm,case in cases.items():
        inner=case/'child/campaign/runs/eight_m100_N';p=load(inner/'precision.npz');arrays[arm]=p
        assert set(p)==set(old) and len(p)==79
        n=len(p['time_s']); assert 1<=n<=26601
        cap=CAPS[arm]; bounds=np.array([1.5,.6,.6,cap,cap])
        np.testing.assert_array_equal(p['exact_input_bounds'],np.tile(bounds,(n,1)))
        np.testing.assert_array_equal(p['exact_applied'],np.clip(p['exact_requested'],-bounds,bounds))
        np.testing.assert_array_equal(p['exact_previous_applied'][1:],p['exact_applied'][:-1])
        assert p['native_feedback_boundary_verified'].all()
        assert p['mirror_previous_applied_matches_physical'].all()
        assert p['no_truth_or_terrain_read_during_command'].all()
        assert (p['native_observer_update_count']==1).all()
        assert not p['exact_heading_command'].any()
        assert not p['exact_feedback_reference_qvel'][:,3:6].any()
        assert np.isfinite(np.r_[p['exact_qpos'].ravel(),p['exact_qvel'].ravel(),p['exact_requested'].ravel()]).all()
        lqr=-np.einsum('nij,nj->ni',p['exact_feedback_gain'],p['exact_error'])
        lqr_error=float(np.max(np.abs(lqr-p['exact_lqr_command'])));assert lqr_error<1e-11
        requested=sum(p[key] for key in ['exact_equilibrium_command','exact_rolling_feedforward',
            'exact_support_command','exact_lqr_command','exact_transition_command_delta',
            'exact_heading_command','exact_fade_command_delta'])
        request_error=float(np.max(np.abs(requested-p['exact_requested'])));assert request_error<1e-11
        outcome=json.loads((case/'outcome.json').read_text())
        receipt=json.loads((case/'capacity_receipt.json').read_text())
        provenance=json.loads((inner/'provenance.json').read_text())
        assert receipt['cap_m_s']==cap and receipt['config_and_design_unchanged'] is True
        assert receipt['native_command_preview_counts']==dict(commands=n,previews=n)
        np.testing.assert_array_equal(receipt['original_designer_bounds'],[1.5,.6,.6,.3,.3])
        for key in ['physical_operating_bounds','mirror_operating_bounds']:
            np.testing.assert_array_equal(receipt[key],bounds)
        assert sha(inner/'source_snapshot/config/model.yaml')==sha(ORIGINAL/'source_snapshot/config/model.yaml')
        for key in ['ordinary_design_sha256','fixed_bank_numeric_sha256','fixed_bank_bytes_sha256']:
            assert provenance[key]==old_provenance[key],(arm,key)
        assert provenance['frozen_bank_loaded'] is True
        full=n==26601 and abs(float(p['time_s'][-1])-133.)<1e-8
        assert outcome['physical_horizon_reached']==full and outcome['recorded_rows']==n
        assert full or bool(outcome['physical_failure'])
        assert not p['command_held_after_row'][-1] and p['command_held_after_row'][:-1].all()
        identities[arm]={key:receipt[key] for key in ['config_sha256','bank_numeric_sha256',
                'ordinary_design_sha256','bank_file_sha256']}
        records[arm]=dict(recorded_rows=n,actual_end_s=float(p['time_s'][-1]),full_horizon=full,
            physical_failure=outcome['physical_failure'],lqr_ledger_max_error=lqr_error,
            requested_ledger_max_error=request_error,all_input_caps_and_guards_passed=True)
    assert identities['B030']==identities['B060']
    a=arrays['B030'];b=arrays['B060'];assert len(a['time_s'])==26601
    baseline_fields=[]
    for key in old:
        okay=a[key].shape==old[key].shape and a[key].dtype==old[key].dtype and a[key].tobytes()==old[key].tobytes()
        baseline_fields.append(dict(field=key,bit_exact=okay))
    assert all(x['bit_exact'] for x in baseline_fields)
    n=len(b['time_s']); changed={}
    for key in a:
        expected=a[key][:n].copy()
        if key=='command_held_after_row':expected[-1]=False
        changed[key]=differences(expected,b[key])
    first_applied=first(changed['exact_applied']);inclusive=n if first_applied is None else first_applied+1
    state_keys=['time_s','exact_qpos','exact_qvel','exact_previous_applied',
        'exact_observer_wrench','exact_observer_generalized','exact_observer_interval_mean',
        'exact_estimated_normal','exact_estimated_support_loads_N','exact_estimated_contact_point_m',
        'truth_time_s','truth_patch_loads_N','truth_patch_points_m','truth_patch_contact_counts','truth_equivalent_point_m']
    prefix={key:not changed[key][:inclusive].any() for key in state_keys}
    assert all(prefix.values()),prefix
    first_diagnostics=first(np.any([value for key,value in changed.items() if key!='exact_input_bounds'],axis=0))
    compare=dict(first_changed_applied_row=first_applied,
        first_changed_applied_time_s=None if first_applied is None else float(b['time_s'][first_applied]),
        first_nonbounds_diagnostic_row=first_diagnostics,
        first_nonbounds_diagnostic_time_s=None if first_diagnostics is None else float(b['time_s'][first_diagnostics]),
        physical_observer_prefix_inclusive_rows=inclusive,prefix_checks=prefix,
        first_difference_by_field=[dict(field=key,first_row=first(value),
            first_time_s=None if first(value) is None else float(b['time_s'][first(value)]),
            declared_capacity_difference=key=='exact_input_bounds') for key,value in changed.items()])
    for name,item in bindings.items():assert sha(ROOT/name)==item['sha256'],name
    save(out/'report.json',dict(iteration='I-82',passed=True,baseline_fields=baseline_fields,
        cases=records,fixed_design_identities=identities,capacity_branch=compare,
        no_new_physics=True,inputs_unchanged=True,controller_acceptance_claim=False,
        scope='One matched capacity pair; later candidate states differ through closed-loop motion. Capacity/preparation and clip effects are not separated.'))
    save(out/'artifact_manifest.json',dict(files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p))
        for p in sorted(out.iterdir()) if p.is_file()}))
    print(json.dumps(dict(passed=True,baseline_fields=79,baseline_rows=26601,
        raised_rows=n,first_changed_applied_row=first_applied)))


if __name__=='__main__':main()
