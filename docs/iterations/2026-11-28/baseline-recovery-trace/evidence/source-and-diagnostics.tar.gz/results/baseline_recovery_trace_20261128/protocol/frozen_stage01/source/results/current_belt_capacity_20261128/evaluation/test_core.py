"""Focused I82 scoring contracts, no case-array/physics/controller calls."""
import numpy as np
import core


def packet_commands(cap, request=.9):
    t = np.array([0., .005, .010])
    bounds = np.broadcast_to([1.5, .6, .6, cap, cap], (3, 5)).copy()
    desired = np.zeros((3, 5)); desired[:2, 3] = request; desired[-1] = 999.
    applied = np.clip(desired, -bounds, bounds)
    previous = np.r_[np.zeros((1, 5)), applied[:-1]]
    return t, desired, applied, previous, bounds, np.array([True, True, False])


def test_terminal_command_cannot_add_clipping_or_steps():
    args = packet_commands(.3)
    r = core.command_metrics(*args)
    assert abs(r['held_seconds']-.01) < 1e-15
    assert abs(r['own']['requested_clipped_any_seconds']-.01) < 1e-15
    assert r['requested_peak_abs'][0] == 0.
    assert r['applied_peak_abs'][3] == .3
    assert r['dimensional_applied_step_peak'][0] == 0.
    assert r['clip_identity'] and r['prior_input_identity']


def test_higher_cap_does_not_hide_common_scale_effort():
    low = core.command_metrics(*packet_commands(.3))
    high = core.command_metrics(*packet_commands(.6))
    assert high['own']['normalized_requested_excess']['rms'] < low['own']['normalized_requested_excess']['rms']
    assert high['base']['normalized_requested_excess']['rms'] == low['base']['normalized_requested_excess']['rms']
    assert low['base']['applied_exceeded_any_seconds'] == 0.
    assert abs(high['base']['applied_exceeded_any_seconds']-.01) < 1e-15
    assert high['base']['normalized_applied_step']['maximum'] == 2.
    assert high['own']['normalized_applied_step']['maximum'] == 1.


def test_clock_and_half_open_moving_window():
    t = np.arange(26601)*.005
    assert core.full_grid(t)
    assert not core.full_grid(t[:-1])
    mask = core.window(np.array([3.-1e-10, 3., 122.995, 123.-1e-10, 123.]), 3., 123., False)
    assert mask.tolist() == [True, True, True, False, False]


def test_nonfinite_and_empty_statistics_not_zero_success():
    assert not core.stats([])['complete'] and core.stats([])['maximum'] is None
    assert not core.stats([0., np.nan])['complete']
    t = np.array([0.]); zeros = np.zeros((1, 5)); bounds = np.broadcast_to(core.BASE_BOUNDS, zeros.shape)
    r = core.command_metrics(t, zeros, zeros, zeros, bounds, np.array([False]))
    assert r['held_seconds'] == 0. and r['own']['requested_clipped_any_fraction'] is None


def test_world_z_rotation_is_not_body_z_rotation():
    q = np.array([[np.sqrt(.5), 0., np.sqrt(.5), 0.]])
    R = core.old.rotation(q)
    omega = R[0]@np.array([0., 0., 1.])
    assert abs(omega[2]) < 1e-15 and abs(omega[0]-1.) < 1e-15


def test_settling_needs_complete_final_window_and_all_conditions():
    t = np.arange(26601)*.005; n = len(t)
    z = np.zeros(n)
    r = core.settling(t, z, z, z, z)
    assert r['four_condition_passed'] and r['final_samples'] == 401
    spin = z.copy(); spin[-1] = .051
    r = core.settling(t, z, z, spin, z)
    assert not r['four_condition_passed'] and r['physical_position_speed_passed']
    r = core.settling(t[:-1], z[:-1], z[:-1], z[:-1], z[:-1])
    assert not r['final_window_complete'] and not r['four_condition_passed']


def test_geometric_path_distance_keeps_segment_endpoints():
    points = np.array([[.5, .2], [2., 0.], [-1., 0.]])
    line = np.array([[0., 0.], [1., 0.]])
    actual = core.old.polyline_distance(points, line)
    np.testing.assert_allclose(actual, [.2, 1., 1.], atol=1e-15, rtol=0.)
