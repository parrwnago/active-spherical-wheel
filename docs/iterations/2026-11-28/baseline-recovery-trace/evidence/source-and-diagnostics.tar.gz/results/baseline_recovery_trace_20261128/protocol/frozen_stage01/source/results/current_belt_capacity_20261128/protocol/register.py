"""Freeze the matched current-case operating belt-capacity experiment."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parents[1]
OLD = ROOT / 'results/tangent_heading_routes_20261127'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    out = args.output.resolve()
    if out.exists():
        raise FileExistsError(out)
    old_path = OLD / 'protocol/protocol.json'
    assert sha(old_path) == '53106cdb758d76436e04b747c9483c4081abcc7ec1f2a163ace90b58b82085c2'
    old = json.loads(old_path.read_text())
    sources, inputs = dict(old['source_sha256']), dict(old['input_sha256'])
    for group in [sources, inputs]:
        for name, h in group.items():
            assert sha(ROOT / name) == h, name
    settings_path = BASE / 'runner/settings.json'
    settings = json.loads(settings_path.read_text())
    assert settings['inner_case_id'] == 'eight_m100_N'
    assert settings['duration_s'] == 133. and settings['caps_m_s'] == {'B030': .3, 'B060': .6}
    assert settings['expected_precision_rows'] == 26601
    assert settings['control_dt_s'] == .005 and settings['physics_dt_s'] == .001
    definitions = BASE / 'evaluation/definitions.json'
    evaluation = json.loads(definitions.read_text())
    own = [Path(__file__).resolve(), ROOT / 'results/causal_replay_20261126/substep_trace.py']
    own += sorted((BASE / 'runner').glob('*.py'))
    own += sorted((BASE / 'evaluation').glob('core*.py'))
    own += sorted((BASE / 'evaluation').glob('test*.py'))
    own += sorted((BASE / 'verification').glob('verify_pair.py'))
    for path in own:
        sources[str(path.relative_to(ROOT))] = sha(path)
    for path in [old_path, OLD / 'campaign/outputs_sealed.json',
                 OLD / 'campaign/runs/eight_m100_N/precision.npz',
                 OLD / 'campaign/runs/eight_m100_N/rollout.npz',
                 OLD / 'campaign/_workspaces/eight_m100_N/mirror/model.xml',
                 settings_path, definitions]:
        inputs[str(path.relative_to(ROOT))] = sha(path)
    for folder in ['runner', 'evaluation']:
        for path in sorted((BASE / folder).glob('*.json')):
            inputs[str(path.relative_to(ROOT))] = sha(path)
    seal = json.loads((OLD / 'campaign/outputs_sealed.json').read_text())
    for name in ['precision.npz', 'rollout.npz']:
        rel = 'campaign/runs/eight_m100_N/' + name
        assert sha(OLD / rel) == seal['files'][rel]['sha256']
    protocol = dict(iteration='I-82', registered_before_physics_utc=datetime.now(timezone.utc).isoformat(),
        source_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        question='Does raising both operating belt caps from0.30to0.60m/s improve this same full native133s eight−1 route and its downhill event with original gains?',
        runner_settings=settings, evaluation=evaluation, source_sha256=sources, input_sha256=inputs,
        original_protocol_path=str(old_path.relative_to(ROOT)), original_protocol_sha256=sha(old_path),
        original_output_seal_sha256=sha(OLD / 'campaign/outputs_sealed.json'),
        gain_cache=old['gain_cache'], bridge_binary_sha256=old['bridge_binary_sha256'],
        exact_physics_binary_sha256=old['exact_physics_binary_sha256'],
        parameters=old['parameters'], design_bounds=[1.5,.6,.6,.3,.3],
        operating_bounds={'B030': [1.5,.6,.6,.3,.3], 'B060': [1.5,.6,.6,.6,.6]},
        fixture='Original I76 eight rough stress; original moderate slope/relief screen remains failed.',
        scope='Two fresh full133s cases; change only operating capacity interface after original design construction. Preparation also observes operating cap. No gain/config/model redesign.',
        measurement_boundary='Exact simulated q/v, previous actual command, observer and known geometry in live control. Physical contacts/terrain are evaluation-only.',
        execution_order=['B030', 'B060'], required_baseline='All79 full26601rows byteexact original before B060 launch.',
        candidate_identity='Operating bounds differ fromreset. Record first diagnostic/request/applied/state differences separately. State/observer prefix must match through first applied change, while internal diagnostic/history differences may start earlier.',
        screen_qualification='Numerical margins are predeclared experiment preferences; report all actual improvements/regressions. A passing one-phase pair is not automatic default adoption.',
        media='Full133s side-by-side physicaltime1x plus fixed98–104s excerpt; MuJoCo visuals of recorded Gazebo/DART poses only, ended panels frozen/marked.',
        default_changed=False, no_outcome_tuning=True, no_automatic_adoption=True)
    out.mkdir(parents=True)
    for name, h in sources.items():
        target = out / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
        assert sha(target) == h
    with (out / 'protocol.json').open('x') as stream:
        json.dump(protocol, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'protocol': str((out / 'protocol.json').relative_to(ROOT)),
        'sha256': sha(out / 'protocol.json'), 'sources': len(sources),
        'inputs': len(inputs), 'physics_started': False}))


if __name__ == '__main__':
    main()
