"""I82 current figure-eight capacity pair; original I76 controller unchanged.

Only operating belt bounds change after the original .30 design is constructed.
The physical plant and contact-free mirror use the same cap; native preparation
also sees it. This is not an isolated final-clipping intervention.
"""
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import traceback

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'results/tangent_heading_routes_20261127'
HELPER = ROOT / 'results/causal_replay_20261126/substep_trace.py'
ORIGINAL_PROTOCOL_SHA = '53106cdb758d76436e04b747c9483c4081abcc7ec1f2a163ace90b58b82085c2'
BASE_BOUNDS = np.array([1.5, .6, .6, .3, .3])
CAPS = {'B030': .3, 'B060': .6}
SETTINGS = dict(inner_case_id='eight_m100_N', duration_s=133., caps_m_s=CAPS,
                control_dt_s=.005, physics_dt_s=.001, expected_precision_rows=26601,
                capture_window_s=[100.5, 101.8], expected_substeps=1300,
                expected_holds=260)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safe(value):
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return safe(value.tolist())
    if isinstance(value, np.generic):
        return safe(value.item())
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(safe(value), stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def fingerprint(value):
    return hashlib.sha256(json.dumps(safe(value), sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def operating_bounds(cap):
    if float(cap) not in CAPS.values():
        raise ValueError('Only the two registered .30/.60 operating caps are allowed')
    value = BASE_BOUNDS.copy()
    value[3:] = float(cap)
    return value


def verify_operating_cap(workspace, physical, mirror, cap, config_sha=None):
    expected = operating_bounds(cap)
    np.testing.assert_array_equal(workspace.design.designer.bounds, BASE_BOUNDS)
    np.testing.assert_array_equal(physical.bounds, expected)
    np.testing.assert_array_equal(mirror.bounds, expected)
    for obj in (workspace.design.designer, physical, mirror):
        if obj.config['actuation']['belt_speed_limit_m_s'] != .3:
            raise AssertionError('Design/model configuration must retain .30 belt capacity')
        if config_sha is not None and fingerprint(obj.config) != config_sha:
            raise AssertionError('Operating capacity changed a generated-model configuration')
    if config_sha is not None and fingerprint(workspace.config) != config_sha:
        raise AssertionError('Workspace configuration changed')
    return expected


def apply_operating_cap(workspace, physical, mirror, cap):
    """After fixed design exists, before the first controller is constructed."""
    operating_bounds(cap)
    objects = (workspace.design.designer, physical, mirror)
    if len({id(obj) for obj in objects}) != 3:
        raise AssertionError('Design, physical plant and mirror must be distinct')
    for i, obj in enumerate(objects):
        np.testing.assert_array_equal(obj.bounds, BASE_BOUNDS)
        if any(np.shares_memory(obj.bounds, other.bounds) for other in objects[i+1:]):
            raise AssertionError('Bounds arrays must not alias')
    config_sha = fingerprint(workspace.config)
    if any(fingerprint(obj.config) != config_sha for obj in objects):
        raise AssertionError('Original generated-model configurations disagree')
    physical.bounds[3:] = float(cap)
    mirror.bounds[3:] = float(cap)
    verify_operating_cap(workspace, physical, mirror, cap, config_sha)
    return config_sha


def validate_settings(protocol, arm):
    if protocol.get('iteration') != 'I-82' or protocol.get('runner_settings') != SETTINGS:
        raise ValueError('I82 settings differ from the declared original-route capacity pair')
    if arm not in CAPS:
        raise ValueError('One registered B030/B060 arm is required')
    return CAPS[arm]


def preflight(protocol_path, arm):
    protocol_path = Path(protocol_path).resolve()
    protocol = json.loads(protocol_path.read_text())
    cap = validate_settings(protocol, arm)
    for key in ('source_sha256', 'input_sha256'):
        for name, expected in protocol[key].items():
            if sha(ROOT / name) != expected:
                raise ValueError('I82 frozen source/input changed: ' + name)
    old_path = OLD / 'protocol/protocol.json'
    if sha(old_path) != ORIGINAL_PROTOCOL_SHA:
        raise ValueError('Original I76 protocol changed')
    old = json.loads(old_path.read_text())
    for key in ('source_sha256', 'input_sha256'):
        for name, expected in old[key].items():
            if sha(ROOT / name) != expected:
                raise ValueError('Original I76 source/input changed: ' + name)
    for path in [Path(__file__).resolve(), OLD / 'campaign_tools/run_case.py', HELPER]:
        if protocol['source_sha256'].get(str(path.relative_to(ROOT))) != sha(path):
            raise ValueError('Runner source missing from I82 bindings')
    baseline = OLD / 'campaign/runs/eight_m100_N/precision.npz'
    seal = json.loads((OLD / 'campaign/outputs_sealed.json').read_text())
    bound = seal['files'][str(baseline.relative_to(OLD))]
    if sha(baseline) != bound['sha256'] or baseline.stat().st_size != bound['bytes']:
        raise ValueError('Original baseline arrays differ from I76 output seal')
    return protocol, old, cap, baseline


def differing_rows(left, right):
    a, b = np.asarray(left), np.asarray(right)
    if a.shape != b.shape or a.dtype != b.dtype:
        raise ValueError('Comparable native arrays need equal dtype and shape')
    n = len(a)
    if not n:
        return np.zeros(0, bool)
    return np.any(np.ascontiguousarray(a).view(np.uint8).reshape(n, -1) !=
                  np.ascontiguousarray(b).view(np.uint8).reshape(n, -1), axis=1)


def compare_native(old_path, produced_path, arm):
    """Exact reproduction or declared capacity branch, including early failures."""
    with np.load(old_path, allow_pickle=False) as z:
        old = {k: z[k].copy() for k in z.files}
    with np.load(produced_path, allow_pickle=False) as z:
        new = {k: z[k].copy() for k in z.files}
    if set(old) != set(new) or len(new) != 79:
        raise AssertionError('All original79 precision fields are required')
    n = len(new['time_s'])
    if not 0 < n <= len(old['time_s']):
        raise AssertionError('Recorded native horizon is outside original route')
    field_rows = {}
    for key in old:
        expected = old[key][:n].copy()
        if key == 'command_held_after_row':
            expected[-1] = False
        field_rows[key] = differing_rows(expected, new[key])
    if arm == 'B030':
        passed = n == 26601 and all(not v.any() for v in field_rows.values())
        return dict(iteration='I-82', arm=arm, baseline_parity_passed=passed,
            recorded_rows=n, recorded_end_s=float(new['time_s'][-1]),
            fields=[dict(field=k, bit_exact=not v.any()) for k, v in field_rows.items()],
            scope='Full133s B030 must reproduce all79 original fields exactly, no terminal-mask exception on the complete route.')
    bounds = np.tile(operating_bounds(CAPS[arm]), (n, 1))
    if not np.array_equal(new['exact_input_bounds'], bounds):
        raise AssertionError('Raised capacity is not applied consistently to all command observations')
    changed = np.flatnonzero(field_rows['exact_applied'])
    first_applied = int(changed[0]) if len(changed) else n
    nonbounds = [v for k, v in field_rows.items() if k != 'exact_input_bounds']
    all_changed = np.flatnonzero(np.any(nonbounds, axis=0))
    first_any = int(all_changed[0]) if len(all_changed) else n
    state_fields = ['time_s', 'exact_qpos', 'exact_qvel', 'exact_previous_applied',
                    'exact_observer_wrench', 'exact_observer_generalized',
                    'exact_observer_interval_mean', 'truth_time_s',
                    'truth_patch_loads_N', 'truth_patch_points_m',
                    'truth_patch_contact_counts', 'truth_equivalent_point_m']
    inclusive = min(n, first_applied + 1)
    state_prefix = {key: not field_rows[key][:inclusive].any() for key in state_fields}
    if not all(state_prefix.values()):
        raise AssertionError('Raised capacity changed physical/observer history before its first changed applied command')
    return dict(iteration='I-82', arm=arm, recorded_rows=n,
        recorded_end_s=float(new['time_s'][-1]),
        first_changed_applied_row=None if first_applied == n else first_applied,
        first_changed_applied_time_s=None if first_applied == n else float(new['time_s'][first_applied]),
        first_nonbounds_diagnostic_change_row=None if first_any == n else first_any,
        first_nonbounds_diagnostic_change_time_s=None if first_any == n else float(new['time_s'][first_any]),
        nonbounds_complete_prefix_rows=first_any,
        physical_observer_prefix_inclusive_rows=inclusive,
        physical_observer_prefix_checks=state_prefix,
        first_difference_by_field=[dict(field=k, first_row=int(np.flatnonzero(v)[0]) if v.any() else None,
             first_time_s=float(new['time_s'][np.flatnonzero(v)[0]]) if v.any() else None,
             declared_initial_capacity_difference=(k == 'exact_input_bounds')) for k, v in field_rows.items()],
        scope='Capacity/preparation can change diagnostics before applied inputs. Physical/observer history must stay exact through the first newly changed applied command. Later history is closed-loop, not a same-state counterfactual.')


def counted_command(native, state, counts):
    def command(controller, xy, velocity, acceleration):
        if not state.get('configured'):
            raise AssertionError('Operating bounds must be installed before controller commands')
        verify_operating_cap(state['workspace'], state['physical'], state['mirror'],
                             state['cap'], state['config_sha'])
        original = controller.synchronizer.preview
        calls = 0
        def preview(*args, **kwargs):
            nonlocal calls
            calls += 1
            return original(*args, **kwargs)
        with patch.object(controller.synchronizer, 'preview', preview):
            applied, info = native(controller, xy, velocity, acceleration)
        if calls != 1:
            raise AssertionError('Exactly one native preview per command is required')
        counts['commands'] = counts.get('commands', 0) + 1
        counts['previews'] = counts.get('previews', 0) + calls
        return applied, info
    return command


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--protocol', type=Path, required=True)
    ap.add_argument('--arm', choices=list(CAPS), required=True)
    ap.add_argument('--output', type=Path)
    ap.add_argument('--native-baseline', type=Path)
    ap.add_argument('--preflight-only', action='store_true')
    ap.add_argument('--run', action='store_true')
    args = ap.parse_args()
    protocol, old, cap, baseline = preflight(args.protocol, args.arm)
    if args.preflight_only:
        print(json.dumps(dict(passed=True, physics_run=False, arm=args.arm, cap_m_s=cap)), flush=True)
        return
    if not args.run or args.output is None:
        raise SystemExit('Explicit --run and NEW --output required for new physics')
    if args.arm == 'B060':
        if args.native_baseline is None:
            raise ValueError('B060 requires the completed B030 output via --native-baseline')
        outcome = json.loads((args.native_baseline / 'outcome.json').read_text())
        if not outcome.get('baseline_parity_passed') or not outcome.get('runner_recording_completed'):
            raise ValueError('B030 full original79-field parity is required before B060')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    for name in protocol['source_sha256']:
        dest = out / 'source' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
    shutil.copyfile(args.protocol, out / 'protocol.json')
    write(out / 'registered_before_physics.json', dict(iteration='I-82',
        utc=datetime.now(timezone.utc).isoformat(), arm=args.arm, cap_m_s=cap,
        protocol_sha256=sha(args.protocol), sources=protocol['source_sha256'], inputs=protocol['input_sha256'],
        scope='Original .30 design, gain bank and controller with only physical/mirror operating belt bounds changed after design construction; preparation observes operating bounds.',
        default_changed=False, full_route_requested_s=133., torque_bounds=BASE_BOUNDS[:3],
        interpretation='A full-run capacity comparison, not final-clamp-only or a same-state local-event intervention. Native child labels remain inherited I76; this record defines actual arm/cap.'))
    child = out / 'child'
    for folder, names in dict(adapter=['tangent_heading_adapter.py'],
                              runtime=['route.py', 'heading_reference.py'],
                              protocol=['protocol.json']).items():
        (child / folder).mkdir(parents=True)
        for name in names:
            shutil.copyfile(OLD / folder / name, child / folder / name)
    parent = module(OLD / 'campaign_tools/run_case.py', '_i82_unchanged_i76_parent')
    recorder = module(HELPER, '_i82_unchanged_substep_trace')
    parent.BOUNDS = operating_bounds(cap)
    from spherical_wheel.offroad_control import OffroadController
    from spherical_wheel.gazebo.experiments import GazeboWorkspace
    original_plant, original_mirror = GazeboWorkspace.plant, GazeboWorkspace.mirror
    original_command = OffroadController.command
    state, counts = {'cap': cap, 'configured': False}, {}
    traces = []
    capture_receipt = None
    returned = False
    try:
        def plant(workspace, terrain):
            obj = original_plant(workspace, terrain)
            if 'physical' in state and state['physical'] is not obj:
                raise AssertionError('Only one physical plant is permitted')
            state.update(workspace=workspace, physical=obj)
            if not traces:
                trace = recorder.SubstepTrace(obj, start_s=100.5, end_s=101.8)
                stack.enter_context(trace.instrument())
                traces.append(trace)
            elif traces[0].plant is not obj:
                raise AssertionError('Substep recorder encountered a replacement plant')
            if state['configured']:
                verify_operating_cap(workspace, obj, state['mirror'], cap, state['config_sha'])
            return obj
        def mirror(workspace):
            obj = original_mirror(workspace)
            if 'physical' not in state:
                raise AssertionError('Original runner must construct physical plant before mirror')
            if not state['configured']:
                before = parent.design_identity(workspace.design)
                config_sha = apply_operating_cap(workspace, state['physical'], obj, cap)
                if parent.design_identity(workspace.design) != before:
                    raise AssertionError('Operating capacity changed numerical design gains')
                state.update(workspace=workspace, mirror=obj, config_sha=config_sha,
                             bank_identity=before, configured=True)
                write(out / 'capacity_before_controller.json', dict(iteration='I-82', arm=args.arm,
                    cap_m_s=cap, config_sha256=config_sha, bank_numeric_sha256=before,
                    original_designer_bounds=workspace.design.designer.bounds,
                    physical_operating_bounds=state['physical'].bounds,
                    mirror_operating_bounds=obj.bounds, design_config_belt_cap_m_s=.3,
                    applied_after_design_before_live_controller=True,
                    design_weights=workspace.design.weights))
            else:
                if obj is not state['mirror']:
                    raise AssertionError('Original mirror replaced during the run')
                verify_operating_cap(workspace, state['physical'], obj, cap, state['config_sha'])
            return obj
        try:
            with ExitStack() as stack:
                stack.enter_context(patch.object(GazeboWorkspace, 'plant', plant))
                stack.enter_context(patch.object(GazeboWorkspace, 'mirror', mirror))
                stack.enter_context(patch.object(OffroadController, 'command', counted_command(original_command, state, counts)))
                parent.run_case(child, SETTINGS['inner_case_id'])
        finally:
            if traces:
                capture_receipt = traces[0].save(out / 'substeps.npz')
                write(out / 'capture_receipt.json', capture_receipt)
        returned = True
        run = child / 'campaign/runs/eight_m100_N'
        summary = json.loads((run / 'summary.json').read_text())
        provenance = json.loads((run / 'provenance.json').read_text())
        comparison = compare_native(baseline, run / 'precision.npz', args.arm)
        write(out / 'native_comparison.json', comparison)
        n = comparison['recorded_rows']
        if counts != dict(commands=n, previews=n):
            raise AssertionError('Native command/preview count does not match recorded rows')
        if args.arm == 'B030' and not comparison['baseline_parity_passed']:
            raise AssertionError('B030 did not reproduce original full133s recording')
        verify_operating_cap(state['workspace'], state['physical'], state['mirror'], cap, state['config_sha'])
        if parent.design_identity(state['workspace'].design) != state['bank_identity']:
            raise AssertionError('Numerical bank changed after operating-capacity run')
        preflight(args.protocol, args.arm)
        full_horizon = n == 26601 and abs(comparison['recorded_end_s'] - 133.) <= 1e-8
        capture_complete = (capture_receipt is not None
            and capture_receipt['substep_rows'] == 1300
            and capture_receipt['metadata']['completed_holds'] == 260
            and capture_receipt['metadata']['failed_holds'] == 0)
        if args.arm == 'B030' or comparison['recorded_end_s'] >= 101.8 - 1e-8:
            if not capture_complete:
                raise AssertionError('Complete covered100.5–101.8s window must have1300samples/260holds')
        write(out / 'capacity_receipt.json', dict(iteration='I-82', arm=args.arm, cap_m_s=cap,
            original_designer_bounds=state['workspace'].design.designer.bounds,
            physical_operating_bounds=state['physical'].bounds, mirror_operating_bounds=state['mirror'].bounds,
            config_sha256=state['config_sha'], bank_numeric_sha256=state['bank_identity'],
            ordinary_design_sha256=provenance['ordinary_design_sha256'],
            bank_file_sha256=provenance['fixed_bank_bytes_sha256'],
            config_and_design_unchanged=True, native_command_preview_counts=counts,
            substep_capture_complete=capture_complete,
            substep_capture_window_s=SETTINGS['capture_window_s'],
            semantics='Operating cap affects physical/mirror inputs and incoming preparation. No model/config/gain/default edits.'))
        write(out / 'outcome.json', dict(iteration='I-82', arm=args.arm, cap_m_s=cap,
            runner_recording_completed=True, native_run_returned=True,
            physical_horizon_reached=full_horizon, actual_end_s=comparison['recorded_end_s'],
            recorded_rows=n, physical_failure=summary.get('failure'),
            substep_capture_complete=capture_complete,
            inherited_native_summary_completed=bool(summary['completed']),
            baseline_parity_passed=comparison.get('baseline_parity_passed'),
            prefix_validation_passed=True, controller_defaults_changed=False,
            acceptance_not_automatic=True,
            qualification='A physical early stop is retained as candidate outcome, separately from process/recording completion. I76 child cap/job labels are inherited; I82 outer arm/cap records are authoritative.'))
        write(out / 'artifact_manifest.json', dict(files={str(p.relative_to(out)):
            dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(out.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts}))
        print(json.dumps(dict(arm=args.arm, runner_recording_completed=True,
            physical_horizon_reached=full_horizon, physical_failure=summary.get('failure'),
            rows=n, baseline_parity_passed=comparison.get('baseline_parity_passed'))), flush=True)
    except BaseException:
        write(out / 'runner_failure.json', dict(iteration='I-82', arm=args.arm,
            cap_m_s=cap, native_run_returned=returned, counts=counts,
            traceback=traceback.format_exc(),
            qualification='Harness/runtime/validation exception; inspect preserved child physics failure and partial arrays separately. No automatic retry or tuning.'))
        raise


if __name__ == '__main__':
    main()
