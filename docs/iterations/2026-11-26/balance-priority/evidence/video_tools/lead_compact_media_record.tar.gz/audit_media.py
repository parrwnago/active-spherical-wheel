"""Independent I58 encoded-media clock audit and fixed contact sheets."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import imageio.v2 as imageio
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
STAGE = HERE/'render_stage01'
QA = HERE/'qa_stage01'
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if QA.exists():
        raise FileExistsError('Preserve the earlier media audit')
    QA.mkdir()
    report = json.loads((STAGE/'metadata.json').read_text())
    schedule = json.loads((STAGE/'display_schedule.json').read_text())
    plan = json.loads((HERE/'presentation_plan.json').read_text())
    evidence = dict(started_utc=datetime.now(timezone.utc).isoformat(),
                    audit_source_sha256=sha(__file__), report_sha256=sha(STAGE/'metadata.json'),
                    plan_sha256=sha(HERE/'presentation_plan.json'), videos={})
    for key, moments in [('overview', [0, 18, 28, 32, 36, 44]),
                         ('slow_28_36', [28, 30, 32, 34, 36])]:
        item = report['videos'][key]
        movie_path = ROOT/item['path']
        assert sha(movie_path) == item['sha256']
        speed = item['playback_speed']
        start, end = item['recorded_window_s']
        expected_count = 100+round((end-start)*20/speed)+1
        entries = [row for row in schedule if row['video'] == key]
        assert len(entries) == expected_count-100
        assert entries[0]['recorded_time_s'] == start
        assert entries[-1]['recorded_time_s'] == end
        images, clocks = [], []
        with imageio.get_reader(movie_path) as reader:
            info = reader.get_meta_data()
            assert reader.count_frames() == item['frames'] == expected_count
            assert abs(info['fps']-20) < 1e-9
            assert abs(info['duration']-expected_count/20) < .051
            for moment in moments:
                frame = 40+round((moment-start)*20/speed)
                row = next(row for row in entries if row['frame'] == frame)
                assert abs(row['recorded_time_s']-moment) < 1e-10
                assert all(abs(sample['saved_time_s']-moment) <= .002501 and not sample['ended'] for sample in row['case_samples'].values())
                pixels = reader.get_data(frame)
                assert pixels.shape == (1080, 1920, 3)
                path = QA/f'{key}_t{moment:05.2f}_frame{frame:04d}.jpg'
                imageio.imwrite(path, pixels, quality=95)
                images.append(Image.fromarray(pixels).resize((960, 540), Image.Resampling.LANCZOS))
                clocks.append(dict(recorded_time_s=moment, frame=frame, movie_time_s=frame/20,
                                   exact_case_saved_time_s={k: v['saved_time_s'] for k,v in row['case_samples'].items()}))
        sheet = Image.new('RGB', (1920, 54+((len(images)+1)//2)*578), (10,20,31))
        draw = ImageDraw.Draw(sheet)
        draw.text((20,10), f'I58 {key}: fixed decoded-frame contact sheet; labels are neutral', font=ImageFont.truetype(FONT,28), fill=(240,230,200))
        for index, (image, clock) in enumerate(zip(images, clocks)):
            x, y = (index%2)*960, 54+(index//2)*578
            draw.text((x+12,y+4), f'Recorded {clock["recorded_time_s"]:.2f} s | frame {clock["frame"]} | movie {clock["movie_time_s"]:.2f} s', font=ImageFont.truetype(FONT,20), fill=(222,234,245))
            sheet.paste(image,(x,y+36))
        sheet.save(QA/f'{key}_contact_sheet.jpg', quality=95)
        evidence['videos'][key] = dict(sha256=item['sha256'], bytes=movie_path.stat().st_size,
            frames=expected_count, fps=20, duration_s=info['duration'], dimensions=list(info['size']),
            decoded_fixed_clocks=clocks, contact_sheet=f'{key}_contact_sheet.jpg')
    evidence['finished_utc'] = datetime.now(timezone.utc).isoformat()
    evidence['qa'] = dict(encoded_clock_checks_passed=True, saved_pose_clocks_passed=True,
        all_three_cases_retained=True, all_cases_cover_both_windows=True,
        scientific_acceptance_not_inferred_from_video=True)
    (QA/'report.json').write_text(json.dumps(evidence,indent=2)+'\n')
    (QA/'artifact_manifest.json').write_text(json.dumps(dict(files=[dict(path=str(p.relative_to(QA)),sha256=sha(p),bytes=p.stat().st_size) for p in sorted(QA.iterdir()) if p.is_file() and p.name!='artifact_manifest.json']),indent=2)+'\n')
    print(json.dumps(evidence,indent=2))


if __name__ == '__main__':
    main()
